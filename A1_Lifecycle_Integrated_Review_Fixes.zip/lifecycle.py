"""Pod A1 lifecycle logic aligned to Canonical Field Mapping v0.2.

Integration module: does not implement discovery persistence or the proposed API.
The caller must supply trusted scan evidence and an approved dormancy threshold.
"""
from __future__ import annotations
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Optional


class LifecycleState(str, Enum):
    ACTIVE = 'ACTIVE'
    UNREACHABLE = 'UNREACHABLE'
    DORMANT = 'DORMANT'
    DELETED = 'DELETED'
    QUARANTINED = 'QUARANTINED'


class ScanStatus(str, Enum):
    SUCCEEDED = 'SUCCEEDED'
    PARTIAL = 'PARTIAL'
    FAILED = 'FAILED'


class LifecycleError(ValueError):
    pass


def utc_datetime(value: datetime) -> datetime:
    if not isinstance(value, datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise LifecycleError('Timestamp must have an explicit timezone')
    return value.astimezone(timezone.utc)


def validate_state(value: str | LifecycleState) -> LifecycleState:
    try:
        return LifecycleState(value)
    except (ValueError, TypeError):
        raise LifecycleError('lifecycle_state must be a valid UPPERCASE non-null state') from None


def provider_state(source_type: str, source_status: str) -> Optional[LifecycleState]:
    """Return None for unrecognised provider status; caller decides review/quarantine."""
    mapping = {
        'AWS_BEDROCK': {'PREPARED': LifecycleState.ACTIVE,
                        'ACTIVE': LifecycleState.ACTIVE,
                        'DELETED': LifecycleState.DELETED},
        'AZURE_AI_FOUNDRY': {'active': LifecycleState.ACTIVE,
                            'DELETED': LifecycleState.DELETED},
    }
    if source_type not in mapping:
        raise LifecycleError('Unsupported source_type')
    return mapping[source_type].get(source_status) if isinstance(source_status, str) else None


@dataclass(frozen=True)
class AgentLifecycle:
    lifecycle_state: LifecycleState
    last_seen_at: datetime
    metadata_version: int

    def __post_init__(self):
        object.__setattr__(self, 'lifecycle_state', validate_state(self.lifecycle_state))
        object.__setattr__(self, 'last_seen_at', utc_datetime(self.last_seen_at))
        if type(self.metadata_version) is not int or self.metadata_version < 1:
            raise LifecycleError('metadata_version must be a positive integer')


def transition(record: AgentLifecycle, target: str | LifecycleState, *,
               observed_at: Optional[datetime] = None) -> AgentLifecycle:
    """Change state and optionally record a verified successful observation.

    Persistence layer must update registry updated_at when a tracked change occurs.
    """
    target = validate_state(target)
    new_seen = record.last_seen_at
    if observed_at is not None:
        new_seen = max(record.last_seen_at, utc_datetime(observed_at))
    changed = target != record.lifecycle_state
    return replace(record, lifecycle_state=target, last_seen_at=new_seen,
                   metadata_version=record.metadata_version + int(changed))


def process_provider_observation(record: Optional[AgentLifecycle], *,
                                 source_type: str, source_status: str,
                                 observed_at: datetime) -> Optional[AgentLifecycle]:
    """New unknown status -> review queue (return None); existing -> QUARANTINED.

    Caller must enqueue rejected/new ambiguous observations for review.
    """
    observed_at = utc_datetime(observed_at)
    mapped = provider_state(source_type, source_status)
    if mapped is None:
        return None if record is None else transition(record, LifecycleState.QUARANTINED)
    if record is None:
        return AgentLifecycle(mapped, observed_at, 1)
    # Delayed observations must not overwrite newer state.
    if observed_at < record.last_seen_at:
        return record
    return transition(record, mapped, observed_at=observed_at)


def process_missing_agent(record: AgentLifecycle, *, scan_status: str | ScanStatus,
                          now: datetime, dormancy_period: timedelta,
                          verification_failed: bool = True) -> AgentLifecycle:
    """Apply absence rules; never infer deletion from scan absence.

    verification_failed indicates this agent was not verifiable in a recent scan.
    The caller is responsible for deciding whether evidence is sufficient.
    """
    try:
        scan_status = ScanStatus(scan_status)
    except (TypeError, ValueError):
        raise LifecycleError('Invalid scan status') from None
    now = utc_datetime(now)
    if dormancy_period <= timedelta(0):
        raise LifecycleError('A positive, approved dormancy_period is required')
    if now < record.last_seen_at:
        raise LifecycleError('now precedes last_seen_at')
    if record.lifecycle_state in (LifecycleState.DELETED, LifecycleState.QUARANTINED):
        return record
    # Failure/partial scans cannot establish absence or deletion; mark uncertain
    # only when caller supplies evidence that this agent was not verified.
    if not verification_failed:
        return record
    if now - record.last_seen_at >= dormancy_period:
        return transition(record, LifecycleState.DORMANT)
    return transition(record, LifecycleState.UNREACHABLE)

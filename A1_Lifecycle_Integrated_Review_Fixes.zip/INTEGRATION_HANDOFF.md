# Lifecycle integration — 26 November 2026
Branch: feature/lifecycle-integration (local baseline from supplied ZIP, not a remote repository).

## Hook points
Gautham: `_upsert()` returns the stored canonical record; snapshot existing record before mutation and compare after commit. New record starts at version 1; `_commit_lifecycle()` writes state, last_seen_at and version. Emit discovery after insertion, lifecycle event on state change, metadata event on tracked metadata change; use stored agent_id/version, never generate them in producer. A single upsert increments once even when state and metadata both change. No event publishing implemented here.
Pavani: call `Inventory.quarantine_existing(tenant_id, source_type, external_id)` for an existing suspicious agent; it invokes transition and retains the record. New suspicious observations must not be inserted. REVIEW is a proposed Result.outcome value pending confirmation of the event/review contract.
Scan coordinator: call `mark_unverified()` with trusted per-agent evidence, scan status and aware timestamp. Default dormancy 14 days, override via Inventory(dormancy_days=N). No scheduler supplied in prototype. Failed/partial scans never infer deletion.

## Changes and decisions
- Replaced STATUS_MAP with provider_state; source aliases bridge the old source_type format to canonical provider mapping. Existing source_type storage, UUID generation and source-reference schema intentionally unchanged to avoid overlapping Soumojit's work.
- Missing or unknown provider status: new observation REVIEW, existing record QUARANTINED. Overlong names follow same review/quarantine routing.
- Quarantine is sticky until explicit review; release policy requires team confirmation. Unknown delayed observations conservatively quarantine existing records; confirm this policy with team.
- Timestamp-only observation updates do not bump metadata_version, preserving baseline test contract; actual state or tracked metadata changes do. Registry updated_at is not present in this baseline; coordinate with Soumojit.
- Changed test_valid_aws_record_is_accepted_and_normalized from active to ACTIVE; changed test_unknown_status_is_quarantined_and_not_stored expected outcome from QUARANTINED to REVIEW. All other original assertions retained.
- Section 13 limits, exact-match identity changes, secret stripping, duplicate detection and event producer are separate teammate work; not implemented here. The uploaded snapshot predates those changes.

## PR process
Apply lifecycle-integration.patch to the matching baseline (or merge manually into latest shared branch). Run python -m pytest -v. Review differences with teammates before pushing. No remote URL or credentials supplied; no remote branch or PR created.

## Sharvari review fixes — 26 November 2026
- Older observations (`observed_at < last_seen_at`) are ignored before status handling or quarantine. An audit entry with outcome REVIEW is appended to `review_log`; the ingest response is ACCEPTED_WITH_WARNINGS with the unchanged stored record.
- Missing provider status (`None` or absent) for an existing agent is treated as no lifecycle evidence: preserve state and metadata_version, return ACCEPTED_WITH_WARNINGS, and advance last_seen_at only if the timestamp is newer. Unknown non-null values still quarantine existing agents.
- A new agent with missing status still enters REVIEW and is not created.
- Added tests: `test_replayed_unknown_status_is_reviewed_without_quarantining_healthy_agent`, `test_missing_status_on_existing_agent_keeps_state_with_warning`, `test_missing_status_new_agent_still_goes_to_review`.
- Local full suite: 63 passed. GitHub PR still requires submission to the team's repository.

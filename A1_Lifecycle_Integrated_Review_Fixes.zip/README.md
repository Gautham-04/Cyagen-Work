# CyAgen – Pod A1 Module 1 Prototype (Discovery & Inventory)

Fixture-based validation prototype (Week 1 Task 4, extended by Sohamsing for M4).
FAKE controlled test data only - no real cloud systems are accessed.

## Files
- ingest.py                    - validation, normalisation, de-duplication, in-memory inventory
- fixtures.json                - fake test records (AWS Bedrock / Azure shaped)
- tests/test_ingest.py         - 21 original tests
- tests/test_m4_extended.py    - 14 UTC / date-validation / replay tests

## Run
    python -m pip install pytest
    python -m pytest -v

Expected result: 35 passed.

## Known limitations (see Field Mapping v0.2, Section 12)
- lifecycle_state and source_type are lowercase (v0.2 requires UPPERCASE)
- agent_id is a plain UUID (v0.2 requires agt_ + UUID v4)
- No discovery events, REVIEW classification or metadata secret stripping yet
- Azure slash-date order/timezone unconfirmed; no live integration or event publisher tested

"""Task 4: validate + normalize source records, and de-duplicate into an inventory.
 
Flow: raw record -> validate -> normalize -> upsert (dedupe) -> store.
Week 1 uses controlled test fixtures only; no real external system is accessed.
"""
from __future__ import annotations
 
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Any, Optional
 
from lifecycle import (AgentLifecycle, LifecycleState, provider_state,
                       process_provider_observation, process_missing_agent, transition)

DEFAULT_DORMANCY_DAYS = 14
REVIEW = "REVIEW"
ACCEPTED = "ACCEPTED"
ACCEPTED_WITH_WARNINGS = "ACCEPTED_WITH_WARNINGS"
QUARANTINED = "QUARANTINED"
REJECTED = "REJECTED"
 
MAX_NAME_LEN = 256
 
# source_type -> mapping of source field names to canonical names
FIELD_MAP = {
    "aws_bedrock": {"external_id": "agentId", "name": "agentName",
                    "status": "agentStatus", "created": "createdAt"},
    "azure_ai": {"external_id": "id", "name": "display_name",
                 "status": "state", "created": "created"},
}
 
SOURCE_ALIASES = {"aws_bedrock": "AWS_BEDROCK", "azure_ai": "AZURE_AI_FOUNDRY"}
 
 
@dataclass
class Result:
    outcome: str
    reasons: list[str] = field(default_factory=list)
    record: Optional[dict] = None  # normalized record (None when rejected)
 
 
def _text(value: Any) -> Optional[str]:
    """Trim, collapse spaces, strip control chars. Empty -> None."""
    if not isinstance(value, str):
        return None
    value = re.sub(r"[\x00-\x1f\x7f]", " ", value)
    value = re.sub(r"\s+", " ", value).strip()
    return value or None
 
 
def parse_date(value: Any, day_first: bool = False) -> Optional[str]:
    """Normalize explicit offset-aware ISO 8601 timestamps to UTC.

    day_first is retained for compatibility but deliberately ignored: a
    source-specific date-order and timezone contract must be approved before
    supporting slash dates or date-only inputs.
    """
    if not isinstance(value, str) or not value.strip():
        return None
    value = value.strip()
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?(?:Z|[+-]\d{2}:\d{2})", value):
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.utcoffset() is None:
            return None
        return dt.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    except ValueError:
        return None


def validate_and_normalize(raw: Any, tenant_id: Any, source_type: Any,
                           observed_at: Optional[str] = None) -> Result:
    """Step 1 validate, step 2 normalize. Required fields can reject; optional never do."""
    if observed_at is None:
        observed_at = datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")
    else:
        observed_at = parse_date(observed_at)
        if observed_at is None:
            return Result(REJECTED, ["observed_at must be timezone-aware ISO 8601"] )
 
    # ---- Validation: required fields (reject) ----
    if not isinstance(raw, dict):
        return Result(REJECTED, ["record is not a JSON object"])
    reasons: list[str] = []
    tenant = _text(tenant_id)
    if not tenant:
        reasons.append("tenant_id missing or empty")
    if source_type not in FIELD_MAP:
        reasons.append("source_type missing or unsupported")
    if reasons:
        return Result(REJECTED, reasons)
 
    fm = FIELD_MAP[source_type]
    external_id = _text(raw.get(fm["external_id"]))
    if not external_id:
        return Result(REJECTED, ["external_id missing or empty"])
 
    # ---- Normalization + optional-field handling ----
    warnings: list[str] = []
    quarantine: list[str] = []
 
    name = _text(raw.get(fm["name"]))
    if name is None:
        warnings.append("name missing; set to null")
    elif len(name) > MAX_NAME_LEN:
        quarantine.append(f"name longer than {MAX_NAME_LEN} characters")
 
    created_raw = raw.get(fm["created"])
    creation_date = parse_date(created_raw, day_first=(source_type == "azure_ai"))
    if created_raw not in (None, "") and creation_date is None:
        warnings.append("creation date missing timezone, ambiguous, or invalid; set to null pending source contract")
 
    status_raw = raw.get(fm["status"])
    mapped = provider_state(SOURCE_ALIASES[source_type], status_raw)
    if mapped is None:
        quarantine.append("missing or unrecognized provider status")
    lifecycle = mapped.value if mapped is not None else QUARANTINED

    record = {
        "tenant_id": tenant,
        "name": name,
        "owner_id": None,  # unknown, never guessed
        "creation_date": creation_date,
        "lifecycle_state": lifecycle,
        "source_references": [{"source_type": source_type,
                               "external_id": external_id,
                               "observed_at": observed_at}],
    }
    if quarantine:
        record["lifecycle_state"] = QUARANTINED
        return Result(QUARANTINED, quarantine + warnings, record)
    if warnings:
        return Result(ACCEPTED_WITH_WARNINGS, warnings, record)
    return Result(ACCEPTED, [], record)
 
 
class Inventory:
    """In-memory inventory. Match key = (tenant_id, source_type, external_id)."""
 
    def __init__(self, dormancy_days: int = DEFAULT_DORMANCY_DAYS) -> None:
        if type(dormancy_days) is not int or dormancy_days <= 0:
            raise ValueError("dormancy_days must be a positive integer")
        self.dormancy_period = timedelta(days=dormancy_days)
        self._agents: dict[tuple, dict] = {}
        self.review_log: list[dict] = []

    @staticmethod
    def _key(record: dict) -> tuple:
        ref = record["source_references"][0]
        return (record["tenant_id"], ref["source_type"], ref["external_id"])

    @staticmethod
    def _as_lifecycle(record: dict) -> AgentLifecycle:
        return AgentLifecycle(record["lifecycle_state"],
                              datetime.fromisoformat(record["last_seen_at"].replace("Z", "+00:00")),
                              record["metadata_version"])

    def _commit_lifecycle(self, record: dict, updated: AgentLifecycle) -> None:
        """Single lifecycle commit hook; event producer can observe before/after here."""
        record["lifecycle_state"] = updated.lifecycle_state.value
        record["last_seen_at"] = updated.last_seen_at.isoformat(timespec="milliseconds").replace("+00:00", "Z")
        record["metadata_version"] = updated.metadata_version

    def ingest(self, raw: Any, tenant_id: Any, source_type: Any,
               observed_at: Optional[str] = None) -> Result:
        res = validate_and_normalize(raw, tenant_id, source_type, observed_at)
        if res.outcome == REJECTED:
            self.review_log.append({"outcome": res.outcome, "reasons": res.reasons,
                                    "tenant_id": tenant_id, "source_type": source_type})
            return res
        rec = res.record
        status = raw.get(FIELD_MAP[source_type]["status"])
        key = self._key(rec)
        existing = self._agents.get(key)
        # Stale observations are audit-only, even if their provider status is
        # unknown. This guard must precede any quarantine or metadata mutation.
        if existing is not None and rec["source_references"][0]["observed_at"] < existing["last_seen_at"]:
            reason = "older observation ignored; sent to review_log"
            self.review_log.append({"outcome": REVIEW, "reasons": [reason],
                                    "tenant_id": tenant_id, "source_type": source_type,
                                    "external_id": key[2],
                                    "observed_at": rec["source_references"][0]["observed_at"]})
            return Result(ACCEPTED_WITH_WARNINGS, [reason], existing)
        # Missing status on an existing agent means no evidence of a state
        # change, not an unrecognized provider status.
        if existing is not None and status is None:
            reason = "provider status missing; existing lifecycle state retained"
            seen = rec["source_references"][0]["observed_at"]
            if seen > existing["last_seen_at"]:
                existing["last_seen_at"] = seen
                existing["source_references"][0]["observed_at"] = seen
            return Result(ACCEPTED_WITH_WARNINGS, [reason] + [r for r in res.reasons if r != "missing or unrecognized provider status"], existing)
        stored = self._upsert(rec, status, res.outcome == QUARANTINED)
        if res.outcome == QUARANTINED:
            res.outcome = REVIEW if stored is None else QUARANTINED
            self.review_log.append({"outcome": res.outcome, "reasons": res.reasons,
                                    "tenant_id": tenant_id, "source_type": source_type})
        res.record = stored
        return res

    def _upsert(self, rec: dict, source_status: Any, suspicious: bool = False) -> Optional[dict]:
        key = self._key(rec)
        seen = rec["source_references"][0]["observed_at"]
        observed = datetime.fromisoformat(seen.replace("Z", "+00:00"))
        existing = self._agents.get(key)
        previous = self._as_lifecycle(existing) if existing is not None else None
        updated = process_provider_observation(previous, source_type=SOURCE_ALIASES[key[1]],
                                               source_status=source_status, observed_at=observed)
        if suspicious:
            if previous is None:
                return None
            updated = transition(previous, LifecycleState.QUARANTINED)
            self._commit_lifecycle(existing, updated)
            return existing
        if updated is None:
            return None
        if existing is None:
            rec.update(agent_id=str(uuid.uuid4()), first_seen_at=seen)
            self._commit_lifecycle(rec, updated)
            self._agents[key] = rec
            return rec
        if observed < previous.last_seen_at:
            return existing
        # Quarantine release requires explicit review; do not silently clear it.
        if previous.lifecycle_state == LifecycleState.QUARANTINED:
            return existing
        changed = any(rec[f] != existing[f] for f in ("name", "creation_date"))
        for f in ("name", "creation_date"):
            existing[f] = rec[f]
        if changed and updated.metadata_version == previous.metadata_version:
            from dataclasses import replace
            updated = replace(updated, metadata_version=previous.metadata_version + 1)
        if seen > existing["last_seen_at"]:
            existing["source_references"][0]["observed_at"] = seen
        self._commit_lifecycle(existing, updated)
        return existing

    def mark_unverified(self, tenant_id: str, source_type: str, external_id: str, *,
                        scan_status: str, now: datetime, verification_failed: bool) -> Optional[dict]:
        """Scan coordinator calls this only for an agent with trusted scan evidence."""
        record = self.get(tenant_id, source_type, external_id)
        if record is None:
            return None
        updated = process_missing_agent(self._as_lifecycle(record), scan_status=scan_status,
                                        now=now, dormancy_period=self.dormancy_period,
                                        verification_failed=verification_failed)
        self._commit_lifecycle(record, updated)
        return record

    def quarantine_existing(self, tenant_id: str, source_type: str, external_id: str) -> Optional[dict]:
        """Pavani's duplicate-detection hook; never creates a record."""
        record = self.get(tenant_id, source_type, external_id)
        if record is not None:
            self._commit_lifecycle(record, transition(self._as_lifecycle(record), LifecycleState.QUARANTINED))
        return record

    def get(self, tenant_id: str, source_type: str, external_id: str) -> Optional[dict]:
        return self._agents.get((tenant_id, source_type, external_id))

    def list_for_tenant(self, tenant_id: str) -> list[dict]:
        return [a for k, a in self._agents.items() if k[0] == tenant_id]

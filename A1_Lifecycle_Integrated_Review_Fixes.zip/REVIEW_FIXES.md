# Lifecycle integration — review fixes (26 November 2026)

## Changes
1. Stale/replayed observations are ignored **before** suspicious status handling, including unknown statuses. An entry is appended to `Inventory.review_log` with outcome `REVIEW`; the ingest call returns `ACCEPTED_WITH_WARNINGS` and the unchanged stored agent.
2. Existing agents with missing (`None`/absent) status retain lifecycle state and metadata_version and receive a warning. The observation timestamp may advance. New agents with missing status continue to `REVIEW`.
3. Added three focused regression tests; all **63 tests pass** using `python -m pytest -v`.

## Ownership and remaining work
Pavani owns `DELETED -> ACTIVE` resurrection review rules and quarantine-release policy is still undefined. No GitHub PR was created from this local package; apply to the current team branch, run the suite there, then submit the PR.

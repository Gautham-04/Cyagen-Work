import unittest
from datetime import datetime, timedelta, timezone
from lifecycle import (AgentLifecycle, LifecycleError, LifecycleState,
                       provider_state, process_missing_agent,
                       process_provider_observation, transition, validate_state)

T = datetime(2026, 11, 20, 9, tzinfo=timezone.utc)

class LifecycleTests(unittest.TestCase):
    def setUp(self):
        self.agent = AgentLifecycle(LifecycleState.ACTIVE, T, 3)

    def test_states_uppercase_and_nonnull(self):
        for value in ('active', None, '', 'SUSPENDED', 'REVOKED'):
            with self.assertRaises(LifecycleError): validate_state(value)
        for value in LifecycleState:
            self.assertEqual(validate_state(value.value), value)

    def test_provider_mapping(self):
        self.assertEqual(provider_state('AWS_BEDROCK', 'PREPARED'), LifecycleState.ACTIVE)
        self.assertEqual(provider_state('AWS_BEDROCK', 'DELETED'), LifecycleState.DELETED)
        self.assertEqual(provider_state('AZURE_AI_FOUNDRY', 'active'), LifecycleState.ACTIVE)
        self.assertIsNone(provider_state('AWS_BEDROCK', 'mystery'))
        with self.assertRaises(LifecycleError): provider_state('aws_bedrock', 'ACTIVE')

    def test_new_unknown_is_not_created(self):
        self.assertIsNone(process_provider_observation(None, source_type='AWS_BEDROCK',
                            source_status='mystery', observed_at=T))

    def test_existing_unknown_quarantined_and_retained(self):
        result = process_provider_observation(self.agent, source_type='AWS_BEDROCK',
                          source_status='mystery', observed_at=T)
        self.assertEqual(result.lifecycle_state, LifecycleState.QUARANTINED)
        self.assertEqual(result.metadata_version, 4)

    def test_unreachable_not_deleted_after_failed_scan(self):
        result = process_missing_agent(self.agent, scan_status='FAILED',
                         now=T + timedelta(hours=1), dormancy_period=timedelta(days=2))
        self.assertEqual(result.lifecycle_state, LifecycleState.UNREACHABLE)
        self.assertEqual(result.last_seen_at, T)

    def test_dormant_after_configured_period(self):
        result = process_missing_agent(self.agent, scan_status='PARTIAL',
                         now=T + timedelta(days=3), dormancy_period=timedelta(days=2))
        self.assertEqual(result.lifecycle_state, LifecycleState.DORMANT)

    def test_no_evidence_no_change(self):
        result = process_missing_agent(self.agent, scan_status='FAILED',
                         now=T + timedelta(hours=1), dormancy_period=timedelta(days=2),
                         verification_failed=False)
        self.assertEqual(result, self.agent)

    def test_no_version_bump_without_change(self):
        self.assertEqual(transition(self.agent, 'ACTIVE').metadata_version, 3)
        self.assertEqual(transition(self.agent, 'DORMANT').metadata_version, 4)

    def test_last_seen_never_goes_backwards(self):
        self.assertEqual(transition(self.agent, 'ACTIVE', observed_at=T-timedelta(days=1)).last_seen_at, T)
        self.assertEqual(process_provider_observation(self.agent, source_type='AWS_BEDROCK',
                         source_status='DELETED', observed_at=T-timedelta(days=1)), self.agent)

    def test_deleted_not_resurrected_by_missing_scan(self):
        deleted = transition(self.agent, 'DELETED')
        self.assertEqual(process_missing_agent(deleted, scan_status='SUCCEEDED',
                         now=T+timedelta(days=3), dormancy_period=timedelta(days=2)), deleted)

    def test_timezone_required(self):
        with self.assertRaises(LifecycleError): AgentLifecycle('ACTIVE', datetime(2026, 11, 20), 1)

if __name__ == '__main__': unittest.main()

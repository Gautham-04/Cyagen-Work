import sys,pathlib
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent.parent))
import pytest
from ingest import parse_date, validate_and_normalize, Inventory, REJECTED, ACCEPTED_WITH_WARNINGS

@pytest.mark.parametrize('incoming,expected',[
 ('2026-11-18T16:00:00+05:30','2026-11-18T10:30:00.000Z'),
 ('2026-11-18T10:30:00Z','2026-11-18T10:30:00.000Z'),
 ('2026-11-18T10:30:00.125Z','2026-11-18T10:30:00.125Z'),
 ('2026-11-18T08:30:00-02:00','2026-11-18T10:30:00.000Z'),
])
def test_utc_conversion(incoming,expected):
 assert parse_date(incoming)==expected

@pytest.mark.parametrize('bad',['01/10/2026','11/12/2026','2026-11-18','2026-11-18T10:30:00','2026-02-30T10:00:00Z','hello','2026-11-18T10:30:00.123456Z'])
def test_ambiguous_or_invalid_date_is_not_guessed(bad):
 assert parse_date(bad) is None

def test_untrusted_observation_timestamp_rejected():
 raw={'agentId':'ABC','agentStatus':'ACTIVE','createdAt':'2026-11-18T10:30:00Z'}
 assert validate_and_normalize(raw,'tenant1','aws_bedrock','11/12/2026').outcome==REJECTED

def test_azure_slash_date_warns_not_guessed():
 raw={'id':'agent','state':'active','created':'01/10/2026'}
 res=validate_and_normalize(raw,'tenant1','azure_ai','2026-11-18T10:30:00Z')
 assert res.outcome==ACCEPTED_WITH_WARNINGS
 assert res.record['creation_date'] is None

def test_replayed_old_observation_does_not_rewind_last_seen():
 inv=Inventory(); raw={'agentId':'A','agentStatus':'ACTIVE','createdAt':'2026-11-18T10:30:00Z'}
 inv.ingest(raw,'tenant1','aws_bedrock','2026-11-18T16:00:00Z')
 inv.ingest(raw,'tenant1','aws_bedrock','2026-11-18T10:00:00Z')
 assert inv.get('tenant1','aws_bedrock','A')['last_seen_at']=='2026-11-18T16:00:00.000Z'


from datetime import datetime, timedelta, timezone
import pytest
from ingest import Inventory, REVIEW, QUARANTINED
T = datetime(2026,11,1,tzinfo=timezone.utc)
SRC = 'aws_bedrock'
def ingest(inv, status='ACTIVE', when=T, **extra):
    return inv.ingest(dict(agentId='a',agentName='Agent',agentStatus=status,**extra),'t',SRC,when.isoformat())
@pytest.mark.parametrize('status',[None,'', 'unknown', [], 'active'])
def test_new_unknown(status):
    inv=Inventory(); r=ingest(inv,status); assert r.outcome==REVIEW and r.record is None and not inv.list_for_tenant('t')
def test_existing_unknown():
    inv=Inventory(); ingest(inv); r=ingest(inv,'unknown'); assert r.outcome==QUARANTINED and r.record['metadata_version']==2
    assert ingest(inv,'unknown').record['metadata_version']==2
    assert ingest(inv).record['lifecycle_state']==QUARANTINED
@pytest.mark.parametrize('scan',['FAILED','PARTIAL','SUCCEEDED'])
def test_dormancy(scan):
    inv=Inventory(); ingest(inv)
    r=inv.mark_unverified('t',SRC,'a',scan_status=scan,now=T+timedelta(days=13),verification_failed=True)
    assert r['lifecycle_state']=='UNREACHABLE' and r['metadata_version']==2
    r=inv.mark_unverified('t',SRC,'a',scan_status=scan,now=T+timedelta(days=14),verification_failed=True)
    assert r['lifecycle_state']=='DORMANT' and r['metadata_version']==3
    assert r['last_seen_at']=='2026-11-01T00:00:00.000Z'
def test_configurable():
    inv=Inventory(2); ingest(inv)
    assert inv.mark_unverified('t',SRC,'a',scan_status='FAILED',now=T+timedelta(days=2),verification_failed=True)['lifecycle_state']=='DORMANT'
def test_no_double_bump():
    inv=Inventory(); ingest(inv)
    r=inv.ingest({'agentId':'a','agentName':'Changed','agentStatus':'DELETED'},'t',SRC,(T+timedelta(days=1)).isoformat())
    assert r.record['metadata_version']==2 and r.record['lifecycle_state']=='DELETED'
def test_quarantine_hook():
    inv=Inventory(); ingest(inv)
    assert inv.quarantine_existing('t',SRC,'a')['metadata_version']==2
    assert inv.quarantine_existing('t',SRC,'a')['metadata_version']==2
    assert inv.quarantine_existing('other',SRC,'a') is None
def test_recovery():
    inv=Inventory(); ingest(inv)
    inv.mark_unverified('t',SRC,'a',scan_status='FAILED',now=T+timedelta(days=14),verification_failed=True)
    assert ingest(inv,when=T+timedelta(days=15)).record['lifecycle_state']=='ACTIVE'
def test_replay_does_not_change_state():
    inv=Inventory(); ingest(inv,when=T+timedelta(days=1)); assert ingest(inv,'DELETED').record['lifecycle_state']=='ACTIVE'

def test_replayed_unknown_status_is_reviewed_without_quarantining_healthy_agent():
    inv = Inventory()
    healthy = ingest(inv, 'ACTIVE', when=T + timedelta(days=2)).record
    before = dict(healthy)
    result = ingest(inv, 'unknown', when=T + timedelta(days=1))
    assert result.record is healthy
    assert result.outcome == 'ACCEPTED_WITH_WARNINGS'
    assert healthy['lifecycle_state'] == 'ACTIVE'
    assert healthy['metadata_version'] == before['metadata_version']
    assert healthy['last_seen_at'] == before['last_seen_at']
    assert inv.review_log[-1]['outcome'] == REVIEW
    assert 'older observation' in inv.review_log[-1]['reasons'][0]


def test_missing_status_on_existing_agent_keeps_state_with_warning():
    inv = Inventory()
    existing = ingest(inv, 'ACTIVE', when=T).record
    result = inv.ingest({'agentId': 'a', 'agentName': 'Agent'}, 't', SRC,
                        (T + timedelta(days=1)).isoformat())
    assert result.outcome == 'ACCEPTED_WITH_WARNINGS'
    assert result.record is existing
    assert existing['lifecycle_state'] == 'ACTIVE'
    assert existing['metadata_version'] == 1
    assert existing['last_seen_at'] == '2026-11-02T00:00:00.000Z'
    assert any('status missing' in r for r in result.reasons)


def test_missing_status_new_agent_still_goes_to_review():
    inv = Inventory()
    result = inv.ingest({'agentId': 'a', 'agentName': 'Agent'}, 't', SRC, T.isoformat())
    assert result.outcome == REVIEW
    assert result.record is None

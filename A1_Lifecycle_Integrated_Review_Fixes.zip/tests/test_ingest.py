import json
import pathlib
import sys
 
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
import pytest
from ingest import (ACCEPTED, ACCEPTED_WITH_WARNINGS, QUARANTINED, REJECTED,
                    Inventory, validate_and_normalize, REVIEW)
 
FX = json.loads((pathlib.Path(__file__).resolve().parent.parent / "fixtures.json").read_text())
T1 = "tenant-1"
 
 
# ---- Valid records ----
def test_valid_aws_record_is_accepted_and_normalized():
    r = validate_and_normalize(FX["aws_valid"], T1, "aws_bedrock")
    assert r.outcome == ACCEPTED
    assert r.record["name"] == "Sales Bot"
    assert r.record["lifecycle_state"] == "ACTIVE"
    assert r.record["creation_date"] == "2026-10-01T10:00:00.000Z"
    assert r.record["source_references"][0]["external_id"] == "ABC123"
 
 
def test_valid_azure_record_is_normalized_to_same_shape():
    r = validate_and_normalize(FX["azure_valid"], T1, "azure_ai")
    assert r.outcome == ACCEPTED_WITH_WARNINGS
    assert r.record["name"] == "Sales Bot"  # trimmed, spaces collapsed
    assert r.record["creation_date"] is None  # date order/timezone unconfirmed
 
 
def test_agent_id_is_platform_generated():
    inv = Inventory()
    inv.ingest(FX["aws_valid"], T1, "aws_bedrock")
    assert inv.get(T1, "aws_bedrock", "ABC123")["agent_id"]
 
 
# ---- Invalid input (required fields) ----
@pytest.mark.parametrize("tenant", [None, "", "   "])
def test_missing_tenant_is_rejected(tenant):
    assert validate_and_normalize(FX["aws_valid"], tenant, "aws_bedrock").outcome == REJECTED
 
 
def test_missing_external_id_is_rejected():
    assert validate_and_normalize(FX["aws_no_id"], T1, "aws_bedrock").outcome == REJECTED
 
 
def test_unsupported_source_is_rejected():
    assert validate_and_normalize(FX["aws_valid"], T1, "unknown_src").outcome == REJECTED
 
 
@pytest.mark.parametrize("bad", ["just a string", ["a"], None, 42])
def test_non_object_record_is_rejected(bad):
    assert validate_and_normalize(bad, T1, "aws_bedrock").outcome == REJECTED
 
 
def test_unknown_status_is_quarantined_and_not_stored():
    inv = Inventory()
    r = inv.ingest(FX["aws_bad_status"], T1, "aws_bedrock")
    assert r.outcome == REVIEW
    assert inv.get(T1, "aws_bedrock", "ABC126") is None
    assert len(inv.review_log) == 1
 
 
def test_overlong_name_is_quarantined():
    raw = dict(FX["aws_valid"], agentName="x" * 300)
    assert validate_and_normalize(raw, T1, "aws_bedrock").outcome == QUARANTINED
 
 
# ---- Missing information (optional fields) ----
def test_missing_name_is_null_and_record_kept():
    inv = Inventory()
    r = inv.ingest(FX["aws_no_name"], T1, "aws_bedrock")
    assert r.outcome == ACCEPTED_WITH_WARNINGS
    assert inv.get(T1, "aws_bedrock", "ABC124")["name"] is None
 
 
def test_bad_date_is_null_and_record_kept():
    r = validate_and_normalize(FX["aws_bad_date"], T1, "aws_bedrock")
    assert r.outcome == ACCEPTED_WITH_WARNINGS
    assert r.record["creation_date"] is None
 
 
def test_owner_is_unknown_not_guessed():
    r = validate_and_normalize(FX["aws_valid"], T1, "aws_bedrock")
    assert r.record["owner_id"] is None
 
 
# ---- Duplicate observations ----
def test_same_agent_seen_twice_is_one_record_and_last_seen_updates():
    inv = Inventory()
    inv.ingest(FX["aws_valid"], T1, "aws_bedrock", "2026-10-27T10:00:00.000Z")
    first_id = inv.get(T1, "aws_bedrock", "ABC123")["agent_id"]
    inv.ingest(FX["aws_valid"], T1, "aws_bedrock", "2026-10-27T16:00:00.000Z")
    agents = inv.list_for_tenant(T1)
    assert len(agents) == 1
    a = agents[0]
    assert a["agent_id"] == first_id
    assert a["first_seen_at"] == "2026-10-27T10:00:00.000Z"
    assert a["last_seen_at"] == "2026-10-27T16:00:00.000Z"
    assert a["metadata_version"] == 1  # nothing changed
 
 
def test_changed_data_bumps_metadata_version():
    inv = Inventory()
    inv.ingest(FX["aws_valid"], T1, "aws_bedrock")
    inv.ingest(dict(FX["aws_valid"], agentName="Sales Bot v2"), T1, "aws_bedrock")
    assert inv.get(T1, "aws_bedrock", "ABC123")["metadata_version"] == 2
 
 
def test_same_name_different_external_id_stays_separate():
    inv = Inventory()
    inv.ingest(FX["aws_valid"], T1, "aws_bedrock")
    inv.ingest(FX["aws_same_name_other_id"], T1, "aws_bedrock")
    assert len(inv.list_for_tenant(T1)) == 2
 
 
def test_same_external_id_in_different_tenants_never_merges():
    inv = Inventory()
    inv.ingest(FX["aws_valid"], "tenant-1", "aws_bedrock")
    inv.ingest(FX["aws_valid"], "tenant-2", "aws_bedrock")
    assert len(inv.list_for_tenant("tenant-1")) == 1
    assert len(inv.list_for_tenant("tenant-2")) == 1
    assert inv.get("tenant-1", "aws_bedrock", "ABC123")["agent_id"] != \
        inv.get("tenant-2", "aws_bedrock", "ABC123")["agent_id"]

from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
import json, sqlite3
from typing import Iterable

class DeliveryState(str, Enum):
    PENDING="PENDING"
    DELIVERED="DELIVERED"
    FAILED="FAILED"

@dataclass(frozen=True)
class OutboxEvent:
    event_ref:str
    idempotency_key:str
    payload:dict
    state:DeliveryState
    created_at:str
    updated_at:str
    retry_count:int=0

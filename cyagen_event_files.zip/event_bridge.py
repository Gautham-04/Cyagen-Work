from __future__ import annotations
from dataclasses import dataclass
from copy import deepcopy
from typing import Optional, Any
from ingest import Inventory

@dataclass(frozen=True)
class InventoryChange:
    change_type:str
    before: Optional[dict]
    after: Optional[dict]
    scan_id: Optional[str]

class EventBridge:
    def __init__(self, inventory: Inventory):
        self.inventory = inventory

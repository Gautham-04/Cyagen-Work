"""
event_validator.py - independent checker for A1 discovery events (NEW FILE)

Checks events against "A1 Discovery Event Contract - Draft v0.2" (and Field
Mapping v0.2 for IDs, lifecycle values and secret patterns), with the latest B2
feedback applied (as stated by the module owner):
  * event_id must NOT be populated by Module 1 (null or absent); B2 creates it
  * sources[].error_code is now sources[].source_error_code
  * scan-level error_code is now scan_error_code

This file is written separately from discovery_events.py on purpose and does NOT
import it: it is a second opinion, so a bug in the producer cannot hide itself.

Command line (from modules/module-1-agent-discovery):
    python src/event_validator.py FILE.json [FILE2.json ...] [--ordered]
FILE may hold one event, a list of events, or a bundle such as
discovery_event_payloads.json (every event found inside is checked).
Exit code 0 = no FAIL findings, 1 = at least one FAIL, 2 = usage/read error.

A finding is a dict: {level: FAIL|WARN, category, rule, message}
Categories: ENVELOPE, ID, TIME, PAYLOAD, SECRET (single event) and
            GROUP, RETRY (across events). Secret VALUES are never printed,
            only their location in the event.
"""
import copy
import json
import re
import sys
from collections import defaultdict
from datetime import datetime

# ---------------------------------------------------------------- contract tables
ENVELOPE_FIELDS = ["event_id", "source_system_ref", "schema_version", "event_type",
                   "source_module", "tenant_id", "correlation_id", "scan_id",
                   "occurred_at", "published_at", "agent_id", "metadata_version",
                   "change_summary", "payload"]
AGENT_TYPES = {"AGENT_DISCOVERED", "AGENT_METADATA_UPDATED",
               "AGENT_LIFECYCLE_CHANGED", "AGENT_IDENTITY_RESOLVED"}
SCAN_TYPES = {"DISCOVERY_SCAN_COMPLETED": "SUCCEEDED", "DISCOVERY_SCAN_PARTIAL": "PARTIAL",
              "DISCOVERY_SCAN_FAILED": "FAILED"}
STATES = {"ACTIVE", "UNREACHABLE", "DORMANT", "DELETED", "QUARANTINED"}
SOURCES = {"AWS_BEDROCK", "AZURE_AI_FOUNDRY"}
CATEGORIES = {"ERROR", "TIMEOUT", "UNAVAILABLE", "INCOMPLETE_RESPONSE"}
# contract 6.1: (failure_category, error_code) pairs that are specified
KNOWN_FAILURES = {("ERROR", "AUTH_ERROR"), ("ERROR", "PERMISSION_DENIED"),
                  ("TIMEOUT", "SOURCE_TIMEOUT"), ("TIMEOUT", "SCAN_TIMEOUT"),
                  ("UNAVAILABLE", "SOURCE_UNAVAILABLE"),
                  ("INCOMPLETE_RESPONSE", "INCOMPLETE_RESPONSE")}
REASONS = {
    "AGENT_DISCOVERED": {"NEW_AGENT_OBSERVED"},
    "AGENT_METADATA_UPDATED": {"SOURCE_METADATA_CHANGED"},
    "AGENT_LIFECYCLE_CHANGED": {"PROVIDER_STATUS", "NOT_VERIFIED_IN_RECENT_SCAN",
                                "DORMANCY_PERIOD_EXCEEDED", "INTEGRITY_CONCERN",
                                "SOURCE_REPORTED_DELETED"},
    "AGENT_IDENTITY_RESOLVED": {"DUPLICATE_IDENTITY_MERGED"},
}
PAYLOAD_KEYS = {
    "AGENT_DISCOVERED": {"lifecycle_state", "source_reference"},
    "AGENT_METADATA_UPDATED": {"previous_metadata_version"},
    "AGENT_LIFECYCLE_CHANGED": {"previous_state", "new_state", "previous_metadata_version"},
    "AGENT_IDENTITY_RESOLVED": {"previous_metadata_version", "resolution", "surviving_agent_id",
                                "retired_agent_ids", "matched_on"},
}
SCAN_BASE_KEYS = {"scan_status", "trigger", "started_at", "completed_at", "agents_observed",
                  "agents_new", "agents_updated", "sources"}
SOURCE_REF_KEYS = {"source_type", "external_id", "first_observed_at", "last_observed_at", "scan_id"}
SOURCE_ENTRY_KEYS = {"source_type", "status", "agents_observed", "failure_category", "source_error_code"}
SCAN_FAILED_EXTRA_KEYS = {"failure_category", "scan_error_code"}
# B2 renames: old name -> new name (used to give a precise finding if the old name appears)
B2_RENAMES = {"sources[]": ("error_code", "source_error_code"), "scan level": ("error_code", "scan_error_code")}

_U = r"[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}"
UUID4_RE = re.compile("^" + _U + "$")
AGENT_RE = re.compile("^agt_" + _U + "$")
TS_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$")

# Field Mapping v0.2 Section 9 secret patterns
SECRET_KEY_RE = re.compile(r"(password|secret|token|api[_-]?key|access[_-]?key|private[_-]?key|"
                           r"credential|authorization|connection[_-]?string)", re.I)
SECRET_VALUE_RES = [
    ("AWS access key", re.compile(r"\b(AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("private key block", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")),
    ("JWT", re.compile(r"\beyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}")),
    ("Bearer token", re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{8,}", re.I)),
    ("GitHub token", re.compile(r"\b(ghp|gho|ghs|ghu|github_pat)_[A-Za-z0-9_]{10,}")),
    ("connection-string password", re.compile(r"(password|pwd)\s*=\s*[^;\s]+", re.I)),
]


def _f(level, category, rule, message):
    return {"level": level, "category": category, "rule": rule, "message": message}


def _is_int(v):
    return isinstance(v, int) and not isinstance(v, bool)


def _ts_ok(v):
    """Strict format AND a real calendar date/time."""
    if not (isinstance(v, str) and TS_RE.match(v)):
        return False
    try:
        datetime.strptime(v, "%Y-%m-%dT%H:%M:%S.%fZ")
        return True
    except ValueError:
        return False


# ---------------------------------------------------------------- single event
def check_event(event):
    """Return a list of findings for one event (empty list = fully clean)."""
    out = []
    if not isinstance(event, dict):
        return [_f("FAIL", "ENVELOPE", "ENV-TYPE", "event is not a JSON object")]
    event = copy.deepcopy(event)
    if "_note" in event:                       # fixture-only comment in supplied samples
        out.append(_f("WARN", "ENVELOPE", "ENV-FIXTURE-NOTE",
                      "'_note' is a fixture-only field, not part of the contract; ignored below"))
        del event["_note"]

    missing = [k for k in ENVELOPE_FIELDS if k not in event and k != "event_id"]   # event_id may be omitted
    extra = [k for k in event if k not in ENVELOPE_FIELDS]
    if missing:
        out.append(_f("FAIL", "ENVELOPE", "ENV-MISSING", "missing envelope fields: %s" % missing))
    if extra:
        out.append(_f("FAIL", "ENVELOPE", "ENV-EXTRA", "unexpected envelope fields: %s" % extra))
    out += _check_secrets(event)
    if missing:
        return out                              # cannot check further safely

    et = event["event_type"]
    is_agent, is_scan = et in AGENT_TYPES, et in SCAN_TYPES
    if not (is_agent or is_scan):
        out.append(_f("FAIL", "ENVELOPE", "ENV-EVENT-TYPE", "unknown event_type %r" % (et,)))
        return out

    # constants / simple fields
    if event["schema_version"] != "0.2":
        out.append(_f("FAIL", "ENVELOPE", "ENV-SCHEMA", "schema_version must be '0.2'"))
    if event["source_module"] != "DISCOVERY":
        out.append(_f("FAIL", "ENVELOPE", "ENV-MODULE", "source_module must be 'DISCOVERY'"))
    if not (isinstance(event["tenant_id"], str) and event["tenant_id"]):
        out.append(_f("FAIL", "ENVELOPE", "ENV-TENANT", "tenant_id must be a non-empty string"))

    # ids
    for fld in ("source_system_ref", "correlation_id"):
        if not (isinstance(event[fld], str) and UUID4_RE.match(event[fld])):
            out.append(_f("FAIL", "ID", "ID-UUID4-" + fld.upper(),
                          "%s must be a lowercase UUID v4 (and correlation_id must not be null)" % fld))
    # B2: event_id is created by B2. Module 1 must leave it null (or omit the key).
    if event.get("event_id") is not None:
        out.append(_f("FAIL", "ID", "ID-EVENT-ID-NOT-NULL",
                      "event_id must not be populated by Module 1 (B2 creates it); use source_system_ref"))
    if is_agent:
        if not (isinstance(event["agent_id"], str) and AGENT_RE.match(event["agent_id"])):
            out.append(_f("FAIL", "ID", "ID-AGENT", "agent_id must be 'agt_' + lowercase UUID v4"))
        if not (_is_int(event["metadata_version"]) and event["metadata_version"] >= 1):
            out.append(_f("FAIL", "ENVELOPE", "ENV-VERSION", "agent events need integer metadata_version >= 1"))
        if event["scan_id"] is not None and not (isinstance(event["scan_id"], str) and event["scan_id"]):
            out.append(_f("FAIL", "ENVELOPE", "ENV-SCAN-ID", "scan_id must be a non-empty string or null"))
    else:
        if event["agent_id"] is not None or event["metadata_version"] is not None \
                or event["change_summary"] is not None:
            out.append(_f("FAIL", "ENVELOPE", "ENV-SCAN-NULLS",
                          "scan events must have agent_id, metadata_version and change_summary = null"))
        if not (isinstance(event["scan_id"], str) and event["scan_id"]):
            out.append(_f("FAIL", "ENVELOPE", "ENV-SCAN-ID", "scan events need a non-empty scan_id"))

    # time
    t_ok = {}
    for fld in ("occurred_at", "published_at"):
        t_ok[fld] = _ts_ok(event[fld])
        if not t_ok[fld]:
            out.append(_f("FAIL", "TIME", "TIME-" + fld.upper(),
                          "%s must be UTC ISO 8601 with milliseconds and 'Z'" % fld))
    if all(t_ok.values()) and event["published_at"] < event["occurred_at"]:
        out.append(_f("FAIL", "TIME", "TIME-PUB-BEFORE-OCC", "published_at must be >= occurred_at"))

    # payload
    if not isinstance(event["payload"], dict):
        out.append(_f("FAIL", "PAYLOAD", "PAY-TYPE", "payload must be an object"))
    elif is_agent:
        out += _check_agent(event)
    else:
        out += _check_scan(event)
    return out


def _check_agent(ev):
    out, et, p, cs = [], ev["event_type"], ev["payload"], ev["change_summary"]
    if set(p) != PAYLOAD_KEYS[et]:
        out.append(_f("FAIL", "PAYLOAD", "PAY-KEYS", "payload keys must be exactly %s, got %s"
                      % (sorted(PAYLOAD_KEYS[et]), sorted(p))))
        return out
    if not (isinstance(cs, dict) and set(cs) == {"reason_code", "changed_fields"}):
        out.append(_f("FAIL", "PAYLOAD", "PAY-CHANGE-SUMMARY",
                      "change_summary must have exactly reason_code and changed_fields"))
        return out
    if cs["reason_code"] not in REASONS[et]:
        out.append(_f("FAIL", "PAYLOAD", "PAY-REASON", "reason_code %r not allowed for %s"
                      % (cs["reason_code"], et)))
    cf = cs["changed_fields"]
    if not (isinstance(cf, list) and all(isinstance(x, str) and x for x in cf)):
        out.append(_f("FAIL", "PAYLOAD", "PAY-CHANGED-FIELDS", "changed_fields must be a list of field names"))
        return out
    ver = ev["metadata_version"]
    if et != "AGENT_DISCOVERED":
        pv = p["previous_metadata_version"]
        if not (_is_int(pv) and pv >= 1):
            out.append(_f("FAIL", "PAYLOAD", "PAY-PREV-VERSION", "previous_metadata_version must be an integer >= 1"))
        elif _is_int(ver) and ver != pv + 1:
            out.append(_f("FAIL", "PAYLOAD", "PAY-VERSION-STEP", "metadata_version must equal previous_metadata_version + 1"))

    if et == "AGENT_DISCOVERED":
        if p["lifecycle_state"] not in STATES:
            out.append(_f("FAIL", "PAYLOAD", "PAY-STATE", "lifecycle_state must be one of %s (UPPERCASE, never null)" % sorted(STATES)))
        if ver != 1:
            out.append(_f("FAIL", "PAYLOAD", "PAY-DISCOVERED-V1", "a newly discovered agent starts at metadata_version 1"))
        if cf != []:
            out.append(_f("FAIL", "PAYLOAD", "PAY-DISCOVERED-FIELDS", "changed_fields must be [] for AGENT_DISCOVERED"))
        sr = p["source_reference"]
        if not (isinstance(sr, dict) and set(sr) == SOURCE_REF_KEYS):
            out.append(_f("FAIL", "PAYLOAD", "PAY-SOURCE-REF", "source_reference must have exactly %s" % sorted(SOURCE_REF_KEYS)))
        else:
            if sr["source_type"] not in SOURCES:
                out.append(_f("FAIL", "PAYLOAD", "PAY-SOURCE-TYPE", "source_type must be one of %s" % sorted(SOURCES)))
            if not (isinstance(sr["external_id"], str) and sr["external_id"]):
                out.append(_f("FAIL", "PAYLOAD", "PAY-EXTERNAL-ID", "external_id must be a non-empty string"))
            if not (_ts_ok(sr["first_observed_at"]) and _ts_ok(sr["last_observed_at"])):
                out.append(_f("FAIL", "TIME", "TIME-SOURCE-REF", "source_reference timestamps must be UTC ms 'Z'"))
    elif et == "AGENT_METADATA_UPDATED":
        if not cf or "lifecycle_state" in cf:
            out.append(_f("FAIL", "PAYLOAD", "PAY-META-FIELDS", "changed_fields must be non-empty and exclude lifecycle_state"))
    elif et == "AGENT_LIFECYCLE_CHANGED":
        ps, ns = p["previous_state"], p["new_state"]
        for name, v in (("previous_state", ps), ("new_state", ns)):
            if v not in STATES:
                out.append(_f("FAIL", "PAYLOAD", "PAY-STATE", "%s must be one of %s (UPPERCASE)" % (name, sorted(STATES))))
        if ps == ns:
            out.append(_f("FAIL", "PAYLOAD", "PAY-STATE-SAME", "previous_state and new_state must differ"))
        if cf != ["lifecycle_state"]:
            out.append(_f("FAIL", "PAYLOAD", "PAY-LIFECYCLE-FIELDS", "changed_fields must be ['lifecycle_state']"))
        r = cs["reason_code"]
        if (ns == "DELETED") != (r == "SOURCE_REPORTED_DELETED"):
            out.append(_f("FAIL", "PAYLOAD", "PAY-DELETED-RULE",
                          "DELETED is only allowed with reason SOURCE_REPORTED_DELETED (never from a failed/partial scan)"))
        if r == "NOT_VERIFIED_IN_RECENT_SCAN" and ns != "UNREACHABLE":
            out.append(_f("FAIL", "PAYLOAD", "PAY-REASON-STATE", "NOT_VERIFIED_IN_RECENT_SCAN must lead to UNREACHABLE"))
        if r == "DORMANCY_PERIOD_EXCEEDED" and ns != "DORMANT":
            out.append(_f("FAIL", "PAYLOAD", "PAY-REASON-STATE", "DORMANCY_PERIOD_EXCEEDED must lead to DORMANT"))
        if r == "INTEGRITY_CONCERN" and ns != "QUARANTINED":
            out.append(_f("FAIL", "PAYLOAD", "PAY-REASON-STATE", "INTEGRITY_CONCERN must lead to QUARANTINED"))
    else:  # AGENT_IDENTITY_RESOLVED
        if p["resolution"] != "MERGED":
            out.append(_f("FAIL", "PAYLOAD", "PAY-RESOLUTION", "resolution must be 'MERGED'"))
        if p["surviving_agent_id"] != ev["agent_id"]:
            out.append(_f("FAIL", "PAYLOAD", "PAY-SURVIVOR", "surviving_agent_id must equal agent_id"))
        ret = p["retired_agent_ids"]
        if not (isinstance(ret, list) and ret and all(isinstance(r, str) and AGENT_RE.match(r) for r in ret)):
            out.append(_f("FAIL", "ID", "ID-RETIRED", "retired_agent_ids must be a non-empty list of valid agt_ IDs"))
        elif len(set(ret)) != len(ret) or p["surviving_agent_id"] in ret:
            out.append(_f("FAIL", "PAYLOAD", "PAY-RETIRED", "retired IDs must be unique and must not include the survivor"))
        mo = p["matched_on"]
        if not (isinstance(mo, list) and mo and all(isinstance(x, str) and x for x in mo)):
            out.append(_f("FAIL", "PAYLOAD", "PAY-MATCHED-ON", "matched_on must be a non-empty list of field names"))
    return out


def _check_scan(ev):
    out, et, p = [], ev["event_type"], ev["payload"]
    keys = SCAN_BASE_KEYS | (SCAN_FAILED_EXTRA_KEYS if et == "DISCOVERY_SCAN_FAILED" else set())
    if "error_code" in p:
        out.append(_f("FAIL", "PAYLOAD", "B2-SCAN-ERROR-CODE",
                      "scan-level 'error_code' was renamed to 'scan_error_code' (latest B2 feedback)"))
    if set(p) != keys:
        out.append(_f("FAIL", "PAYLOAD", "PAY-KEYS", "scan payload keys must be exactly %s, got %s" % (sorted(keys), sorted(p))))
        return out
    if p["scan_status"] != SCAN_TYPES[et]:
        out.append(_f("FAIL", "PAYLOAD", "PAY-SCAN-STATUS", "scan_status must be %s for %s, got %r"
                      % (SCAN_TYPES[et], et, p["scan_status"])))
    if p["trigger"] not in ("SCHEDULED", "ON_DEMAND"):
        out.append(_f("FAIL", "PAYLOAD", "PAY-TRIGGER", "trigger must be SCHEDULED or ON_DEMAND"))
    ok_t = _ts_ok(p["started_at"]) and _ts_ok(p["completed_at"])
    if not ok_t:
        out.append(_f("FAIL", "TIME", "TIME-SCAN", "started_at/completed_at must be UTC ms 'Z'"))
    else:
        if p["completed_at"] < p["started_at"]:
            out.append(_f("FAIL", "TIME", "TIME-SCAN-ORDER", "completed_at must not be before started_at"))
        if _ts_ok(ev["occurred_at"]) and ev["occurred_at"] != p["completed_at"]:
            out.append(_f("WARN", "TIME", "TIME-OCC-NE-COMPLETED",
                          "scan occurred_at normally equals payload.completed_at (all supplied samples do)"))
    for k in ("agents_observed", "agents_new", "agents_updated"):
        if not (_is_int(p[k]) and p[k] >= 0):
            out.append(_f("FAIL", "PAYLOAD", "PAY-COUNT", "%s must be an integer >= 0" % k))
    if et == "DISCOVERY_SCAN_FAILED":
        if p["failure_category"] not in CATEGORIES or not (isinstance(p["scan_error_code"], str) and p["scan_error_code"]):
            out.append(_f("FAIL", "PAYLOAD", "PAY-SCAN-FAILURE", "FAILED scan needs failure_category (B2 list) and scan_error_code"))
        elif (p["failure_category"], p["scan_error_code"]) not in KNOWN_FAILURES:
            out.append(_f("WARN", "PAYLOAD", "PAY-UNSPECIFIED-CODE", "failure pair not in contract 6.1 table"))
    srcs = p["sources"]
    if not (isinstance(srcs, list) and srcs):
        out.append(_f("FAIL", "PAYLOAD", "PAY-SOURCES", "sources must be a non-empty list"))
        return out
    ok = bad = 0
    malformed = False            # a malformed entry makes the distinct-count range unknowable
    ok_counts, all_sum, seen = [], 0, set()
    for i, s in enumerate(srcs):
        w = "sources[%d]" % i
        if isinstance(s, dict) and "error_code" in s:
            out.append(_f("FAIL", "PAYLOAD", "B2-SOURCE-ERROR-CODE",
                          "%s: 'error_code' was renamed to 'source_error_code' (latest B2 feedback)" % w))
        if not (isinstance(s, dict) and set(s) == SOURCE_ENTRY_KEYS):
            out.append(_f("FAIL", "PAYLOAD", "PAY-SOURCE-KEYS", "%s must have exactly %s" % (w, sorted(SOURCE_ENTRY_KEYS))))
            malformed = True
            continue
        if s["source_type"] not in SOURCES:
            out.append(_f("FAIL", "PAYLOAD", "PAY-SOURCE-TYPE", "%s.source_type must be one of %s" % (w, sorted(SOURCES))))
        if s["source_type"] in seen:
            out.append(_f("FAIL", "PAYLOAD", "PAY-SOURCE-DUP", "%s duplicates source_type %s" % (w, s["source_type"])))
        seen.add(s["source_type"])
        if not (_is_int(s["agents_observed"]) and s["agents_observed"] >= 0):
            out.append(_f("FAIL", "PAYLOAD", "PAY-COUNT", "%s.agents_observed must be an integer >= 0" % w))
            malformed = True
            continue
        all_sum += s["agents_observed"]
        if s["status"] == "SUCCEEDED":
            ok += 1
            ok_counts.append(s["agents_observed"])
            if s["failure_category"] is not None or s["source_error_code"] is not None:
                out.append(_f("FAIL", "PAYLOAD", "PAY-SOURCE-OK-NULLS", "%s succeeded: failure fields must be null" % w))
        elif s["status"] == "FAILED":
            bad += 1
            if s["failure_category"] not in CATEGORIES or not s["source_error_code"]:
                out.append(_f("FAIL", "PAYLOAD", "PAY-SOURCE-FAILURE", "%s failed: needs failure_category and source_error_code" % w))
            elif (s["failure_category"], s["source_error_code"]) not in KNOWN_FAILURES:
                out.append(_f("WARN", "PAYLOAD", "PAY-UNSPECIFIED-CODE", "%s failure pair not in contract 6.1 table" % w))
            if s["agents_observed"] != 0:
                out.append(_f("FAIL", "PAYLOAD", "PAY-SOURCE-FAILED-COUNT", "%s failed: agents_observed must be 0" % w))
        else:
            out.append(_f("FAIL", "PAYLOAD", "PAY-SOURCE-STATUS", "%s.status must be SUCCEEDED or FAILED" % w))
    if et == "DISCOVERY_SCAN_COMPLETED" and bad:
        out.append(_f("FAIL", "PAYLOAD", "PAY-COMPLETED-NEEDS-ALL-OK", "COMPLETED requires every source to succeed"))
    if et == "DISCOVERY_SCAN_PARTIAL" and not malformed and not (ok and bad):
        out.append(_f("FAIL", "PAYLOAD", "PAY-PARTIAL-MIX", "PARTIAL requires at least one succeeded and one failed source"))
    # agents_observed is DISTINCT across sources: max(source) <= total <= sum(sources)
    if _is_int(p["agents_observed"]) and not malformed:
        lo = max(ok_counts) if ok_counts else 0
        if not (lo <= p["agents_observed"] <= all_sum):
            out.append(_f("FAIL", "PAYLOAD", "PAY-OBSERVED-RANGE",
                          "agents_observed=%s outside possible distinct range %s..%s" % (p["agents_observed"], lo, all_sum)))
    return out


def _check_secrets(obj, path="event"):
    """Look for secret-like keys/values. Only the LOCATION is reported."""
    out = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            here = "%s.%s" % (path, k)
            if isinstance(k, str) and SECRET_KEY_RE.search(k):
                out.append(_f("FAIL", "SECRET", "SECRET-KEY", "secret-like key at %s" % here))
            out += _check_secrets(v, here)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            out += _check_secrets(v, "%s[%d]" % (path, i))
    elif isinstance(obj, str):
        for label, rx in SECRET_VALUE_RES:
            if rx.search(obj):
                out.append(_f("FAIL", "SECRET", "SECRET-VALUE", "%s-looking value at %s" % (label, path)))
    return out


# ---------------------------------------------------------------- across events
def check_scan_groups(events, ordered=False):
    """Checks that need several events. Returns {(tenant, scan_id): [findings]}.
    ordered=True means the list is in publish order, so the terminal event must be last."""
    results = {}
    groups = defaultdict(list)
    for idx, e in enumerate(events):
        if isinstance(e, dict) and e.get("scan_id") and e.get("tenant_id"):
            groups[(e["tenant_id"], e["scan_id"])].append((idx, e))
    for key, items in groups.items():
        out = []
        terms = [(i, e) for i, e in items if e.get("event_type") in SCAN_TYPES]
        agents = [(i, e) for i, e in items if e.get("event_type") in AGENT_TYPES]
        if len(terms) > 1:
            out.append(_f("FAIL", "GROUP", "GROUP-ONE-TERMINAL",
                          "%d terminal events for one scan (exactly one allowed)" % len(terms)))
        elif not terms:
            out.append(_f("WARN", "GROUP", "GROUP-NO-TERMINAL",
                          "no terminal scan event in the supplied set for this scan (cannot confirm 'exactly one')"))
        if len({e.get("correlation_id") for _, e in items}) > 1:
            out.append(_f("FAIL", "GROUP", "GROUP-CORRELATION", "events of one scan must share one correlation_id"))
        if terms:
            _, t = terms[0]
            tp = t.get("payload") or {}
            new_ids = {a.get("agent_id") for _, a in agents if a.get("event_type") == "AGENT_DISCOVERED"}
            upd_ids = {a.get("agent_id") for _, a in agents if a.get("event_type") != "AGENT_DISCOVERED"} - new_ids
            if _is_int(tp.get("agents_new")) and _is_int(tp.get("agents_updated")) \
                    and (tp["agents_new"] != len(new_ids) or tp["agents_updated"] != len(upd_ids)):
                out.append(_f("WARN", "GROUP", "GROUP-COUNTS-VS-EVENTS",
                              "terminal says agents_new=%s agents_updated=%s but the supplied agent events show %d new / %d updated "
                              "(the supplied set may be incomplete)" % (tp["agents_new"], tp["agents_updated"],
                                                                        len(new_ids), len(upd_ids))))
            for _, a in agents:
                if isinstance(a.get("occurred_at"), str) and isinstance(t.get("occurred_at"), str) \
                        and a["occurred_at"] > t["occurred_at"]:
                    out.append(_f("FAIL", "GROUP", "GROUP-TERMINAL-LAST",
                                  "agent event occurred after the terminal event"))
            if ordered and items[-1][1] is not terms[-1][1]:
                out.append(_f("FAIL", "GROUP", "GROUP-TERMINAL-LAST", "terminal event is not last in publish order"))
            status = (t.get("payload") or {}).get("scan_status")
            for _, a in agents:
                if a.get("event_type") != "AGENT_LIFECYCLE_CHANGED":
                    continue
                pl, r = a.get("payload") or {}, (a.get("change_summary") or {}).get("reason_code")
                risky = pl.get("new_state") == "DELETED" or r in ("SOURCE_REPORTED_DELETED", "NOT_VERIFIED_IN_RECENT_SCAN")
                if status == "FAILED" and risky:
                    out.append(_f("FAIL", "GROUP", "GROUP-FAILED-SCAN-NO-DELETE",
                                  "a FAILED scan must not produce DELETED/UNREACHABLE changes (agent %s)" % a.get("agent_id")))
                elif status == "PARTIAL" and pl.get("new_state") == "DELETED":
                    out.append(_f("WARN", "GROUP", "GROUP-PARTIAL-DELETE-REVIEW",
                                  "DELETED inside a PARTIAL scan: confirm it came from a source that succeeded"))
        results[key] = out
    return results


def check_batch_integrity(events):
    """Duplicate refs, per-agent version rules. Returns a flat list of findings."""
    out = []
    by_ref = defaultdict(list)
    by_ver = defaultdict(list)
    for e in events:
        if not isinstance(e, dict):
            continue
        by_ref[e.get("source_system_ref")].append(e)
        if e.get("event_type") in AGENT_TYPES:
            by_ver[(e.get("tenant_id"), e.get("agent_id"), e.get("metadata_version"))].append(e)
    for ref, evs in by_ref.items():
        if len(evs) > 1:
            base = {k: v for k, v in evs[0].items() if k not in ("published_at", "_note")}
            if any({k: v for k, v in o.items() if k not in ("published_at", "_note")} != base for o in evs[1:]):
                out.append(_f("FAIL", "GROUP", "GROUP-DUPLICATE-REF",
                              "source_system_ref %s reused by DIFFERENT events (must be unique per event)" % ref))
    for key, evs in by_ver.items():
        if len({e["source_system_ref"] for e in evs}) > 1:
            out.append(_f("FAIL", "GROUP", "GROUP-ONE-EVENT-PER-VERSION",
                          "agent %s version %s has more than one event" % (key[1], key[2])))
    return out


def check_retries(deliveries):
    """deliveries: list of event copies as delivered (including retries).
    Same source_system_ref must mean identical event; only published_at may change."""
    out = []
    by_ref = defaultdict(list)
    for d in deliveries:
        by_ref[d.get("source_system_ref")].append(d)
    for ref, copies in by_ref.items():
        if len(copies) < 2:
            continue
        base = {k: v for k, v in copies[0].items() if k != "published_at"}
        for c in copies[1:]:
            diff = [k for k in set(base) | set(c) if k != "published_at" and base.get(k) != c.get(k)]
            if diff:
                out.append(_f("FAIL", "RETRY", "RETRY-IDENTICAL",
                              "retry of %s changed %s (only published_at may change)" % (ref, sorted(diff))))
    return out


# ---------------------------------------------------------------- batch + files
def find_events(obj):
    """Collect every event dict found anywhere inside a loaded JSON value."""
    found = []
    if isinstance(obj, dict):
        if "event_type" in obj and ("source_system_ref" in obj or "payload" in obj):
            found.append(obj)
        else:
            for v in obj.values():
                found += find_events(v)
    elif isinstance(obj, list):
        for v in obj:
            found += find_events(v)
    return found


def validate_batch(events, ordered=False):
    """Run every check. Returns dict with per-event results and cross-event findings."""
    per_event = []
    for i, e in enumerate(events):
        f = check_event(e)
        per_event.append({"index": i,
                          "event_type": e.get("event_type") if isinstance(e, dict) else None,
                          "source_system_ref": e.get("source_system_ref") if isinstance(e, dict) else None,
                          "findings": f,
                          "passed": not any(x["level"] == "FAIL" for x in f)})
    groups = check_scan_groups(events, ordered=ordered)
    cross = check_batch_integrity(events)
    failed = (not all(p["passed"] for p in per_event)
              or any(x["level"] == "FAIL" for g in groups.values() for x in g)
              or any(x["level"] == "FAIL" for x in cross))
    return {"per_event": per_event, "groups": groups, "cross": cross, "passed": not failed}


def main(argv):
    ordered = "--ordered" in argv
    paths = [a for a in argv if not a.startswith("--")]
    if not paths:
        print(__doc__)
        return 2
    any_fail = False
    for path in paths:
        try:
            with open(path, encoding="utf-8") as fh:
                events = find_events(json.load(fh))
        except (OSError, ValueError) as exc:
            print("%s: cannot read (%s)" % (path, exc))
            return 2
        res = validate_batch(events, ordered=ordered)
        print("== %s: %d event(s)" % (path, len(events)))
        for p in res["per_event"]:
            print("  [%s] #%d %s %s" % ("PASS" if p["passed"] else "FAIL", p["index"],
                                        p["event_type"], p["source_system_ref"]))
            for f in p["findings"]:
                print("        %s %s: %s" % (f["level"], f["rule"], f["message"]))
        for key, fs in res["groups"].items():
            for f in fs:
                print("  scan %s/%s  %s %s: %s" % (key[0], key[1], f["level"], f["rule"], f["message"]))
        for f in res["cross"]:
            print("  batch  %s %s: %s" % (f["level"], f["rule"], f["message"]))
        any_fail = any_fail or not res["passed"]
    return 1 if any_fail else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

"""
discovery_events.py - A1 Discovery Event Producer (replaces the build's NotImplementedError scaffold)

Implements the producer side of "A1 Discovery Event Contract - Draft v0.2" as encoded in the supplied official
samples (the contract document itself was not supplied):
  * the 7 event types              (contract Section 3)
  * the common envelope            (Section 4)
  * agent / scan payloads          (Sections 5, 6) and failure mapping (6.1)
  * delivery rules                 (Section 7)

Integration with the week_2 build (src/ingest.py + src/lifecycle.py, both UNMODIFIED), following the build's
INTEGRATION_HANDOFF.md "Hook points / Gautham":
  `InventoryObserver` calls the reusable inventory operations (ingest, mark_unverified, quarantine_existing), takes a
  deep-copy snapshot before and after, and `diff_records` turns the committed difference into an `InventoryChange`
  (same dataclass as the build's scaffold). `InventoryEventBridge` buffers it and `ScanEventSession` publishes it once
  the source result is known; `finish()` emits exactly one terminal scan event, last.
  agent_id and metadata_version are copied from the STORED record; they are NEVER generated or counted here.
  This module imports nothing from ingest.py / lifecycle.py.

B2 feedback applied (as stated by the module owner / task):
  1. event_id is NOT included at all (B2 creates it). Module 1's own identifier travels in source_system_ref.
  2. sources[].error_code  ->  sources[].source_error_code      (inside sources[])
  3. scan-level error_code ->  scan_error_code                   (scan level, DISCOVERY_SCAN_FAILED only)

Standard library only. Tested on Python 3.13.18 only.
"""

from __future__ import annotations

import copy
import re
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Iterable, List, Optional

# --------------------------------------------------------------------------
# Constants taken straight from the contract / Field Mapping v0.2
# --------------------------------------------------------------------------
SCHEMA_VERSION = "0.2"                       # contract Section 4
SOURCE_MODULE = "DISCOVERY"                  # contract Section 4

AGENT_DISCOVERED = "AGENT_DISCOVERED"
AGENT_METADATA_UPDATED = "AGENT_METADATA_UPDATED"
AGENT_LIFECYCLE_CHANGED = "AGENT_LIFECYCLE_CHANGED"
AGENT_IDENTITY_RESOLVED = "AGENT_IDENTITY_RESOLVED"
DISCOVERY_SCAN_COMPLETED = "DISCOVERY_SCAN_COMPLETED"
DISCOVERY_SCAN_PARTIAL = "DISCOVERY_SCAN_PARTIAL"
DISCOVERY_SCAN_FAILED = "DISCOVERY_SCAN_FAILED"

AGENT_EVENT_TYPES = (AGENT_DISCOVERED, AGENT_METADATA_UPDATED,
                     AGENT_LIFECYCLE_CHANGED, AGENT_IDENTITY_RESOLVED)
SCAN_EVENT_TYPES = (DISCOVERY_SCAN_COMPLETED, DISCOVERY_SCAN_PARTIAL,
                    DISCOVERY_SCAN_FAILED)
ALL_EVENT_TYPES = AGENT_EVENT_TYPES + SCAN_EVENT_TYPES

LIFECYCLE_STATES = ("ACTIVE", "UNREACHABLE", "DORMANT", "DELETED", "QUARANTINED")
# Field Mapping 4: approved list is itself an OPEN item - extend here when approved.
APPROVED_SOURCE_TYPES = ("AWS_BEDROCK", "AZURE_AI_FOUNDRY")
TRIGGERS = ("SCHEDULED", "ON_DEMAND")
FAILURE_CATEGORIES = ("ERROR", "TIMEOUT", "UNAVAILABLE", "INCOMPLETE_RESPONSE")

LIFECYCLE_REASON_CODES = ("PROVIDER_STATUS", "NOT_VERIFIED_IN_RECENT_SCAN",
                          "DORMANCY_PERIOD_EXCEEDED", "INTEGRITY_CONCERN",
                          "SOURCE_REPORTED_DELETED")

# Names of fields that may appear in change_summary.changed_fields (names only,
# never values). Taken from Field Mapping v0.2 Section 5.
TRACKED_FIELDS = ("source_references", "lifecycle_state", "name", "owner_id",
                  "purpose", "creation_date", "connected_tools", "access_scope",
                  "metadata", "autonomy_level", "risk_score", "metadata_confidence")

ENVELOPE_KEYS = ("event_id", "source_system_ref", "schema_version", "event_type",
                 "source_module", "tenant_id", "correlation_id", "scan_id",
                 "occurred_at", "published_at", "agent_id", "metadata_version",
                 "change_summary", "payload")

# event_id is created by B2, never by Module 1, and the task says it must NOT be included:
# the key is ABSENT from every event this producer emits ("OMIT", the default). "NULL" (key
# present, value null) is kept only as a switch in case B2 asks for it; the validator accepts
# both but rejects any populated event_id.
EVENT_ID_MODE = "OMIT"

# Contract Section 6.1: situation -> (failure_category, error_code).
# These pairs keep the contract's term "error_code" internally; in the emitted payload the
# code is named source_error_code (inside sources[]) or scan_error_code (scan level).
FAILURE_MAP = {
    "INVALID_CREDENTIALS":    ("ERROR", "AUTH_ERROR"),
    "INSUFFICIENT_PERMISSIONS": ("ERROR", "PERMISSION_DENIED"),
    "SOURCE_TIMEOUT":         ("TIMEOUT", "SOURCE_TIMEOUT"),
    "SCAN_TIMEOUT":           ("TIMEOUT", "SCAN_TIMEOUT"),
    "SOURCE_UNAVAILABLE":     ("UNAVAILABLE", "SOURCE_UNAVAILABLE"),
    "INCOMPLETE_RESPONSE":    ("INCOMPLETE_RESPONSE", "INCOMPLETE_RESPONSE"),
}

_UUID4 = r"[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}"
_UUID4_RE = re.compile("^" + _UUID4 + "$")
_AGENT_ID_RE = re.compile("^agt_" + _UUID4 + "$")      # Field Mapping 5 pattern
_TS_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$")

Clock = Callable[[], datetime]


class EventValidationError(ValueError):
    """An event does not follow the contract. .problems lists every issue."""

    def __init__(self, problems: List[str]):
        self.problems = problems
        super().__init__("; ".join(problems))


class UnmappedFailureError(KeyError):
    """A failure situation has no mapping in contract Section 6.1."""


class LifecycleRuleError(ValueError):
    """A requested lifecycle event would break the 'failed scan != DELETED' rules."""


# --------------------------------------------------------------------------
# Small helpers: IDs and timestamps
# --------------------------------------------------------------------------
def new_uuid4() -> str:
    """Lowercase UUID v4 string (used for correlation_id and source_system_ref ONLY;
    agent IDs are created by the inventory, ingest.new_agent_id)."""
    return str(uuid.uuid4())


def is_valid_uuid4(value: Any) -> bool:
    return isinstance(value, str) and bool(_UUID4_RE.match(value))


def is_valid_agent_id(value: Any) -> bool:
    return isinstance(value, str) and bool(_AGENT_ID_RE.match(value))


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def format_utc(dt: datetime) -> str:
    """UTC ISO 8601 with milliseconds and 'Z', e.g. 2026-11-23T09:00:03.000Z."""
    if dt.tzinfo is None:
        raise ValueError("naive datetime refused: a timezone is required")
    dt = dt.astimezone(timezone.utc)
    return dt.strftime("%Y-%m-%dT%H:%M:%S.") + "%03dZ" % (dt.microsecond // 1000)


def is_valid_timestamp(value: Any) -> bool:
    return isinstance(value, str) and bool(_TS_RE.match(value))


def map_failure(situation: str) -> Dict[str, str]:
    """Apply the contract 6.1 failure mapping. Unknown situations are refused
    (we do not invent codes - B2 owns the final list)."""
    try:
        category, code = FAILURE_MAP[situation]
    except KeyError:
        raise UnmappedFailureError(
            "No failure mapping for %r. Known situations: %s"
            % (situation, ", ".join(sorted(FAILURE_MAP))))
    return {"failure_category": category, "error_code": code}


# --------------------------------------------------------------------------
# Envelope builder (Section 4)
# --------------------------------------------------------------------------
def build_event(*, event_type: str, tenant_id: str, correlation_id: str,
                scan_id: Optional[str], occurred_at: Optional[str],
                payload: Dict[str, Any], agent_id: Optional[str] = None,
                metadata_version: Optional[int] = None,
                change_summary: Optional[Dict[str, Any]] = None,
                source_system_ref: Optional[str] = None,
                uuid_factory: Callable[[], str] = new_uuid4) -> Dict[str, Any]:
    """Build one envelope. source_system_ref is Module 1's own event identifier (UUID v4).
    event_id is NOT included (B2 creates it): omitted when EVENT_ID_MODE == "OMIT" (default), else null.
    published_at is left None; the publisher sets it at delivery time."""
    ref = source_system_ref or uuid_factory()
    event = {
        "event_id": None,
        "source_system_ref": ref,
        "schema_version": SCHEMA_VERSION,
        "event_type": event_type,
        "source_module": SOURCE_MODULE,
        "tenant_id": tenant_id,
        "correlation_id": correlation_id,
        "scan_id": scan_id,
        "occurred_at": occurred_at,
        "published_at": None,
        "agent_id": agent_id,
        "metadata_version": metadata_version,
        "change_summary": change_summary,
        "payload": payload,
    }
    if EVENT_ID_MODE == "OMIT":
        del event["event_id"]
    return event


# --------------------------------------------------------------------------
# Validation (Sections 4, 5, 6) - strict key sets also keep secrets out
# --------------------------------------------------------------------------
def _is_int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool)


def _check_source_reference(ref: Any, errs: List[str], where: str) -> None:
    keys = {"source_type", "external_id", "first_observed_at",
            "last_observed_at", "scan_id"}
    if not isinstance(ref, dict) or set(ref) != keys:
        errs.append("%s must have exactly keys %s" % (where, sorted(keys)))
        return
    if ref["source_type"] not in APPROVED_SOURCE_TYPES:
        errs.append("%s.source_type not approved" % where)
    if not (isinstance(ref["external_id"], str) and ref["external_id"]):
        errs.append("%s.external_id must be a non-empty string" % where)
    for k in ("first_observed_at", "last_observed_at"):
        if not is_valid_timestamp(ref[k]):
            errs.append("%s.%s must be UTC ms 'Z' timestamp" % (where, k))
    if not (isinstance(ref["scan_id"], str) and ref["scan_id"]):
        errs.append("%s.scan_id must be a non-empty string" % where)


def _check_scan_payload(event: Dict[str, Any], errs: List[str]) -> None:
    p = event["payload"]
    et = event["event_type"]
    status_for = {DISCOVERY_SCAN_COMPLETED: "SUCCEEDED",
                  DISCOVERY_SCAN_PARTIAL: "PARTIAL",
                  DISCOVERY_SCAN_FAILED: "FAILED"}[et]
    base = {"scan_status", "trigger", "started_at", "completed_at",
            "agents_observed", "agents_new", "agents_updated", "sources"}
    keys = base | ({"failure_category", "scan_error_code"} if et == DISCOVERY_SCAN_FAILED else set())
    if set(p) != keys:
        errs.append("scan payload keys must be exactly %s" % sorted(keys))
        return
    if p["scan_status"] != status_for:
        errs.append("scan_status must be %s for %s" % (status_for, et))
    if p["trigger"] not in TRIGGERS:
        errs.append("trigger must be one of %s" % (TRIGGERS,))
    for k in ("started_at", "completed_at"):
        if not is_valid_timestamp(p[k]):
            errs.append("payload.%s must be UTC ms 'Z' timestamp" % k)
    if is_valid_timestamp(p["completed_at"]) and p["completed_at"] != event["occurred_at"]:
        errs.append("scan event occurred_at must equal payload.completed_at")
    for k in ("agents_observed", "agents_new", "agents_updated"):
        if not (_is_int(p[k]) and p[k] >= 0):
            errs.append("payload.%s must be an integer >= 0" % k)
    if et == DISCOVERY_SCAN_FAILED:
        if p["failure_category"] not in FAILURE_CATEGORIES:
            errs.append("FAILED scan needs a valid failure_category")
        if not (isinstance(p["scan_error_code"], str) and p["scan_error_code"]):
            errs.append("FAILED scan needs a scan_error_code")
    srcs = p["sources"]
    if not isinstance(srcs, list) or not srcs:
        errs.append("payload.sources must be a non-empty list")
        return
    src_keys = {"source_type", "status", "agents_observed", "failure_category", "source_error_code"}
    ok, bad = 0, 0
    for i, s in enumerate(srcs):
        w = "sources[%d]" % i
        if not isinstance(s, dict) or set(s) != src_keys:
            errs.append("%s must have exactly keys %s" % (w, sorted(src_keys)))
            continue
        if s["source_type"] not in APPROVED_SOURCE_TYPES:
            errs.append("%s.source_type not approved" % w)
        if not (_is_int(s["agents_observed"]) and s["agents_observed"] >= 0):
            errs.append("%s.agents_observed must be an integer >= 0" % w)
        if s["status"] == "SUCCEEDED":
            ok += 1
            if s["failure_category"] is not None or s["source_error_code"] is not None:
                errs.append("%s succeeded: failure fields must be null" % w)
        elif s["status"] == "FAILED":
            bad += 1
            if s["failure_category"] not in FAILURE_CATEGORIES or not s["source_error_code"]:
                errs.append("%s failed: needs failure_category and source_error_code" % w)
            if s["agents_observed"] != 0:
                errs.append("%s failed: agents_observed must be 0" % w)
        else:
            errs.append("%s.status must be SUCCEEDED or FAILED" % w)
    if et == DISCOVERY_SCAN_COMPLETED and bad:
        errs.append("COMPLETED requires every source to have succeeded")
    if et == DISCOVERY_SCAN_PARTIAL and not (ok and bad):
        errs.append("PARTIAL requires >=1 succeeded and >=1 failed source")
    if et == DISCOVERY_SCAN_FAILED and ok and p["scan_error_code"] is None:
        errs.append("FAILED with a succeeded source needs a scan-level failure")


def _check_agent_payload(event: Dict[str, Any], errs: List[str]) -> None:
    et, p, cs = event["event_type"], event["payload"], event["change_summary"]
    ver = event["metadata_version"]
    if not isinstance(cs, dict) or set(cs) != {"reason_code", "changed_fields"}:
        errs.append("change_summary must have exactly reason_code and changed_fields")
        return
    fields = cs["changed_fields"]
    if not (isinstance(fields, list) and all(f in TRACKED_FIELDS for f in fields)):
        errs.append("changed_fields must list known field NAMES only")
        return
    reason = cs["reason_code"]

    def prev_ok(expected_keys):
        if set(p) != set(expected_keys):
            errs.append("payload keys must be exactly %s" % sorted(expected_keys))
            return False
        pv = p["previous_metadata_version"]
        if not (_is_int(pv) and pv >= 1):
            errs.append("previous_metadata_version must be an integer >= 1")
            return False
        if _is_int(ver) and ver != pv + 1:
            errs.append("metadata_version must be previous_metadata_version + 1")
        return True

    if et == AGENT_DISCOVERED:
        if set(p) != {"lifecycle_state", "source_reference"}:
            errs.append("payload keys must be exactly ['lifecycle_state', 'source_reference']")
            return
        if reason != "NEW_AGENT_OBSERVED":
            errs.append("reason_code must be NEW_AGENT_OBSERVED")
        if fields != []:
            errs.append("AGENT_DISCOVERED changed_fields must be []")
        if ver != 1:
            errs.append("AGENT_DISCOVERED metadata_version must be 1")
        if p["lifecycle_state"] not in LIFECYCLE_STATES:
            errs.append("lifecycle_state must be one of %s (never null)" % (LIFECYCLE_STATES,))
        _check_source_reference(p["source_reference"], errs, "payload.source_reference")

    elif et == AGENT_METADATA_UPDATED:
        if not prev_ok({"previous_metadata_version"}):
            return
        if reason != "SOURCE_METADATA_CHANGED":
            errs.append("reason_code must be SOURCE_METADATA_CHANGED")
        if not fields or "lifecycle_state" in fields:
            errs.append("changed_fields must be non-empty and must not contain lifecycle_state")

    elif et == AGENT_LIFECYCLE_CHANGED:
        if not prev_ok({"previous_state", "new_state", "previous_metadata_version"}):
            return
        if reason not in LIFECYCLE_REASON_CODES:
            errs.append("reason_code must be one of %s" % (LIFECYCLE_REASON_CODES,))
        if fields != ["lifecycle_state"]:
            errs.append("changed_fields must be ['lifecycle_state']")
        for k in ("previous_state", "new_state"):
            if p[k] not in LIFECYCLE_STATES:
                errs.append("payload.%s must be one of %s" % (k, LIFECYCLE_STATES))
        if p["previous_state"] == p["new_state"]:
            errs.append("previous_state and new_state must differ")
        # Rule: nothing becomes DELETED unless the source itself reported it.
        if (p["new_state"] == "DELETED") != (reason == "SOURCE_REPORTED_DELETED"):
            errs.append("DELETED is allowed only with reason SOURCE_REPORTED_DELETED (and vice versa)")
        if reason == "NOT_VERIFIED_IN_RECENT_SCAN" and p["new_state"] != "UNREACHABLE":
            errs.append("NOT_VERIFIED_IN_RECENT_SCAN must lead to UNREACHABLE")
        if reason == "DORMANCY_PERIOD_EXCEEDED" and p["new_state"] != "DORMANT":
            errs.append("DORMANCY_PERIOD_EXCEEDED must lead to DORMANT")
        if reason == "INTEGRITY_CONCERN" and p["new_state"] != "QUARANTINED":
            errs.append("INTEGRITY_CONCERN must lead to QUARANTINED")

    elif et == AGENT_IDENTITY_RESOLVED:
        keys = {"previous_metadata_version", "resolution", "surviving_agent_id",
                "retired_agent_ids", "matched_on"}
        if not prev_ok(keys):
            return
        if reason != "DUPLICATE_IDENTITY_MERGED":
            errs.append("reason_code must be DUPLICATE_IDENTITY_MERGED")
        if p["resolution"] != "MERGED":
            errs.append("resolution must be MERGED")
        if p["surviving_agent_id"] != event["agent_id"]:
            errs.append("surviving_agent_id must equal agent_id")
        ret = p["retired_agent_ids"]
        if not (isinstance(ret, list) and ret and all(is_valid_agent_id(r) for r in ret)
                and len(set(ret)) == len(ret) and p["surviving_agent_id"] not in ret):
            errs.append("retired_agent_ids must be unique valid agt_ IDs, not the survivor")
        mo = p["matched_on"]
        if not (isinstance(mo, list) and mo and all(isinstance(x, str) and x for x in mo)):
            errs.append("matched_on must be a non-empty list of field names")


def validate_event(event: Dict[str, Any], require_published: bool = True) -> None:
    """Raise EventValidationError if the event breaks the contract."""
    errs: List[str] = []
    allowed = (set(ENVELOPE_KEYS), set(ENVELOPE_KEYS) - {"event_id"})   # event_id: null or omitted
    if not isinstance(event, dict) or set(event) not in allowed:
        raise EventValidationError(["envelope keys must be exactly %s (event_id may be omitted)"
                                    % (ENVELOPE_KEYS,)])
    et = event["event_type"]
    if et not in ALL_EVENT_TYPES:
        raise EventValidationError(["unknown event_type %r" % (et,)])
    if not is_valid_uuid4(event["source_system_ref"]):
        errs.append("source_system_ref must be a lowercase UUID v4")
    if event.get("event_id") is not None:
        errs.append("event_id must not be populated by Module 1 (B2 creates it)")
    if event["schema_version"] != SCHEMA_VERSION:
        errs.append("schema_version must be %r" % SCHEMA_VERSION)
    if event["source_module"] != SOURCE_MODULE:
        errs.append("source_module must be DISCOVERY")
    if not (isinstance(event["tenant_id"], str) and event["tenant_id"]):
        errs.append("tenant_id must be a non-empty string")
    if not is_valid_uuid4(event["correlation_id"]):
        errs.append("correlation_id must be a non-null lowercase UUID v4")
    if not is_valid_timestamp(event["occurred_at"]):
        errs.append("occurred_at must be UTC ISO 8601 with ms and Z")
    if event["published_at"] is None:
        if require_published:
            errs.append("published_at is missing")
    elif not is_valid_timestamp(event["published_at"]):
        errs.append("published_at must be UTC ISO 8601 with ms and Z")
    elif is_valid_timestamp(event["occurred_at"]) and event["published_at"] < event["occurred_at"]:
        errs.append("published_at must be >= occurred_at")
    if not isinstance(event["payload"], dict):
        errs.append("payload must be an object")
    if errs:
        raise EventValidationError(errs)

    if et in AGENT_EVENT_TYPES:
        if not is_valid_agent_id(event["agent_id"]):
            errs.append("agent_id must be agt_ + lowercase UUID v4")
        if not (_is_int(event["metadata_version"]) and event["metadata_version"] >= 1):
            errs.append("agent events need an integer metadata_version >= 1")
        if event["scan_id"] is not None and not (isinstance(event["scan_id"], str) and event["scan_id"]):
            errs.append("scan_id must be a non-empty string or null")
        if not errs:
            _check_agent_payload(event, errs)
    else:
        if event["agent_id"] is not None or event["metadata_version"] is not None \
                or event["change_summary"] is not None:
            errs.append("scan events need agent_id, metadata_version, change_summary = null")
        if not (isinstance(event["scan_id"], str) and event["scan_id"]):
            errs.append("scan events need a scan_id")
        if not errs:
            _check_scan_payload(event, errs)
    if errs:
        raise EventValidationError(errs)


# --------------------------------------------------------------------------
# Publisher: at-least-once delivery, identical retries, in-order outbox (Sec 7)
# --------------------------------------------------------------------------
class EventPublisher:
    """Hands events to a `sink` (a function that takes one event dict and raises
    on failure). The real transport belongs to B2 and is not decided yet, so the
    sink is injected rather than assumed.

    * Events wait in an in-order outbox, so a scan's terminal event can never
      overtake its agent events.
    * A retry resends the SAME event: same source_system_ref, occurred_at and
      payload. Only published_at is refreshed (and never earlier than occurred_at).
    * The outbox lives in memory only (like the prototype). A durable outbox is
      an open item for B2 transport / outage behaviour.
    """

    def __init__(self, sink: Callable[[Dict[str, Any]], None], clock: Clock = utc_now,
                 max_attempts: int = 3, backoff_seconds: float = 0.5,
                 sleep: Callable[[float], None] = time.sleep):
        self._sink = sink
        self._clock = clock
        self._max_attempts = max_attempts
        self._backoff = backoff_seconds
        self._sleep = sleep
        self.outbox: List[Dict[str, Any]] = []
        self.last_error: Optional[Exception] = None

    def submit(self, event: Dict[str, Any]) -> bool:
        """Queue an event and try to deliver everything waiting. True if the
        outbox is now empty."""
        validate_event(event, require_published=False)
        self.outbox.append(copy.deepcopy(event))
        return self.drain()

    def drain(self) -> bool:
        """Deliver waiting events in order; stop at the first one that fails."""
        while self.outbox:
            if not self._deliver(self.outbox[0]):
                return False
            self.outbox.pop(0)
        return True

    def _deliver(self, event: Dict[str, Any]) -> bool:
        for attempt in range(1, self._max_attempts + 1):
            out = copy.deepcopy(event)
            now = format_utc(self._clock())
            out["published_at"] = max(now, out["occurred_at"])   # always >= occurred_at
            validate_event(out)
            try:
                self._sink(out)
                return True
            except Exception as exc:                              # sink/transport problem
                self.last_error = exc
                if attempt < self._max_attempts:
                    self._sleep(self._backoff * (2 ** (attempt - 1)))
        return False


# --------------------------------------------------------------------------
# Scan session: the object the existing scan code talks to
# --------------------------------------------------------------------------
class ScanEventSession:
    """One discovery scan's worth of events.

    Typical flow (see demo_scan.py for a runnable example):
        s = ScanEventSession(publisher, tenant_id, scan_id)   # correlation_id made here
        s.record_source_succeeded("AWS_BEDROCK", [agent_ids...])
        s.record_source_failed("AZURE_AI_FOUNDRY", "INVALID_CREDENTIALS")
        s.queue_agent_discovered(...)  /  queue_metadata_updated(...) / ...
        s.commit_and_publish(registry_save_function)   # save FIRST, then publish
        s.finish_scan()                                # exactly one terminal event, last
    """

    def __init__(self, publisher: EventPublisher, tenant_id: str, scan_id: str,
                 trigger: str = "SCHEDULED", correlation_id: Optional[str] = None,
                 clock: Clock = utc_now, uuid_factory: Callable[[], str] = new_uuid4):
        if not (isinstance(tenant_id, str) and tenant_id):
            raise ValueError("tenant_id must be a non-empty string")
        if not (isinstance(scan_id, str) and scan_id):
            raise ValueError("scan_id must be a non-empty string")
        if trigger not in TRIGGERS:
            raise ValueError("trigger must be one of %s" % (TRIGGERS,))
        if correlation_id is not None and not is_valid_uuid4(correlation_id):
            raise ValueError("supplied correlation_id must be a lowercase UUID v4")
        self._pub = publisher
        self._clock = clock
        self._uuid = uuid_factory
        self.tenant_id, self.scan_id, self.trigger = tenant_id, scan_id, trigger
        # Generated at scan start; shared by every event of this scan.
        self.correlation_id = correlation_id or self._uuid()
        self.started_at = format_utc(self._clock())
        self._sources: Dict[str, Dict[str, Any]] = {}
        self._pending: List[Dict[str, Any]] = []
        self._used_versions = set()          # (agent_id, metadata_version)
        self._new_agents = set()
        self._updated_agents = set()
        self._finished = False
        self.terminal_event: Optional[Dict[str, Any]] = None

    # ---- source results ---------------------------------------------------
    def record_source_succeeded(self, source_type: str, observed_agent_ids: Iterable[str]) -> None:
        self._add_source(source_type, {"status": "SUCCEEDED",
                                       "agents": set(observed_agent_ids),
                                       "failure_category": None, "error_code": None})

    def record_source_failed(self, source_type: str, situation: str) -> None:
        """`situation` is a key of FAILURE_MAP (contract 6.1). Anything this
        source returned before failing is NOT counted."""
        f = map_failure(situation)
        self._add_source(source_type, {"status": "FAILED", "agents": set(), **f})

    def _add_source(self, source_type: str, info: Dict[str, Any]) -> None:
        self._require_open()
        if source_type not in APPROVED_SOURCE_TYPES:
            raise ValueError("source_type %r is not approved" % source_type)
        if source_type in self._sources:
            raise ValueError("source %s already recorded for this scan" % source_type)
        self._sources[source_type] = info

    # ---- queue agent events (nothing is published yet) ---------------------
    def queue_agent_discovered(self, *, agent_id: str, lifecycle_state: str,
                               source_reference: Dict[str, Any], metadata_version: int) -> None:
        self._queue(AGENT_DISCOVERED, agent_id, metadata_version,
                    {"reason_code": "NEW_AGENT_OBSERVED", "changed_fields": []},
                    {"lifecycle_state": lifecycle_state, "source_reference": source_reference})

    def queue_metadata_updated(self, *, agent_id: str, metadata_version: int,
                               previous_metadata_version: int, changed_fields: List[str]) -> None:
        self._queue(AGENT_METADATA_UPDATED, agent_id, metadata_version,
                    {"reason_code": "SOURCE_METADATA_CHANGED", "changed_fields": list(changed_fields)},
                    {"previous_metadata_version": previous_metadata_version})

    def queue_lifecycle_changed(self, *, agent_id: str, previous_state: str, new_state: str,
                                metadata_version: int, previous_metadata_version: int,
                                reason_code: str, source_type: Optional[str] = None) -> None:
        # Rule: failed/partial/credential-failed scans never delete or declare
        # "not verified". Those two reasons must be backed by a source that
        # SUCCEEDED in this scan.
        if reason_code in ("NOT_VERIFIED_IN_RECENT_SCAN", "SOURCE_REPORTED_DELETED"):
            src = self._sources.get(source_type or "")
            if src is None or src["status"] != "SUCCEEDED":
                raise LifecycleRuleError(
                    "%s needs source_type of a source that SUCCEEDED in this scan; "
                    "a failed or unrecorded source can never justify it" % reason_code)
        self._queue(AGENT_LIFECYCLE_CHANGED, agent_id, metadata_version,
                    {"reason_code": reason_code, "changed_fields": ["lifecycle_state"]},
                    {"previous_state": previous_state, "new_state": new_state,
                     "previous_metadata_version": previous_metadata_version})

    def queue_identity_resolved(self, *, surviving_agent_id: str, retired_agent_ids: List[str],
                                matched_on: List[str], metadata_version: int,
                                previous_metadata_version: int) -> None:
        self._queue(AGENT_IDENTITY_RESOLVED, surviving_agent_id, metadata_version,
                    {"reason_code": "DUPLICATE_IDENTITY_MERGED", "changed_fields": ["source_references"]},
                    {"previous_metadata_version": previous_metadata_version, "resolution": "MERGED",
                     "surviving_agent_id": surviving_agent_id,
                     "retired_agent_ids": list(retired_agent_ids), "matched_on": list(matched_on)})

    def _queue(self, event_type, agent_id, version, change_summary, payload) -> None:
        self._require_open()
        key = (agent_id, version)
        if key in self._used_versions:
            raise ValueError("an event for %s version %s already exists: each "
                             "metadata_version bump gets exactly one event" % key)
        event = build_event(event_type=event_type, tenant_id=self.tenant_id,
                            correlation_id=self.correlation_id, scan_id=self.scan_id,
                            occurred_at=None, payload=payload, agent_id=agent_id,
                            metadata_version=version, change_summary=change_summary,
                            uuid_factory=self._uuid)
        self._validate_pending(event)
        self._used_versions.add(key)
        self._pending.append(event)

    @staticmethod
    def _validate_pending(event: Dict[str, Any]) -> None:
        # occurred_at is only known after the registry commit, so check a copy
        # with a placeholder time now; this catches mistakes at queue time.
        probe = copy.deepcopy(event)
        probe["occurred_at"] = probe["published_at"] = "2000-01-01T00:00:00.000Z"
        validate_event(probe)

    # ---- the "save first, publish second" rule ----------------------------
    def commit_and_publish(self, commit_fn: Callable[[], Any]) -> List[Dict[str, Any]]:
        """Run `commit_fn` (the code that SAVES the registry changes). Agent
        events are handed to the publisher only after it returns without error.
        If it raises, the queued events are thrown away and nothing is published."""
        self._require_open()
        batch, self._pending = self._pending, []
        try:
            commit_fn()
        except BaseException:
            for e in batch:                       # change never happened: free the versions
                self._used_versions.discard((e["agent_id"], e["metadata_version"]))
            raise
        occurred_at = format_utc(self._clock())   # moment the change was committed
        for e in batch:
            e["occurred_at"] = occurred_at
            if e["event_type"] == AGENT_DISCOVERED:
                self._new_agents.add(e["agent_id"])
            else:
                self._updated_agents.add(e["agent_id"])
            self._pub.submit(e)
        return batch

    def publish_committed(self) -> List[Dict[str, Any]]:
        """Publish queued events whose registry change is ALREADY committed (the inventory
        commits before it notifies). Same as commit_and_publish with an empty commit step."""
        return self.commit_and_publish(lambda: None)

    def discard_pending(self) -> None:
        """Call if you abandon queued changes without committing them."""
        for e in self._pending:
            self._used_versions.discard((e["agent_id"], e["metadata_version"]))
        self._pending = []

    # ---- terminal scan event ----------------------------------------------
    def finish_scan(self, scan_failure_situation: Optional[str] = None) -> Dict[str, Any]:
        """Emit the ONE terminal event (COMPLETED / PARTIAL / FAILED).

        scan_failure_situation: a FAILURE_MAP key for a scan-level failure
        (e.g. 'SCAN_TIMEOUT'). If given the scan is FAILED."""
        self._require_open()
        if self._pending:
            raise RuntimeError("uncommitted agent events are pending: call "
                               "commit_and_publish() or discard_pending() first")
        if not self._sources:
            raise ValueError("no source results recorded; cannot decide scan status")

        ok = [s for s, i in self._sources.items() if i["status"] == "SUCCEEDED"]
        bad = [s for s, i in self._sources.items() if i["status"] == "FAILED"]
        scan_failure = map_failure(scan_failure_situation) if scan_failure_situation else None
        if scan_failure or not ok:
            event_type, status = DISCOVERY_SCAN_FAILED, "FAILED"
            if scan_failure is None:      # ASSUMPTION (flagged): reuse first failed source's mapping
                first = self._sources[bad[0]]
                scan_failure = {"failure_category": first["failure_category"],
                                "error_code": first["error_code"]}
        elif bad:
            event_type, status = DISCOVERY_SCAN_PARTIAL, "PARTIAL"
        else:
            event_type, status = DISCOVERY_SCAN_COMPLETED, "SUCCEEDED"

        distinct = set()
        for i in self._sources.values():
            distinct |= i["agents"]
        completed_at = format_utc(self._clock())
        payload: Dict[str, Any] = {
            "scan_status": status, "trigger": self.trigger,
            "started_at": self.started_at, "completed_at": completed_at,
            "agents_observed": len(distinct),
            "agents_new": len(self._new_agents),
            "agents_updated": len(self._updated_agents - self._new_agents),
        }
        if event_type == DISCOVERY_SCAN_FAILED:
            payload["failure_category"] = scan_failure["failure_category"]
            payload["scan_error_code"] = scan_failure["error_code"]      # B2: was error_code
        payload["sources"] = [
            {"source_type": s, "status": i["status"], "agents_observed": len(i["agents"]),
             "failure_category": i["failure_category"],
             "source_error_code": i["error_code"]}                        # B2: was error_code
            for s, i in self._sources.items()]

        event = build_event(event_type=event_type, tenant_id=self.tenant_id,
                            correlation_id=self.correlation_id, scan_id=self.scan_id,
                            occurred_at=completed_at, payload=payload, uuid_factory=self._uuid)
        self._finished = True                      # nothing may follow the terminal event
        self.terminal_event = event
        self._pub.submit(event)
        return event

    def _require_open(self) -> None:
        if self._finished:
            raise RuntimeError("scan already finished: the terminal event must come last")


# --------------------------------------------------------------------------
# Bridge: Soham's Inventory (ingest.py) -> events
# --------------------------------------------------------------------------
class InMemoryEventSink:
    """The prototype's agreed in-memory event collection. Not B2 transport: it only keeps
    the events the publisher hands over, in order, in `self.events`."""

    def __init__(self) -> None:
        self.events: List[Dict[str, Any]] = []

    def __call__(self, event: Dict[str, Any]) -> None:
        self.events.append(copy.deepcopy(event))


class InventoryEventBridge:
    """Receives committed changes from `InventoryObserver` (or any caller that reports them).

    The change is reported AFTER the inventory has committed it. The bridge
    buffers the change; `source_succeeded` / `source_failed` record the source result in
    the scan session and then flush (queue + publish) the buffered changes, so a
    lifecycle reason that needs a SUCCEEDED source is checked against the real result.
    `finish()` flushes anything left and sends the single terminal scan event last.

    Every agent_id / metadata_version in an event is copied from the change the inventory
    reported (i.e. from the stored record). Nothing is generated or incremented here.
    """

    def __init__(self, session: "ScanEventSession") -> None:
        self._s = session
        self._buffer: List[Dict[str, Any]] = []
        # A metadata change that shared its single metadata_version step with a lifecycle change
        # (Soham's one-bump rule). The contract allows one event per version, so the lifecycle
        # event is emitted and the field NAMES are recorded here, never silently lost.
        self.merged_metadata_fields: List[Dict[str, Any]] = []

    def __call__(self, change: Dict[str, Any]) -> None:       # Inventory listener
        if change.get("also_changed_fields"):
            self.merged_metadata_fields.append({"agent_id": change["agent_id"],
                                                "metadata_version": change["metadata_version"],
                                                "fields": list(change["also_changed_fields"])})
        self._buffer.append(change)

    @property
    def scan_id(self) -> str:
        return self._s.scan_id

    @property
    def pending_changes(self) -> int:
        return len(self._buffer)

    def source_succeeded(self, source_type: str, observed_agent_ids: Iterable[str]) -> None:
        self._s.record_source_succeeded(source_type, observed_agent_ids)
        self.flush()

    def source_failed(self, source_type: str, situation: str) -> None:
        self._s.record_source_failed(source_type, situation)
        self.flush()

    def flush(self) -> None:
        """Queue and publish every buffered committed change, oldest first. A change that
        cannot be turned into a valid event stays in the buffer and the error is raised
        (committed changes are never silently dropped)."""
        queued = False
        try:
            while self._buffer:
                self._queue(self._buffer[0])
                self._buffer.pop(0)
                queued = True
        finally:
            if queued:
                self._s.publish_committed()

    def finish(self, scan_failure_situation: Optional[str] = None) -> Dict[str, Any]:
        self.flush()
        return self._s.finish_scan(scan_failure_situation)

    def _queue(self, c: Dict[str, Any]) -> None:
        kind = c["kind"]
        if kind == AGENT_DISCOVERED:
            self._s.queue_agent_discovered(
                agent_id=c["agent_id"], lifecycle_state=c["lifecycle_state"],
                metadata_version=c["metadata_version"],
                source_reference={"source_type": c["source_type"], "external_id": c["external_id"],
                                  "first_observed_at": c["first_observed_at"],
                                  "last_observed_at": c["last_observed_at"],
                                  "scan_id": self._s.scan_id})
        elif kind == AGENT_METADATA_UPDATED:
            self._s.queue_metadata_updated(
                agent_id=c["agent_id"], metadata_version=c["metadata_version"],
                previous_metadata_version=c["previous_metadata_version"],
                changed_fields=c["changed_fields"])
        elif kind == AGENT_LIFECYCLE_CHANGED:
            self._s.queue_lifecycle_changed(
                agent_id=c["agent_id"], previous_state=c["previous_state"], new_state=c["new_state"],
                metadata_version=c["metadata_version"],
                previous_metadata_version=c["previous_metadata_version"],
                reason_code=c["reason_code"], source_type=c["source_type"])
        else:
            raise ValueError("unsupported inventory change kind %r" % (kind,))


# ==========================================================================
# Inventory hook points (build INTEGRATION_HANDOFF.md, "Hook points / Gautham")
# --------------------------------------------------------------------------
# "_upsert() returns the stored canonical record; snapshot the existing record before
#  mutation and compare after commit. New record starts at version 1. Emit discovery after
#  insertion, lifecycle event on state change, metadata event on tracked metadata change;
#  use stored agent_id/version, never generate them in the producer."
# ingest.py / lifecycle.py are NOT modified: the observer below snapshots the inventory
# before and after each reusable call and derives the committed change from the difference.
# ==========================================================================
from dataclasses import dataclass
from typing import Mapping

# Mirror of ingest.SOURCE_ALIASES (Soham's mapping of his stored source keys to the approved
# UPPERCASE values; a test asserts the two stay identical). Approved values pass through
# unchanged, so the observer keeps working once Soumojit's UPPERCASE alignment lands.
STORED_SOURCE_KEYS = {"aws_bedrock": "AWS_BEDROCK", "azure_ai": "AZURE_AI_FOUNDRY"}

# Fields the inventory tracks for change detection in the supplied ingest.py `_upsert`
# (name, creation_date, metadata) plus the other Field Mapping v0.2 tracked names, so a
# future inventory that tracks them is reported with the right field NAME (never a value).
TRACKED_RECORD_FIELDS = ("name", "creation_date", "metadata", "owner_id", "purpose",
                         "connected_tools", "access_scope", "autonomy_level", "risk_score",
                         "metadata_confidence")

# Reason code is a pure function of the NEW state (contract reason<->state pairing).
REASON_FOR_NEW_STATE = {"QUARANTINED": "INTEGRITY_CONCERN",
                        "DELETED": "SOURCE_REPORTED_DELETED",
                        "UNREACHABLE": "NOT_VERIFIED_IN_RECENT_SCAN",
                        "DORMANT": "DORMANCY_PERIOD_EXCEEDED",
                        "ACTIVE": "PROVIDER_STATUS"}


@dataclass(frozen=True)
class InventoryChange:
    """Snapshot-derived committed inventory change (same shape as the build's scaffold)."""
    change_type: str                       # AGENT_DISCOVERED | AGENT_METADATA_UPDATED | AGENT_LIFECYCLE_CHANGED
    record: Mapping[str, Any]              # stored record AFTER the commit
    previous_record: Optional[Mapping[str, Any]] = None   # deep copy taken BEFORE (None for a new record)
    scan_id: Optional[str] = None


def _event_source_type(stored: str) -> str:
    return STORED_SOURCE_KEYS.get(stored, stored)


def diff_records(before: Optional[Mapping[str, Any]], after: Mapping[str, Any],
                 scan_id: Optional[str] = None) -> Optional[InventoryChange]:
    """Compare a record before and after one inventory call.

    No change (including `last_seen_at`-only movement) -> None, so a stale observation, a missing
    status on an existing agent, an unchanged agent or a REVIEW outcome never produce an event.
    The version counter belongs to the inventory: it must have moved by exactly 1.
    """
    if before is None:
        return InventoryChange(AGENT_DISCOVERED, after, None, scan_id)
    delta = after["metadata_version"] - before["metadata_version"]
    if delta == 0:
        return None
    if delta != 1:
        raise ValueError("metadata_version moved by %d for %s (expected exactly 1); refusing to "
                         "invent or skip an event" % (delta, after["agent_id"]))
    if before["lifecycle_state"] != after["lifecycle_state"]:
        return InventoryChange(AGENT_LIFECYCLE_CHANGED, after, before, scan_id)
    return InventoryChange(AGENT_METADATA_UPDATED, after, before, scan_id)


def changed_tracked_fields(before: Mapping[str, Any], after: Mapping[str, Any]) -> List[str]:
    """Names (never values) of tracked fields that differ; absent and null are the same value."""
    return [f for f in TRACKED_RECORD_FIELDS if before.get(f) != after.get(f)]


class DiscoveryEventProducer:
    """Turns an InventoryChange into the change dict / event. Never mints an id or a version."""

    def __init__(self, session: Optional["ScanEventSession"] = None, event_validator=None):
        self.session = session
        self.event_validator = event_validator

    @staticmethod
    def change_dict(change: InventoryChange) -> Dict[str, Any]:
        rec, prev = change.record, change.previous_record
        ref = rec["source_references"][0]
        d = {"kind": change.change_type, "agent_id": rec["agent_id"],
             "metadata_version": rec["metadata_version"], "lifecycle_state": rec["lifecycle_state"],
             "source_type": _event_source_type(ref["source_type"]), "external_id": ref["external_id"],
             # per-source first/last observed are not stored by the supplied inventory (Field Mapping
             # section 12, Soumojit, in progress): use the record's own first/last_seen_at
             "first_observed_at": ref.get("first_observed_at", rec["first_seen_at"]),
             "last_observed_at": ref.get("last_observed_at", rec["last_seen_at"])}
        if prev is not None:
            d["previous_metadata_version"] = prev["metadata_version"]
            if change.change_type == AGENT_LIFECYCLE_CHANGED:
                d.update(previous_state=prev["lifecycle_state"], new_state=rec["lifecycle_state"],
                         reason_code=REASON_FOR_NEW_STATE[rec["lifecycle_state"]],
                         changed_fields=["lifecycle_state"],
                         also_changed_fields=changed_tracked_fields(prev, rec))
            else:
                d["changed_fields"] = changed_tracked_fields(prev, rec)
        return d

    def build_event(self, change: InventoryChange) -> Dict[str, Any]:
        """Queue the change in the scan session (validated against the contract) and return a copy
        of the resulting, not yet published, event."""
        if self.session is None:
            raise ValueError("DiscoveryEventProducer needs a ScanEventSession to build events")
        InventoryEventBridge(self.session)._queue(self.change_dict(change))
        event = copy.deepcopy(self.session._pending[-1])
        if self.event_validator is not None:
            self.event_validator(event)
        return event


class InventoryObserver:
    """Calls the REUSABLE inventory operations and reports what they committed.

    Wraps `ingest.Inventory` without changing it: each call takes a deep-copy snapshot of the
    tenant's records first, runs the real method, snapshots again, and hands the differences to
    the bridge (which publishes only after the source result is known). Method signatures match
    Soham's Inventory.

    Hook placement (build handoff): `quarantine_existing()` and the DELETED -> ACTIVE decision
    belong to the review/duplicate layer (Pavani) and `mark_unverified()` to the scan
    coordinator; this class does NOT decide when to call them, it only reports what they did.
    """

    def __init__(self, inventory: Any, bridge: "InventoryEventBridge") -> None:
        self.inventory, self.bridge = inventory, bridge
        self.review_warnings: List[str] = []

    def _snapshot(self, tenant_id: str) -> Dict[str, Dict[str, Any]]:
        return {r["agent_id"]: copy.deepcopy(r) for r in self.inventory.list_for_tenant(tenant_id)}

    def _observe(self, tenant_id: str, call: Callable[[], Any]) -> Any:
        before = self._snapshot(tenant_id)
        result = call()                                   # the real, unmodified inventory method
        for agent_id, record in self._snapshot(tenant_id).items():
            change = diff_records(before.get(agent_id), record, self.bridge.scan_id)
            if change is None:
                continue
            if (change.change_type == AGENT_LIFECYCLE_CHANGED
                    and change.previous_record["lifecycle_state"] == "DELETED"
                    and record["lifecycle_state"] == "ACTIVE"):
                self.review_warnings.append(
                    "%s went DELETED -> ACTIVE without a review hold; the review layer must intercept "
                    "resurrection before ingest and call quarantine_existing()" % agent_id)
            self.bridge(DiscoveryEventProducer.change_dict(change))
        return result

    def ingest(self, raw: Any, tenant_id: Any, source_type: Any, *args: Any, **kwargs: Any) -> Any:
        return self._observe(tenant_id, lambda: self.inventory.ingest(raw, tenant_id, source_type, *args, **kwargs))

    def mark_unverified(self, tenant_id: str, source_type: str, external_id: str, **kwargs: Any) -> Any:
        return self._observe(tenant_id, lambda: self.inventory.mark_unverified(
            tenant_id, source_type, external_id, **kwargs))

    def quarantine_existing(self, tenant_id: str, source_type: str, external_id: str) -> Any:
        return self._observe(tenant_id, lambda: self.inventory.quarantine_existing(
            tenant_id, source_type, external_id))

"""Generates discovery_event_payloads.json and discovery_scan_results.json FROM THE CODE.

Every event comes out of discovery_events.py, driven by the week_2 build's real, UNMODIFIED ingest.Inventory +
lifecycle.py through InventoryObserver -> InventoryEventBridge -> ScanEventSession -> EventPublisher.
Input records are SYNTHETIC fixtures (tests/fixtures.json shapes) - NOT production data. Agent ids and timestamps of
`occurred_at`/`published_at` come from the run.

ID-FORMAT SHIM (disclosed in the output): the supplied ingest.py still mints a bare UUID; Field Mapping v0.2 requires
agt_ + UUID v4 and lists the alignment as "In progress" (Soumojit). The run swaps ingest.py's `uuid` module for one whose
uuid4() adds the "agt_" prefix so that contract-valid events can be shown. Without it the producer refuses the events
(tests/test_integration.py::test_unaligned_plain_uuid_agent_id_blocks_the_event_but_not_the_commit).

Run from the module root:   python scripts/generate_payloads.py
"""
import copy
import json
import os
import sys
import types
import uuid
from datetime import datetime, timedelta, timezone

MOD = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path[:0] = [os.path.join(MOD, "src")]
import discovery_events as de   # noqa: E402
import event_validator as ev    # noqa: E402
import ingest                   # noqa: E402

ingest.uuid = types.SimpleNamespace(uuid4=lambda: "agt_" + str(uuid.uuid4()))      # disclosed shim (see docstring)

with open(os.path.join(MOD, "tests", "fixtures.json"), encoding="utf-8") as fh:
    FX = json.load(fh)

TENANT = "tnt_synthetic_001"
AWS, AZ = "AWS_BEDROCK", "AZURE_AI_FOUNDRY"
AWS_IN, AZ_IN = "aws_bedrock", "azure_ai"


class Clock:
    def __init__(self, iso):
        self.set(iso)

    def set(self, iso):
        self.t = datetime.strptime(iso, "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=timezone.utc)

    def __call__(self):
        return self.t


def aws(ext, **kw):
    r = dict(FX["aws_valid"], agentId=ext, agentName="Synthetic " + ext)
    r.update(kw)
    return r


def main():
    inv = ingest.Inventory(dormancy_days=14)
    sink = de.InMemoryEventSink()
    clock = Clock("2026-11-24T09:00:00.000Z")
    pub_clock = Clock("2026-11-24T09:00:30.000Z")
    scans, state = [], {}

    def begin(scan_id, at):
        clock.set(at)
        pub = de.EventPublisher(sink, clock=clock, sleep=lambda s: None)
        session = de.ScanEventSession(pub, TENANT, scan_id, clock=clock)
        bridge = de.InventoryEventBridge(session)
        obs = de.InventoryObserver(inv, bridge)
        return session, bridge, obs, len(sink.events)

    def record(scan_id, n0, note, extra=None):
        evs = sink.events[n0:]
        scans.append({"scan_id": scan_id, "note": note, "event_types": [e["event_type"] for e in evs],
                      "terminal_event": evs[-1]["event_type"], "terminal_status": evs[-1]["payload"].get("scan_status"),
                      "terminal_is_last": evs[-1]["event_type"] in de.SCAN_EVENT_TYPES,
                      "terminal_events_in_scan": sum(e["event_type"] in de.SCAN_EVENT_TYPES for e in evs),
                      **(extra or {})})

    # ---- scan 1: COMPLETED - 3 new AWS agents + 1 new Azure agent -> 4 x AGENT_DISCOVERED
    s, b, o, n = begin("scn_synth_01", "2026-11-24T09:00:00.000Z")
    ids = [o.ingest(aws(x), TENANT, AWS_IN, "2026-11-24T09:00:00.000Z").record["agent_id"] for x in ("SYN-AWS-1", "SYN-AWS-2", "SYN-AWS-3")]
    az = o.ingest(FX["azure_valid"], TENANT, AZ_IN, "2026-11-24T09:00:00.000Z").record["agent_id"]
    b.source_succeeded(AWS, ids)
    b.source_succeeded(AZ, [az])
    clock.set("2026-11-24T09:05:00.000Z")
    b.finish()
    record("scn_synth_01", n, "all sources succeed; 4 new agents")

    # ---- scan 2: PARTIAL - Azure fails; metadata change, DELETED, UNREACHABLE (scan coordinator), quarantine (review layer)
    s, b, o, n = begin("scn_synth_02", "2026-11-25T09:00:00.000Z")
    at = "2026-11-25T09:00:00.000Z"
    o.ingest(aws("SYN-AWS-1", agentName="Synthetic SYN-AWS-1 (renamed)"), TENANT, AWS_IN, at)                       # METADATA_UPDATED (name)
    o.ingest(aws("SYN-AWS-3", agentStatus="DELETED"), TENANT, AWS_IN, at)                                           # LIFECYCLE_CHANGED -> DELETED
    o.mark_unverified(TENANT, AWS_IN, "SYN-AWS-2", scan_status="SUCCEEDED", verification_failed=True,               # LIFECYCLE_CHANGED -> UNREACHABLE
                      now=datetime(2026, 11, 25, 9, 0, 10, tzinfo=timezone.utc))
    b.source_succeeded(AWS, [ids[0], ids[2]])
    b.source_failed(AZ, "INVALID_CREDENTIALS")
    clock.set("2026-11-25T09:05:00.000Z")
    b.finish()
    record("scn_synth_02", n, "Azure fails: PARTIAL; rename, provider DELETED, agent not verified")

    # ---- scan 3: COMPLETED - stale + missing status (no events), review-layer quarantine of a resurrection and a duplicate
    s, b, o, n = begin("scn_synth_03", "2026-11-26T09:00:00.000Z")
    at = "2026-11-26T09:00:00.000Z"
    v_before = inv.get(TENANT, AWS_IN, "SYN-AWS-1")["metadata_version"]
    o.ingest(aws("SYN-AWS-1", agentName="Synthetic SYN-AWS-1 (renamed)", agentStatus="DELETED"), TENANT, AWS_IN, "2026-11-24T08:00:00.000Z")   # STALE
    o.ingest({k: v for k, v in aws("SYN-AWS-1", agentName="Synthetic SYN-AWS-1 (renamed)").items() if k != "agentStatus"}, TENANT, AWS_IN, at)   # MISSING status
    o.ingest(aws("SYN-AWS-1", agentName="Synthetic SYN-AWS-1 (renamed)"), TENANT, AWS_IN, at)                       # identical to stored
    # review layer (caller-side, per build handoff): DELETED -> ACTIVE intercepted BEFORE ingest, then quarantine_existing()
    prior = inv.get(TENANT, AWS_IN, "SYN-AWS-3")
    incoming = aws("SYN-AWS-3", agentStatus="ACTIVE")
    if prior["lifecycle_state"] == "DELETED" and incoming["agentStatus"] == "ACTIVE":
        o.quarantine_existing(TENANT, AWS_IN, "SYN-AWS-3")
        inv.review_log.append({"outcome": ingest.REVIEW, "reasons": ["DELETED to ACTIVE resurrection requires human review"],
                               "tenant_id": TENANT, "source_type": AWS_IN, "external_id": "SYN-AWS-3"})
    stale_ok = inv.get(TENANT, AWS_IN, "SYN-AWS-1")["metadata_version"] == v_before
    o.ingest(FX["azure_valid"], TENANT, AZ_IN, at)                                                                  # identical
    b.source_succeeded(AWS, [ids[0], ids[2]])
    b.source_succeeded(AZ, [az])
    clock.set("2026-11-26T09:05:00.000Z")
    b.finish()
    record("scn_synth_03", n, "stale + missing-status observations emit nothing; resurrection held in QUARANTINED by the review layer",
           {"stale_and_missing_status_changed_nothing": stale_ok})

    # ---- scan 4: FAILED - every source fails
    s, b, o, n = begin("scn_synth_04", "2026-11-27T09:00:00.000Z")
    before = {k: copy.deepcopy(a) for k, a in ((e, inv.get(TENANT, AWS_IN, e)) for e in ("SYN-AWS-1", "SYN-AWS-2", "SYN-AWS-3"))}
    b.source_failed(AWS, "SOURCE_TIMEOUT")
    b.source_failed(AZ, "INVALID_CREDENTIALS")
    clock.set("2026-11-27T09:05:00.000Z")
    b.finish("SCAN_TIMEOUT")
    unchanged = all(inv.get(TENANT, AWS_IN, e) == before[e] for e in before)
    record("scn_synth_04", n, "all sources fail: FAILED scan, no agent changes", {"inventory_unchanged": unchanged})

    events = copy.deepcopy(sink.events)
    batch = ev.validate_batch(events, ordered=True)
    final = {a["agent_id"]: a for a in inv.list_for_tenant(TENANT)}
    checks = {
        "validator_passed_all_events": bool(batch["passed"]),
        "no_event_id_key_anywhere": all("event_id" not in e for e in events),
        "source_system_ref_is_uuid4": all(de.is_valid_uuid4(e["source_system_ref"]) for e in events),
        "agent_ids_are_agt_uuid4": all(de.is_valid_agent_id(e["agent_id"]) for e in events if e["event_type"] in de.AGENT_EVENT_TYPES),
        "agent_event_ids_exist_in_inventory": all(e["agent_id"] in final for e in events if e["event_type"] in de.AGENT_EVENT_TYPES),
        "last_event_version_equals_stored_version": all(
            max(e["metadata_version"] for e in events if e["agent_id"] == a) == final[a]["metadata_version"] for a in final),
        "source_error_code_inside_sources": all("source_error_code" in x and "error_code" not in x
                                               for e in events if e["event_type"] in de.SCAN_EVENT_TYPES for x in e["payload"]["sources"]),
        "scan_error_code_only_on_failed_scans": all(("scan_error_code" in e["payload"]) == (e["event_type"] == de.DISCOVERY_SCAN_FAILED)
                                                    for e in events if e["event_type"] in de.SCAN_EVENT_TYPES),
        "exactly_one_terminal_event_per_scan_and_it_is_last": all(s["terminal_events_in_scan"] == 1 and s["terminal_is_last"] for s in scans),
        "scan_statuses_present": sorted({e["payload"]["scan_status"] for e in events if e["event_type"] in de.SCAN_EVENT_TYPES}),
        "event_types_present": sorted({e["event_type"] for e in events}),
    }
    label = ("SYNTHETIC / FIXTURE data run through the week_2 build's real ingest.Inventory (unmodified) - NOT production output. "
             "Agent ids carry the agt_ prefix through a disclosed test shim (see generate_payloads.py docstring); "
             "event_id is not included on any event.")
    out = {"_provenance": label, "generated_by": "scripts/generate_payloads.py", "checks": checks,
           "events": events}
    with open(os.path.join(MOD, "discovery_event_payloads.json"), "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=2)
        fh.write("\n")
    res = {"_provenance": label, "scans": scans, "checks": checks,
           "final_inventory_state": [{k: a[k] for k in ("agent_id", "lifecycle_state", "metadata_version")} | {"external_id": a["source_references"][0]["external_id"]}
                                     for a in inv.list_for_tenant(TENANT)],
           "review_log": inv.review_log}
    with open(os.path.join(MOD, "discovery_scan_results.json"), "w", encoding="utf-8") as fh:
        json.dump(res, fh, indent=2)
        fh.write("\n")
    print(json.dumps(checks, indent=2))
    print("events:", len(events), "| validator:", "PASS" if batch["passed"] else "FAIL")
    bad = [k for k, v in checks.items() if v is False]
    return 1 if bad or not batch["passed"] else 0


if __name__ == "__main__":
    sys.exit(main())

"""
test_discovery_events.py - tests for discovery_events.py (NEW FILE)

Run (from modules/module-1-agent-discovery):
    python -m unittest discover -s tests -v

The sample-matching tests read tests/fixtures/A1_Discovery_Event_Samples/
(the supplied company fixtures). Set A1_SAMPLES_DIR to use another folder.
If the folder is missing those tests FAIL (they never skip).

NOTE: a few tests build scans from randomly generated agent IDs. That is
synthetic TEST data only - it is never used in the delivered example files.
"""
import copy
import glob
import json
import os
import re
import sys
import unittest
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "src"))

sys.path.insert(0, HERE)
import discovery_events as de  # noqa: E402
import uuid as _uuid  # noqa: E402


def new_agent_id():
    """TEST-ONLY helper: a well-formed agt_ id for unit tests that feed the session directly.
    The producer never creates ids; real ids come from the inventory (see test_integration.py)."""
    return "agt_" + str(_uuid.uuid4())


def samples_dir():
    cands = [os.environ.get("A1_SAMPLES_DIR", ""),
             os.path.join(HERE, "fixtures", "A1_Discovery_Event_Samples")]
    for c in cands:
        if c and glob.glob(os.path.join(c, "agent_discovered.json")):
            return c
    raise AssertionError("Sample folder not found. Expected tests/fixtures/A1_Discovery_Event_Samples "
                         "or set A1_SAMPLES_DIR. Tried: %r" % cands)


def load_sample(name, raw=False):
    """Official v0.2 sample, as supplied. The fixture-only `_note` is dropped (the producer never
    emits it) unless raw=True."""
    with open(os.path.join(samples_dir(), name), encoding="utf-8") as fh:
        d = json.load(fh)
    if not raw:
        d.pop("_note", None)
    return d


class FakeClock:
    """Returns whatever time was set last, so tests control timestamps."""
    def __init__(self, iso="2026-01-01T00:00:00.000Z"):
        self.set(iso)

    def set(self, iso):
        self._t = datetime.strptime(iso, "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=timezone.utc)

    def __call__(self):
        return self._t


def uuids(*values):
    it = iter(values)
    return lambda: next(it)


class Sink:
    def __init__(self):
        self.events, self.fail = [], False
        self.log = []

    def __call__(self, ev):
        self.log.append("sink")
        if self.fail:
            raise ConnectionError("transport down")
        self.events.append(copy.deepcopy(ev))


def make(sink=None, pub_clock=None, **kw):
    sink = sink or Sink()
    pub_clock = pub_clock or FakeClock()
    pub = de.EventPublisher(sink, clock=pub_clock, sleep=lambda s: None, **kw)
    return sink, pub_clock, pub


ACME, CORR = "tnt_acme_001", "8d1e5b6a-3c2f-4e7d-9a1b-0c4d5e6f7a8b"


class IdAndTimeTests(unittest.TestCase):
    def test_agent_id_format(self):
        for _ in range(50):
            self.assertTrue(de.is_valid_agent_id(new_agent_id()))
        self.assertFalse(de.is_valid_agent_id("7f3c2a91-0b4e-4d1a-9c55-2e8f6a1b3d07"))  # old plain UUID
        self.assertFalse(de.is_valid_agent_id("AGT_7f3c2a91-0b4e-4d1a-9c55-2e8f6a1b3d07"))
        self.assertFalse(de.is_valid_agent_id("agt_7F3C2A91-0B4E-4D1A-9C55-2E8F6A1B3D07"))
        self.assertFalse(de.is_valid_agent_id("agt_7f3c2a91-0b4e-1d1a-9c55-2e8f6a1b3d07"))  # not v4

    def test_utc_format(self):
        ist = datetime.strptime("2026-11-23 14:30:00.123456 +0530", "%Y-%m-%d %H:%M:%S.%f %z")
        self.assertEqual(de.format_utc(ist), "2026-11-23T09:00:00.123Z")
        with self.assertRaises(ValueError):
            de.format_utc(datetime(2026, 1, 1))              # naive refused

    def test_correlation_id_generated_at_scan_start(self):
        _, _, pub = make()
        a = de.ScanEventSession(pub, ACME, "scn_a")
        b = de.ScanEventSession(pub, ACME, "scn_b")
        self.assertTrue(de.is_valid_uuid4(a.correlation_id))
        self.assertNotEqual(a.correlation_id, b.correlation_id)
        self.assertNotEqual(a.correlation_id, a.scan_id)      # not reused from scan_id
        with self.assertRaises(ValueError):
            de.ScanEventSession(pub, ACME, "scn_c", correlation_id="scn_20261123_0900_01")


class SampleReproductionTests(unittest.TestCase):
    """The producer must emit EXACTLY what the supplied samples show."""

    def run_agent_sample(self, name, queue, ref, occurred, published, corr, scan_id):
        sample = load_sample(name)
        sink, pub_clock, pub = make()
        clock = FakeClock("2026-01-01T00:00:00.000Z")
        s = de.ScanEventSession(pub, sample["tenant_id"], scan_id, correlation_id=corr,
                                clock=clock, uuid_factory=uuids(ref))
        queue(s)
        clock.set(occurred)
        pub_clock.set(published)
        s.commit_and_publish(lambda: None)
        self.assertEqual(len(sink.events), 1)
        self.assertEqual(sink.events[0], sample)
        self.assertEqual(list(sink.events[0]), list(sample))   # same key order too
        return sink.events[0]

    def test_agent_discovered(self):
        sample = load_sample("agent_discovered.json")
        self.run_agent_sample(
            "agent_discovered.json",
            lambda s: s.queue_agent_discovered(
                agent_id=sample["agent_id"], lifecycle_state="ACTIVE",
                source_reference=copy.deepcopy(sample["payload"]["source_reference"]),
                metadata_version=1),
            sample["source_system_ref"], sample["occurred_at"], sample["published_at"],
            sample["correlation_id"], sample["scan_id"])

    def test_metadata_updated(self):
        sample = load_sample("agent_metadata_updated.json")
        self.run_agent_sample(
            "agent_metadata_updated.json",
            lambda s: s.queue_metadata_updated(
                agent_id=sample["agent_id"], metadata_version=3, previous_metadata_version=2,
                changed_fields=["owner_id", "connected_tools"]),
            sample["source_system_ref"], sample["occurred_at"], sample["published_at"],
            sample["correlation_id"], sample["scan_id"])

    def test_lifecycle_quarantined(self):
        sample = load_sample("agent_lifecycle_changed.json")
        self.run_agent_sample(
            "agent_lifecycle_changed.json",
            lambda s: s.queue_lifecycle_changed(
                agent_id=sample["agent_id"], previous_state="ACTIVE", new_state="QUARANTINED",
                metadata_version=6, previous_metadata_version=5, reason_code="INTEGRITY_CONCERN"),
            sample["source_system_ref"], sample["occurred_at"], sample["published_at"],
            sample["correlation_id"], sample["scan_id"])

    def test_lifecycle_unreachable(self):
        sample = load_sample("agent_lifecycle_changed__unreachable.json")

        def queue(s):
            s.record_source_succeeded("AWS_BEDROCK", [])      # a SUCCEEDED source backs "not verified"
            s.queue_lifecycle_changed(
                agent_id=sample["agent_id"], previous_state="ACTIVE", new_state="UNREACHABLE",
                metadata_version=4, previous_metadata_version=3,
                reason_code="NOT_VERIFIED_IN_RECENT_SCAN", source_type="AWS_BEDROCK")
        self.run_agent_sample("agent_lifecycle_changed__unreachable.json", queue,
                              sample["source_system_ref"], sample["occurred_at"],
                              sample["published_at"], sample["correlation_id"], sample["scan_id"])

    def test_identity_resolved(self):
        sample = load_sample("agent_identity_resolved.json")
        p = sample["payload"]
        self.run_agent_sample(
            "agent_identity_resolved.json",
            lambda s: s.queue_identity_resolved(
                surviving_agent_id=p["surviving_agent_id"], retired_agent_ids=p["retired_agent_ids"],
                matched_on=p["matched_on"], metadata_version=7, previous_metadata_version=6),
            sample["source_system_ref"], sample["occurred_at"], sample["published_at"],
            sample["correlation_id"], sample["scan_id"])

    # ---- scan events -------------------------------------------------------
    def run_scan_sample(self, name, build):
        """build(session, helpers) drives the session; then compare terminal event."""
        sample = load_sample(name)
        p = sample["payload"]
        sink, pub_clock, pub = make()
        clock = FakeClock(p["started_at"])
        # factory order: any agent-event refs first, terminal event ref last
        extra = build.get("extra_refs", [])
        s = de.ScanEventSession(pub, sample["tenant_id"], sample["scan_id"],
                                trigger=p["trigger"], correlation_id=sample["correlation_id"],
                                clock=clock, uuid_factory=uuids(*extra, sample["source_system_ref"]))
        build["drive"](s, clock, pub_clock)
        clock.set(p["completed_at"])
        pub_clock.set(sample["published_at"])
        s.finish_scan(build.get("scan_failure"))
        self.assertEqual(sink.events[-1], sample)
        self.assertEqual(list(sink.events[-1]), list(sample))
        return sink

    def test_scan_completed(self):
        ids = [new_agent_id() for _ in range(7)]
        aws, azure = ids[0:3], ids[2:7]                      # 3 + 5 with 1 overlap = 7 distinct

        def drive(s, clock, pub_clock):
            s.record_source_succeeded("AWS_BEDROCK", aws)
            s.record_source_succeeded("AZURE_AI_FOUNDRY", azure)
            s.queue_metadata_updated(agent_id=ids[0], metadata_version=2,
                                     previous_metadata_version=1, changed_fields=["owner_id"])
            s.queue_metadata_updated(agent_id=ids[1], metadata_version=3,
                                     previous_metadata_version=2, changed_fields=["purpose"])
            s.commit_and_publish(lambda: None)
        sink = self.run_scan_sample("discovery_scan_completed.json", {
            "drive": drive, "extra_refs": [de.new_uuid4(), de.new_uuid4()]})
        self.assertEqual([e["event_type"] for e in sink.events][-1], de.DISCOVERY_SCAN_COMPLETED)
        self.assertEqual(sum(1 for e in sink.events if e["event_type"] in de.SCAN_EVENT_TYPES), 1)

    def test_scan_completed_zero_results(self):
        self.run_scan_sample("discovery_scan_completed__zero_results.json", {
            "drive": lambda s, c, pc: s.record_source_succeeded("AWS_BEDROCK", [])})

    def test_scan_partial(self):
        ids = [new_agent_id() for _ in range(3)]

        def drive(s, c, pc):
            s.record_source_succeeded("AWS_BEDROCK", ids)
            s.record_source_failed("AZURE_AI_FOUNDRY", "INVALID_CREDENTIALS")
            s.queue_metadata_updated(agent_id=ids[0], metadata_version=3,
                                     previous_metadata_version=2, changed_fields=["owner_id"])
            s.queue_lifecycle_changed(agent_id=ids[1], previous_state="ACTIVE", new_state="QUARANTINED",
                                      metadata_version=6, previous_metadata_version=5,
                                      reason_code="INTEGRITY_CONCERN")
            s.commit_and_publish(lambda: None)
        self.run_scan_sample("discovery_scan_partial.json", {
            "drive": drive, "extra_refs": [de.new_uuid4(), de.new_uuid4()]})

    def test_scan_failed_timeout(self):
        def drive(s, c, pc):
            s.record_source_failed("AWS_BEDROCK", "SOURCE_TIMEOUT")
            s.record_source_failed("AZURE_AI_FOUNDRY", "INVALID_CREDENTIALS")
        self.run_scan_sample("discovery_scan_failed.json", {"drive": drive, "scan_failure": "SCAN_TIMEOUT"})

    def test_every_sample_passes_validation(self):
        files = glob.glob(os.path.join(samples_dir(), "*.json"))
        self.assertEqual(len(files), 9)
        for f in files:
            with self.subTest(f=os.path.basename(f)):
                with open(f, encoding="utf-8") as fh:
                    d = json.load(fh)
                    d.pop("_note", None)
                de.validate_event(d)


class DeliveryRuleTests(unittest.TestCase):
    def session(self, sink=None, **kw):
        sink, pub_clock, pub = make(sink, **kw)
        clock = FakeClock("2026-11-23T09:00:00.000Z")
        pub_clock.set("2026-11-23T09:00:01.000Z")
        return sink, pub, clock, de.ScanEventSession(pub, ACME, "scn_x", clock=clock)

    def test_registry_saved_before_publish(self):
        sink, pub, clock, s = self.session()
        s.record_source_succeeded("AWS_BEDROCK", [])
        s.queue_metadata_updated(agent_id=new_agent_id(), metadata_version=2,
                                 previous_metadata_version=1, changed_fields=["name"])
        order = []
        sink.log = order

        def save():
            order.append("registry_saved")
        s.commit_and_publish(save)
        self.assertEqual(order, ["registry_saved", "sink"])

    def test_failed_commit_publishes_nothing(self):
        sink, pub, clock, s = self.session()
        aid = new_agent_id()
        s.queue_agent_discovered(agent_id=aid, lifecycle_state="ACTIVE", source_reference={
            "source_type": "AWS_BEDROCK", "external_id": "X", "first_observed_at": "2026-11-23T09:00:00.000Z",
            "last_observed_at": "2026-11-23T09:00:00.000Z", "scan_id": "scn_x"},
            metadata_version=1)

        def boom():
            raise IOError("disk full")
        with self.assertRaises(IOError):
            s.commit_and_publish(boom)
        self.assertEqual(sink.events, [])
        self.assertEqual(pub.outbox, [])

    def test_terminal_event_is_last_and_only_one(self):
        sink, pub, clock, s = self.session()
        s.record_source_succeeded("AWS_BEDROCK", [])
        s.queue_metadata_updated(agent_id=new_agent_id(), metadata_version=2,
                                 previous_metadata_version=1, changed_fields=["name"])
        s.commit_and_publish(lambda: None)
        s.finish_scan()
        types = [e["event_type"] for e in sink.events]
        self.assertEqual(types, [de.AGENT_METADATA_UPDATED, de.DISCOVERY_SCAN_COMPLETED])
        with self.assertRaises(RuntimeError):
            s.finish_scan()
        with self.assertRaises(RuntimeError):
            s.queue_metadata_updated(agent_id=new_agent_id(), metadata_version=2,
                                     previous_metadata_version=1, changed_fields=["name"])

    def test_pending_events_block_finish(self):
        sink, pub, clock, s = self.session()
        s.record_source_succeeded("AWS_BEDROCK", [])
        s.queue_metadata_updated(agent_id=new_agent_id(), metadata_version=2,
                                 previous_metadata_version=1, changed_fields=["name"])
        with self.assertRaises(RuntimeError):
            s.finish_scan()

    def test_retry_resends_identical_event(self):
        attempts = []

        class Flaky(Sink):
            def __call__(self, ev):
                attempts.append(copy.deepcopy(ev))
                if len(attempts) < 3:
                    raise TimeoutError("slow")
                super().__call__(ev)
        sink = Flaky()
        pub_clock = FakeClock("2026-11-23T09:00:01.000Z")
        pub = de.EventPublisher(sink, clock=pub_clock, max_attempts=3, sleep=lambda s: pub_clock.set("2026-11-23T09:00:02.000Z"))
        clock = FakeClock("2026-11-23T09:00:00.000Z")
        s = de.ScanEventSession(pub, ACME, "scn_x", clock=clock)
        s.queue_metadata_updated(agent_id=new_agent_id(), metadata_version=2,
                                 previous_metadata_version=1, changed_fields=["name"])
        s.commit_and_publish(lambda: None)
        self.assertEqual(len(attempts), 3)
        for a in attempts[1:]:
            for k in a:
                if k != "published_at":
                    self.assertEqual(a[k], attempts[0][k], k)   # only published_at may differ
        self.assertNotEqual(attempts[0]["published_at"], attempts[2]["published_at"])
        self.assertEqual(len({a["source_system_ref"] for a in attempts}), 1)

    def test_outage_keeps_order_then_recovers(self):
        sink = Sink()
        sink.fail = True
        _, pub_clock, pub = make(sink)
        pub_clock.set("2026-11-23T09:00:01.000Z")
        clock = FakeClock("2026-11-23T09:00:00.000Z")
        s = de.ScanEventSession(pub, ACME, "scn_x", clock=clock)
        s.record_source_succeeded("AWS_BEDROCK", [])
        s.queue_metadata_updated(agent_id=new_agent_id(), metadata_version=2,
                                 previous_metadata_version=1, changed_fields=["name"])
        s.commit_and_publish(lambda: None)
        s.finish_scan()
        self.assertEqual(sink.events, [])
        self.assertEqual(len(pub.outbox), 2)
        refs = [e["source_system_ref"] for e in pub.outbox]
        sink.fail = False
        self.assertTrue(pub.drain())
        self.assertEqual([e["event_type"] for e in sink.events],
                         [de.AGENT_METADATA_UPDATED, de.DISCOVERY_SCAN_COMPLETED])
        self.assertEqual([e["source_system_ref"] for e in sink.events], refs)

    def test_published_at_never_before_occurred_at(self):
        sink, pub, clock, s = self.session()
        clock.set("2026-11-23T09:00:30.000Z")            # registry clock ahead of publisher clock
        s.queue_metadata_updated(agent_id=new_agent_id(), metadata_version=2,
                                 previous_metadata_version=1, changed_fields=["name"])
        s.commit_and_publish(lambda: None)
        self.assertGreaterEqual(sink.events[0]["published_at"], sink.events[0]["occurred_at"])

    def test_unique_refs_and_event_id_not_populated(self):
        sink, pub, clock, s = self.session()
        s.record_source_succeeded("AWS_BEDROCK", [])
        for v in (2, 3, 4):
            s.queue_metadata_updated(agent_id=new_agent_id(), metadata_version=v,
                                     previous_metadata_version=v - 1, changed_fields=["name"])
        s.commit_and_publish(lambda: None)
        s.finish_scan()
        refs = [e["source_system_ref"] for e in sink.events]
        self.assertEqual(len(refs), len(set(refs)))
        for e in sink.events:
            self.assertNotIn("event_id", e)                      # B2 creates event_id; the key is not included
            self.assertTrue(de.is_valid_uuid4(e["source_system_ref"]))
            self.assertEqual(e["correlation_id"], s.correlation_id)


class FailureAndLifecycleRuleTests(unittest.TestCase):
    def test_failure_mapping_table(self):
        expected = {
            "INVALID_CREDENTIALS": ("ERROR", "AUTH_ERROR"),
            "INSUFFICIENT_PERMISSIONS": ("ERROR", "PERMISSION_DENIED"),
            "SOURCE_TIMEOUT": ("TIMEOUT", "SOURCE_TIMEOUT"),
            "SCAN_TIMEOUT": ("TIMEOUT", "SCAN_TIMEOUT"),
            "SOURCE_UNAVAILABLE": ("UNAVAILABLE", "SOURCE_UNAVAILABLE"),
            "INCOMPLETE_RESPONSE": ("INCOMPLETE_RESPONSE", "INCOMPLETE_RESPONSE")}
        for k, (cat, code) in expected.items():
            self.assertEqual(de.map_failure(k), {"failure_category": cat, "error_code": code})
        with self.assertRaises(de.UnmappedFailureError):
            de.map_failure("SOMETHING_NEW")

    def new_session(self):
        sink, pub_clock, pub = make()
        pub_clock.set("2026-11-23T09:00:01.000Z")
        return sink, de.ScanEventSession(pub, ACME, "scn_x", clock=FakeClock("2026-11-23T09:00:00.000Z"))

    def test_failed_source_cannot_cause_unreachable_or_deleted(self):
        sink, s = self.new_session()
        s.record_source_failed("AZURE_AI_FOUNDRY", "INVALID_CREDENTIALS")
        for state, reason in (("UNREACHABLE", "NOT_VERIFIED_IN_RECENT_SCAN"), ("DELETED", "SOURCE_REPORTED_DELETED")):
            with self.assertRaises(de.LifecycleRuleError):
                s.queue_lifecycle_changed(agent_id=new_agent_id(), previous_state="ACTIVE",
                                          new_state=state, metadata_version=2, previous_metadata_version=1,
                                          reason_code=reason, source_type="AZURE_AI_FOUNDRY")
        with self.assertRaises(de.LifecycleRuleError):          # source never recorded at all
            s.queue_lifecycle_changed(agent_id=new_agent_id(), previous_state="ACTIVE",
                                      new_state="DELETED", metadata_version=2, previous_metadata_version=1,
                                      reason_code="SOURCE_REPORTED_DELETED", source_type="AWS_BEDROCK")

    def test_deleted_needs_the_source_reported_reason(self):
        sink, s = self.new_session()
        s.record_source_succeeded("AWS_BEDROCK", [])
        with self.assertRaises(de.EventValidationError):        # DELETED with another reason
            s.queue_lifecycle_changed(agent_id=new_agent_id(), previous_state="ACTIVE",
                                      new_state="DELETED", metadata_version=2, previous_metadata_version=1,
                                      reason_code="PROVIDER_STATUS")
        with self.assertRaises(de.EventValidationError):        # NOT_VERIFIED must not delete
            s.queue_lifecycle_changed(agent_id=new_agent_id(), previous_state="ACTIVE",
                                      new_state="DELETED", metadata_version=2, previous_metadata_version=1,
                                      reason_code="NOT_VERIFIED_IN_RECENT_SCAN", source_type="AWS_BEDROCK")
        s.queue_lifecycle_changed(agent_id=new_agent_id(), previous_state="ACTIVE", new_state="DELETED",
                                  metadata_version=2, previous_metadata_version=1,
                                  reason_code="SOURCE_REPORTED_DELETED", source_type="AWS_BEDROCK")

    def test_status_decision(self):
        for setup, scan_failure, expected in (
            (lambda s: (s.record_source_succeeded("AWS_BEDROCK", []),
                        s.record_source_succeeded("AZURE_AI_FOUNDRY", [])), None, de.DISCOVERY_SCAN_COMPLETED),
            (lambda s: (s.record_source_succeeded("AWS_BEDROCK", []),
                        s.record_source_failed("AZURE_AI_FOUNDRY", "SOURCE_UNAVAILABLE")), None, de.DISCOVERY_SCAN_PARTIAL),
            (lambda s: (s.record_source_failed("AWS_BEDROCK", "INCOMPLETE_RESPONSE"),
                        s.record_source_failed("AZURE_AI_FOUNDRY", "SOURCE_TIMEOUT")), None, de.DISCOVERY_SCAN_FAILED),
            (lambda s: (s.record_source_succeeded("AWS_BEDROCK", []),), "SCAN_TIMEOUT", de.DISCOVERY_SCAN_FAILED),
        ):
            sink, s = self.new_session()
            setup(s)
            ev = s.finish_scan(scan_failure)
            self.assertEqual(ev["event_type"], expected)
            de.validate_event(sink.events[-1])

    def test_metadata_version_rules(self):
        sink, s = self.new_session()
        aid = new_agent_id()
        with self.assertRaises(de.EventValidationError):        # skipped a version
            s.queue_metadata_updated(agent_id=aid, metadata_version=5, previous_metadata_version=3,
                                     changed_fields=["name"])
        s.queue_metadata_updated(agent_id=aid, metadata_version=4, previous_metadata_version=3,
                                 changed_fields=["name"])
        with self.assertRaises(ValueError):                     # 2nd event for the same bump
            s.queue_lifecycle_changed(agent_id=aid, previous_state="ACTIVE", new_state="QUARANTINED",
                                      metadata_version=4, previous_metadata_version=3,
                                      reason_code="INTEGRITY_CONCERN")
        with self.assertRaises(de.EventValidationError):        # lifecycle_state is not a metadata change
            s.queue_metadata_updated(agent_id=aid, metadata_version=5, previous_metadata_version=4,
                                     changed_fields=["lifecycle_state"])

    def test_events_cannot_carry_extra_data(self):
        sink, s = self.new_session()
        s.record_source_succeeded("AWS_BEDROCK", [])
        ev = de.build_event(event_type=de.AGENT_METADATA_UPDATED, tenant_id=ACME, correlation_id=CORR,
                            scan_id="scn_x", occurred_at="2026-11-23T09:00:00.000Z", agent_id=new_agent_id(),
                            metadata_version=2, change_summary={"reason_code": "SOURCE_METADATA_CHANGED",
                                                                "changed_fields": ["metadata"]},
                            payload={"previous_metadata_version": 1, "api_key": "AKIA..."})
        ev["published_at"] = "2026-11-23T09:00:01.000Z"
        with self.assertRaises(de.EventValidationError):
            de.validate_event(ev)


class HookPointProducerTests(unittest.TestCase):
    """Producer hook points from the build's INTEGRATION_HANDOFF.md: snapshot-derived InventoryChange ->
    event. Records below are plain dicts shaped like the stored inventory record (no inventory needed)."""

    def rec(self, **kw):
        r = {"tenant_id": "tnt_t", "agent_id": new_agent_id(), "name": "n", "lifecycle_state": "ACTIVE",
             "metadata_version": 1, "first_seen_at": "2026-11-24T10:00:00.000Z",
             "last_seen_at": "2026-11-24T10:00:00.000Z",
             "source_references": [{"source_type": "aws_bedrock", "external_id": "X1",
                                    "observed_at": "2026-11-24T10:00:00.000Z"}]}
        r.update(kw)
        return r

    def session(self):
        return de.ScanEventSession(de.EventPublisher(lambda e: None), "tnt_t", "scn_hook_01")

    def test_no_change_when_version_is_unchanged_even_if_last_seen_moves(self):
        before = self.rec()
        after = dict(before, last_seen_at="2026-11-24T12:00:00.000Z")
        self.assertIsNone(de.diff_records(before, after))

    def test_version_jump_other_than_one_is_refused_not_invented(self):
        before = self.rec()
        with self.assertRaises(ValueError):
            de.diff_records(before, dict(before, metadata_version=3))

    def test_change_types(self):
        before = self.rec()
        self.assertEqual(de.diff_records(None, before).change_type, de.AGENT_DISCOVERED)
        self.assertEqual(de.diff_records(before, dict(before, name="m", metadata_version=2)).change_type,
                         de.AGENT_METADATA_UPDATED)
        self.assertEqual(de.diff_records(before, dict(before, lifecycle_state="DELETED", metadata_version=2)).change_type,
                         de.AGENT_LIFECYCLE_CHANGED)

    def test_build_event_for_each_change_uses_stored_id_and_version_and_no_event_id(self):
        before = self.rec()
        p = de.DiscoveryEventProducer(self.session())
        e1 = p.build_event(de.diff_records(None, before, "scn_hook_01"))
        e2 = p.build_event(de.diff_records(before, dict(before, name="m", metadata_version=2)))
        e3 = p.build_event(de.diff_records(dict(before, name="m", metadata_version=2),
                                           dict(before, name="m", lifecycle_state="QUARANTINED", metadata_version=3)))
        for e, version in ((e1, 1), (e2, 2), (e3, 3)):
            self.assertEqual(e["agent_id"], before["agent_id"])
            self.assertEqual(e["metadata_version"], version)
            self.assertNotIn("event_id", e)
            self.assertEqual(set(e), set(de.ENVELOPE_KEYS) - {"event_id"})
        self.assertEqual(e1["payload"]["source_reference"]["source_type"], "AWS_BEDROCK")   # mapped from the stored key
        self.assertEqual(e2["change_summary"]["changed_fields"], ["name"])
        self.assertEqual((e3["payload"]["new_state"], e3["change_summary"]["reason_code"]),
                         ("QUARANTINED", "INTEGRITY_CONCERN"))
        self.assertEqual(e3["change_summary"]["changed_fields"], ["lifecycle_state"])

    def test_reason_code_follows_the_new_state(self):
        self.assertEqual(de.REASON_FOR_NEW_STATE, {"QUARANTINED": "INTEGRITY_CONCERN",
                                                   "DELETED": "SOURCE_REPORTED_DELETED",
                                                   "UNREACHABLE": "NOT_VERIFIED_IN_RECENT_SCAN",
                                                   "DORMANT": "DORMANCY_PERIOD_EXCEEDED", "ACTIVE": "PROVIDER_STATUS"})
        self.assertTrue(set(de.REASON_FOR_NEW_STATE.values()) <= set(de.LIFECYCLE_REASON_CODES))

    def test_already_uppercase_stored_source_type_passes_through(self):
        r = self.rec(source_references=[{"source_type": "AZURE_AI_FOUNDRY", "external_id": "X1",
                                         "first_observed_at": "2026-11-24T09:00:00.000Z",
                                         "last_observed_at": "2026-11-24T10:00:00.000Z", "scan_id": "scn_old"}])
        e = de.DiscoveryEventProducer(self.session()).build_event(de.diff_records(None, r))
        ref = e["payload"]["source_reference"]
        self.assertEqual((ref["source_type"], ref["first_observed_at"], ref["scan_id"]),
                         ("AZURE_AI_FOUNDRY", "2026-11-24T09:00:00.000Z", "scn_hook_01"))   # scan_id = the scan's

    def test_build_event_needs_a_session(self):
        with self.assertRaises(ValueError):
            de.DiscoveryEventProducer().build_event(de.diff_records(None, self.rec()))

    def test_plain_uuid_agent_id_is_refused_not_repaired(self):
        r = self.rec(agent_id=str(_uuid.uuid4()))
        with self.assertRaises(de.EventValidationError):
            de.DiscoveryEventProducer(self.session()).build_event(de.diff_records(None, r))

    def test_scan_events_carry_b2_fields_in_the_right_place(self):
        sink = de.InMemoryEventSink()
        s = de.ScanEventSession(de.EventPublisher(sink), "tnt_t", "scn_b2_01")
        s.record_source_succeeded("AWS_BEDROCK", [])
        s.record_source_failed("AZURE_AI_FOUNDRY", "INVALID_CREDENTIALS")
        t = s.finish_scan()
        self.assertEqual(t["event_type"], de.DISCOVERY_SCAN_PARTIAL)
        self.assertNotIn("event_id", t)
        self.assertNotIn("scan_error_code", t["payload"])                 # only on FAILED scans
        self.assertTrue(all("source_error_code" in x and "error_code" not in x for x in t["payload"]["sources"]))
        s2 = de.ScanEventSession(de.EventPublisher(sink), "tnt_t", "scn_b2_02")
        s2.record_source_failed("AWS_BEDROCK", "SOURCE_TIMEOUT")
        f = s2.finish_scan("SCAN_TIMEOUT")
        self.assertEqual(f["event_type"], de.DISCOVERY_SCAN_FAILED)
        self.assertIn("scan_error_code", f["payload"])
        self.assertNotIn("error_code", f["payload"])
        self.assertNotIn("source_error_code", {k for k in f["payload"] if k != "sources"})


if __name__ == "__main__":
    unittest.main(verbosity=2)

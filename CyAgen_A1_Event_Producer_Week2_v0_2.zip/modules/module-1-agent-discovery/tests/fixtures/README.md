# Test fixtures - provenance

These are copies of files supplied by Pod A1, kept **unchanged** as the reference for expected output.
They are FIXTURES, not output from a live discovery source.

| Folder | Origin | Used for |
|---|---|---|
| `A1_Discovery_Event_Samples/` | `A1_Discovery_Event_Samples_v0_2.zip` (event contract v0.2 samples) | Expected output of the producer; validator input |
| `A1_A2_Dashboard_Sample_Data/` | `A1_A2_Dashboard_Sample_Data.zip` (Field Mapping v0.2 / API spec v0.1 samples) | Source of agent records, per-source observations and scan records used to build scenarios and cross-check scan results |

The event samples contain a fixture-only `_note` field that is not part of the contract; the producer never emits it.
Do not edit these files. If the pod issues new samples, replace the folders and re-run the tests and
`scripts/generate_deliverables.py`.

## Contract v0.2
`A1_Discovery_Event_Samples/` holds the official v0.2 samples (no `event_id`, `source_error_code` inside `sources[]`,
`scan_error_code` on FAILED scans, `schema_version` "0.2"). They are used as supplied; the old v0.1 samples and the
`fixture_adapter.py` that patched them are removed. Tests only drop the fixture-only `_note` before comparing.

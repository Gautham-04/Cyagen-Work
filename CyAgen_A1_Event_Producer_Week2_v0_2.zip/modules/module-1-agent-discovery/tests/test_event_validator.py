"""
test_event_validator.py - tests for src/event_validator.py (NEW FILE)

Run (from modules/module-1-agent-discovery):
    python -m unittest discover -s tests -v

Three kinds of test:
  1. every supplied company fixture passes the validator (no FAIL);
  2. every deliberately broken event in negative_cases.py is REJECTED with the
     expected rule (so the validator is proven able to fail);
  3. the producer and the independent validator agree on the producer's output.
"""
import glob
import json
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "src"))
sys.path.insert(0, HERE)

import discovery_events as de      # noqa: E402
import event_validator as ev       # noqa: E402
import negative_cases as neg       # noqa: E402
import uuid as _uuid              # noqa: E402


def new_agent_id():
    """TEST-ONLY helper (well-formed agt_ id); the producer and validator never create ids."""
    return "agt_" + str(_uuid.uuid4())

FIXTURES = os.path.join(HERE, "fixtures", "A1_Discovery_Event_Samples")


def load_fixtures(raw=False):
    """The 9 official v0.2 samples. Default: as supplied minus the fixture-only `_note`.
    raw=True: exactly as supplied (includes `_note`)."""
    fx = {}
    for path in sorted(glob.glob(os.path.join(FIXTURES, "*.json"))):
        with open(path, encoding="utf-8") as fh:
            d = json.load(fh)
        if not raw:
            d.pop("_note", None)
        fx[os.path.splitext(os.path.basename(path))[0]] = d
    if len(fx) != 9:
        raise AssertionError("expected 9 fixture files in %s, found %d" % (FIXTURES, len(fx)))
    return fx


class SuppliedFixtureTests(unittest.TestCase):
    def test_every_fixture_has_no_fail(self):
        for name, event in load_fixtures().items():
            with self.subTest(name):
                fails = [f for f in ev.check_event(event) if f["level"] == "FAIL"]
                self.assertEqual(fails, [])

    def test_raw_v0_2_samples_have_no_fail_and_no_event_id(self):
        """The official v0.2 samples, exactly as supplied, must pass: no event_id key, source_error_code /
        scan_error_code, schema_version 0.2."""
        for name, event in load_fixtures(raw=True).items():
            with self.subTest(name):
                self.assertNotIn("event_id", event)
                self.assertEqual(event["schema_version"], "0.2")
                self.assertEqual([f for f in ev.check_event(event) if f["level"] == "FAIL"], [])

    def test_fixture_note_is_only_a_warning(self):
        warns = [f["rule"] for f in ev.check_event(load_fixtures(raw=True)["agent_discovered"])
                 if f["level"] == "WARN"]
        self.assertEqual(warns, ["ENV-FIXTURE-NOTE"])

    def test_event_id_null_or_omitted_is_accepted(self):
        e = load_fixtures()["agent_discovered"]
        e["event_id"] = None
        self.assertIsNone(e["event_id"])
        self.assertEqual([f for f in ev.check_event(e) if f["level"] == "FAIL"], [])
        del e["event_id"]
        self.assertEqual([f for f in ev.check_event(e) if f["level"] == "FAIL"], [])

    def test_fixture_batch_has_no_fail(self):
        res = ev.validate_batch(list(load_fixtures().values()))
        self.assertTrue(res["passed"])


class CountConsistencyTests(unittest.TestCase):
    def rules(self, events):
        return [f["rule"] for fs in ev.check_scan_groups(events).values() for f in fs]

    def test_complete_scan_set_has_no_count_warning(self):
        fx = load_fixtures()
        scan = [fx[k] for k in ("agent_metadata_updated", "agent_lifecycle_changed",
                                "agent_identity_resolved", "discovery_scan_partial")]
        self.assertNotIn("GROUP-COUNTS-VS-EVENTS", self.rules(scan))

    def test_incomplete_scan_set_is_flagged_as_warning_not_failure(self):
        fx = load_fixtures()      # fixture says agents_updated=2 but only 1 agent event is supplied
        scan = [fx["agent_lifecycle_changed__unreachable"], fx["discovery_scan_completed"]]
        self.assertIn("GROUP-COUNTS-VS-EVENTS", self.rules(scan))
        self.assertTrue(ev.validate_batch(scan)["passed"])


class NegativeCaseTests(unittest.TestCase):
    def test_every_broken_event_is_rejected(self):
        fx = load_fixtures()
        all_cases = neg.cases()
        self.assertGreaterEqual(len(all_cases), 30)
        for case in all_cases:
            with self.subTest(case["name"]):
                caught, findings = neg.evaluate(case, fx, ev)
                self.assertTrue(caught, "expected %s but got %s" % (case["expect"], [
                    (f["category"], f["rule"]) for f in findings]))

    def test_each_case_breaks_only_what_it_claims(self):
        """A broken event should not ALSO be reported as a different category
        of failure by accident (keeps the cases honest)."""
        fx = load_fixtures()
        for case in neg.cases():
            if case["mode"] != "event":
                continue
            with self.subTest(case["name"]):
                _, findings = neg.evaluate(case, fx, ev)
                cats = {f["category"] for f in findings if f["level"] == "FAIL"}
                self.assertIn(case["expect"][0], cats)


class ProducerAgreementTests(unittest.TestCase):
    def test_producer_output_passes_independent_validator(self):
        sunk = []
        pub = de.EventPublisher(sunk.append)
        s = de.ScanEventSession(pub, "tnt_test_001", "scn_test_01")
        a, b = new_agent_id(), new_agent_id()
        s.record_source_succeeded("AWS_BEDROCK", [a, b])
        s.record_source_failed("AZURE_AI_FOUNDRY", "INSUFFICIENT_PERMISSIONS")
        now = de.format_utc(de.utc_now())
        s.queue_agent_discovered(agent_id=a, lifecycle_state="ACTIVE", source_reference={
            "source_type": "AWS_BEDROCK", "external_id": "TEST-1", "first_observed_at": now,
            "last_observed_at": now, "scan_id": "scn_test_01"}, metadata_version=1)
        s.queue_metadata_updated(agent_id=b, metadata_version=2, previous_metadata_version=1,
                                 changed_fields=["purpose"])
        s.commit_and_publish(lambda: None)
        s.finish_scan()
        res = ev.validate_batch(sunk, ordered=True)
        self.assertTrue(res["passed"], res)
        self.assertEqual([p["passed"] for p in res["per_event"]], [True] * 3)

    def test_retry_deliveries_pass_retry_check(self):
        sunk = []
        calls = {"n": 0}

        def flaky(e):
            calls["n"] += 1
            sunk.append(json.loads(json.dumps(e)))     # record every attempt
            if calls["n"] < 3:
                raise TimeoutError("simulated")
        pub = de.EventPublisher(flaky, sleep=lambda s: None)
        s = de.ScanEventSession(pub, "tnt_test_001", "scn_test_02")
        s.queue_metadata_updated(agent_id=new_agent_id(), metadata_version=2,
                                 previous_metadata_version=1, changed_fields=["name"])
        s.commit_and_publish(lambda: None)
        self.assertEqual(len(sunk), 3)
        self.assertEqual(ev.check_retries(sunk), [])


class SecretHandlingTests(unittest.TestCase):
    def test_secret_value_is_never_echoed(self):
        e = load_fixtures()["agent_metadata_updated"]
        e["payload"]["note"] = "AKIAIOSFODNN7EXAMPLE"
        text = json.dumps(ev.check_event(e))
        self.assertNotIn("AKIAIOSFODNN7EXAMPLE", text)
        self.assertIn("event.payload.note", text)        # location only


if __name__ == "__main__":
    unittest.main(verbosity=2)

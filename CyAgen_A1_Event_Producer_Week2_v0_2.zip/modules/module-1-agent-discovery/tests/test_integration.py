"""
test_integration.py - events produced from the week_2 build's REAL inventory (src/ingest.py, UNMODIFIED) and
lifecycle (src/lifecycle.py).

Nothing here builds an event by hand: every agent event comes from a change the `ingest.Inventory`
COMMITTED, detected by `discovery_events.InventoryObserver` (snapshot before / compare after, per the build's
INTEGRATION_HANDOFF.md) and published through `discovery_events.InventoryEventBridge`. Agent IDs and
metadata_versions asserted below are read back from the stored inventory record.

ID-FORMAT SHIM: the supplied ingest.py still mints a bare UUID (Field Mapping v0.2 section 12: Soumojit's
agt_ alignment is "In progress"). For the tests, module-level setUp swaps the `uuid` module INSIDE ingest.py for
one whose uuid4() is prefixed "agt_" - the ID is still minted by the inventory's own code path. Tests that need the
real, unaligned behaviour (PlainUuidBlockerTests) switch the shim off. Input records are synthetic fixtures
(tests/fixtures.json, Soham's). This is test evidence, not production output.

Run (from modules/module-1-agent-discovery):   python -m pytest -q tests
"""
import copy
import json
import os
import sys
import unittest
from datetime import datetime, timedelta, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "src"))
sys.path.insert(0, HERE)

import discovery_events as de   # noqa: E402
import event_validator as ev    # noqa: E402
import ingest                   # noqa: E402
import lifecycle                # noqa: E402
import types as _types          # noqa: E402
import uuid as _real_uuid       # noqa: E402

_AGT_UUID = _types.SimpleNamespace(uuid4=lambda: "agt_" + str(_real_uuid.uuid4()))   # simulates the pending alignment


def use_agt_shim(on=True):
    ingest.uuid = _AGT_UUID if on else _real_uuid


def setUpModule():
    use_agt_shim(True)


def tearDownModule():
    use_agt_shim(False)                     # leave Soham's tests exactly as delivered

with open(os.path.join(HERE, "fixtures.json"), encoding="utf-8") as fh:
    FX = json.load(fh)

T, AWS, AZ = "tnt_int_001", "AWS_BEDROCK", "AZURE_AI_FOUNDRY"     # approved values, used in EVENTS
AWS_IN, AZ_IN = "aws_bedrock", "azure_ai"                          # Soham's inventory keys (mapped by SOURCE_ALIASES)


def aid(res):
    """Canonical agent_id of an ingest Result (Soham's Result has no agent_id attribute)."""
    return res.record["agent_id"]


class Clock:
    def __init__(self, iso="2026-11-24T10:00:00.000Z"):
        self.set(iso)

    def set(self, iso):
        self._t = datetime.strptime(iso, "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=timezone.utc)

    def __call__(self):
        return self._t


class _Facade:
    """Mutating calls go through the observer; everything else (get, list_for_tenant, review_log) is the inventory."""

    def __init__(self, observer, real):
        self._o, self._r = observer, real

    def __getattr__(self, name):
        if name in ("ingest", "mark_unverified", "quarantine_existing"):
            return getattr(self._o, name)
        return getattr(self._r, name)


class Harness:
    """One inventory that lives across several scans (like the real registry would)."""

    def __init__(self, dormancy_days=14):
        self.inv = None
        self.real = ingest.Inventory(dormancy_days)    # Soham's unmodified Inventory
        self.events = de.InMemoryEventSink()          # the agreed in-memory event collection
        self.observer = None
        self.n = 0

    def scan(self, scan_id=None, at="2026-11-24T10:00:00.000Z"):
        self.n += 1
        self.clock = Clock(at)
        pub = de.EventPublisher(self.events, clock=Clock("2026-11-24T10:00:30.000Z"), sleep=lambda s: None)
        self.session = de.ScanEventSession(pub, T, scan_id or "scn_int_%02d" % self.n, clock=self.clock)
        self.bridge = de.InventoryEventBridge(self.session)
        self.observer = de.InventoryObserver(self.real, self.bridge)
        self.inv = _Facade(self.observer, self.real)
        self.at = at
        return self

    def ingest(self, raw, source=AWS_IN, at=None):
        return self.inv.ingest(raw, T, source, at or self.at)

    def stored(self, external_id, source=AWS_IN):
        return self.real.get(T, source, external_id)

    def new_events(self, since):
        return self.events.events[since:]


def aws(**kw):
    return dict(FX["aws_valid"], **kw)


def types(events):
    return [e["event_type"] for e in events]


class DiscoveredTests(unittest.TestCase):
    def test_new_agent_produces_agent_discovered(self):
        h = Harness().scan()
        res = h.ingest(aws())
        h.bridge.source_succeeded(AWS, [aid(res)])
        h.bridge.finish()
        self.assertEqual(types(h.events.events), [de.AGENT_DISCOVERED, de.DISCOVERY_SCAN_COMPLETED])
        e = h.events.events[0]
        rec = h.stored("ABC123")
        self.assertEqual(e["payload"]["lifecycle_state"], "ACTIVE")
        self.assertEqual(e["payload"]["source_reference"], {
            "source_type": AWS, "external_id": "ABC123", "first_observed_at": rec["first_seen_at"],
            "last_observed_at": rec["last_seen_at"], "scan_id": "scn_int_01"})
        self.assertEqual(e["change_summary"], {"reason_code": "NEW_AGENT_OBSERVED", "changed_fields": []})
        self.assertTrue(ev.validate_batch(h.events.events, ordered=True)["passed"])

    def test_azure_agent_uses_lifecycle_provider_mapping(self):
        h = Harness().scan()
        res = h.ingest(FX["azure_valid"], source=AZ_IN)
        h.bridge.source_succeeded(AZ, [aid(res)])
        self.assertEqual(h.events.events[0]["payload"]["source_reference"]["source_type"], AZ)
        self.assertEqual(h.events.events[0]["payload"]["lifecycle_state"], "ACTIVE")


class CanonicalIdAndVersionTests(unittest.TestCase):
    def test_events_use_the_canonical_inventory_agent_id(self):
        h = Harness().scan()
        res = h.ingest(aws())
        h.bridge.source_succeeded(AWS, [aid(res)])
        e = h.events.events[0]
        rec = h.stored("ABC123")
        self.assertEqual(e["agent_id"], rec["agent_id"])
        self.assertEqual(e["agent_id"], aid(res))
        self.assertTrue(rec["agent_id"].startswith("agt_"))
        self.assertTrue(de.is_valid_agent_id(e["agent_id"]))
        # a later change on the same agent keeps the SAME id
        h.bridge.finish()
        h.scan()
        h.ingest(aws(agentName="Sales Bot v2"))
        h.bridge.source_succeeded(AWS, [rec["agent_id"]])
        self.assertEqual(h.events.events[-1]["agent_id"], rec["agent_id"])

    def test_events_use_the_updated_inventory_metadata_version(self):
        h = Harness().scan()
        h.ingest(aws())
        h.bridge.source_succeeded(AWS, [h.stored("ABC123")["agent_id"]])
        self.assertEqual(h.events.events[0]["metadata_version"], h.stored("ABC123")["metadata_version"])
        h.bridge.finish()
        h.scan()
        h.ingest(aws(agentName="Sales Bot v2"))
        h.bridge.source_succeeded(AWS, [h.stored("ABC123")["agent_id"]])
        e = h.events.events[-1]
        self.assertEqual(e["event_type"], de.AGENT_METADATA_UPDATED)
        self.assertEqual(e["metadata_version"], h.stored("ABC123")["metadata_version"])
        self.assertEqual(e["metadata_version"], 2)
        self.assertEqual(e["payload"]["previous_metadata_version"], 1)

    def test_initial_version_comes_from_the_inventory(self):
        h = Harness().scan()
        h.ingest(aws())
        self.assertEqual(h.stored("ABC123")["metadata_version"], 1)
        # lifecycle.py agrees with ingest.py about a new agent's first version
        new = lifecycle.process_provider_observation(None, source_type=AWS, source_status="PREPARED",
                                                     observed_at=datetime(2026, 11, 24, tzinfo=timezone.utc))
        self.assertEqual(new.metadata_version, 1)

    def test_producer_has_no_id_or_version_generator(self):
        self.assertFalse(hasattr(de, "new_agent_id"))
        self.assertFalse(hasattr(de, "mint_agent_id"))
        s = de.ScanEventSession(de.EventPublisher(lambda e: None), T, "scn_x")
        with self.assertRaises(TypeError):                   # version must be supplied, never defaulted
            s.queue_agent_discovered(agent_id="agt_" + str(_real_uuid.uuid4()), lifecycle_state="ACTIVE",
                                     source_reference={})

    def test_ids_are_never_reissued_for_the_same_source_agent(self):
        h = Harness().scan()
        a = aid(h.ingest(aws()))
        h.ingest(aws(agentStatus="DELETED"))
        self.assertEqual(h.stored("ABC123")["lifecycle_state"], "DELETED")
        h.ingest(aws(agentStatus="ACTIVE"), at="2026-11-24T11:00:00.000Z")    # same external id again
        self.assertEqual(h.stored("ABC123")["agent_id"], a)                   # same immutable id, not a new one
        other = aid(h.ingest(dict(FX["aws_same_name_other_id"])))
        self.assertNotEqual(other, a)
        self.assertEqual(len({r["agent_id"] for r in h.inv.list_for_tenant(T)}), 2)


class MetadataAndLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.h = Harness().scan()
        self.aid = aid(self.h.ingest(aws()))
        self.h.bridge.source_succeeded(AWS, [self.aid])
        self.h.bridge.finish()
        self.base = len(self.h.events.events)

    def test_tracked_metadata_change_produces_agent_metadata_updated(self):
        self.h.scan()
        self.h.ingest(aws(agentName="Renamed Bot"))
        self.h.bridge.source_succeeded(AWS, [self.aid])
        e = self.h.new_events(self.base)[0]
        self.assertEqual(e["event_type"], de.AGENT_METADATA_UPDATED)
        self.assertEqual(e["change_summary"], {"reason_code": "SOURCE_METADATA_CHANGED", "changed_fields": ["name"]})
        self.assertNotIn("Renamed Bot", json.dumps(e))          # names of fields only, never values

    def test_lifecycle_change_produces_agent_lifecycle_changed(self):
        self.h.scan()
        self.h.ingest(aws(agentStatus="DELETED"))
        self.h.bridge.source_succeeded(AWS, [self.aid])
        e = self.h.new_events(self.base)[0]
        self.assertEqual(e["event_type"], de.AGENT_LIFECYCLE_CHANGED)
        self.assertEqual((e["payload"]["previous_state"], e["payload"]["new_state"]), ("ACTIVE", "DELETED"))
        self.assertEqual(e["change_summary"], {"reason_code": "SOURCE_REPORTED_DELETED",
                                               "changed_fields": ["lifecycle_state"]})
        self.assertEqual(e["metadata_version"], 2)

    def test_missing_agent_rules_produce_unreachable_then_dormant(self):
        h = Harness(dormancy_days=2).scan()
        aid_ = aid(h.ingest(aws()))
        h.bridge.source_succeeded(AWS, [aid_])
        h.bridge.finish()
        base = len(h.events.events)
        h.scan()
        seen = datetime(2026, 11, 24, 10, tzinfo=timezone.utc)
        h.inv.mark_unverified(T, AWS_IN, "ABC123", scan_status="SUCCEEDED", now=seen + timedelta(hours=2),
                              verification_failed=True)
        h.bridge.source_succeeded(AWS, [])
        u = h.new_events(base)[0]
        self.assertEqual((u["payload"]["new_state"], u["change_summary"]["reason_code"]),
                         ("UNREACHABLE", "NOT_VERIFIED_IN_RECENT_SCAN"))
        h.bridge.finish()
        n = len(h.events.events)
        h.scan()
        h.inv.mark_unverified(T, AWS_IN, "ABC123", scan_status="SUCCEEDED", now=seen + timedelta(days=3),
                              verification_failed=True)
        h.bridge.source_succeeded(AWS, [])
        d = h.new_events(n)[0]
        self.assertEqual((d["payload"]["previous_state"], d["payload"]["new_state"],
                          d["change_summary"]["reason_code"]), ("UNREACHABLE", "DORMANT", "DORMANCY_PERIOD_EXCEEDED"))
        self.assertEqual(d["metadata_version"], 3)

    def test_default_dormancy_is_14_days_and_configurable(self):
        self.assertEqual(ingest.DEFAULT_DORMANCY_DAYS, 14)
        self.assertEqual(ingest.Inventory().dormancy_period, timedelta(days=14))
        seen = datetime(2026, 11, 24, 10, tzinfo=timezone.utc)
        for days, expected in ((13, "UNREACHABLE"), (14, "DORMANT")):
            h = Harness().scan()
            h.ingest(aws())
            h.inv.mark_unverified(T, AWS_IN, "ABC123", scan_status="SUCCEEDED", now=seen + timedelta(days=days),
                                  verification_failed=True)
            h.bridge.source_succeeded(AWS, [])
            last = h.events.events[-1]
            self.assertEqual(last["payload"]["new_state"], expected, days)
        h2 = Harness(dormancy_days=3).scan()
        h2.ingest(aws())
        h2.inv.mark_unverified(T, AWS_IN, "ABC123", scan_status="SUCCEEDED", now=seen + timedelta(days=3),
                               verification_failed=True)
        self.assertEqual(h2.stored("ABC123")["lifecycle_state"], "DORMANT")

    def test_failed_source_can_never_justify_unreachable(self):
        self.h.scan()
        self.h.inv.mark_unverified(T, AWS_IN, "ABC123", scan_status="FAILED",
                                   now=datetime(2026, 11, 24, 12, tzinfo=timezone.utc), verification_failed=True)
        with self.assertRaises(de.LifecycleRuleError):
            self.h.bridge.source_failed(AWS, "INVALID_CREDENTIALS")
        self.assertEqual(self.h.bridge.pending_changes, 1)       # committed change is NOT silently dropped
        self.assertEqual(self.h.new_events(self.base), [])        # and nothing was published

    def test_no_event_when_nothing_changes(self):
        self.h.scan(at="2026-11-24T16:00:00.000Z")
        before = copy.deepcopy(self.h.stored("ABC123"))
        self.h.ingest(aws())                                       # identical observation, later time
        self.assertEqual(self.h.bridge.pending_changes, 0)
        self.h.bridge.source_succeeded(AWS, [self.aid])
        self.h.bridge.finish()
        self.assertEqual(types(self.h.new_events(self.base)), [de.DISCOVERY_SCAN_COMPLETED])
        after = self.h.stored("ABC123")
        self.assertEqual(after["metadata_version"], before["metadata_version"])
        self.assertGreater(after["last_seen_at"], before["last_seen_at"])   # last_seen moves, not tracked
        terminal = self.h.events.events[-1]["payload"]
        self.assertEqual((terminal["agents_new"], terminal["agents_updated"], terminal["agents_observed"]), (0, 0, 1))

    def test_delayed_observation_neither_moves_last_seen_back_nor_emits(self):
        self.h.scan(at="2026-11-24T08:00:00.000Z")
        self.h.ingest(aws())
        self.assertEqual(self.h.bridge.pending_changes, 0)
        self.assertGreaterEqual(self.h.stored("ABC123")["last_seen_at"], "2026-11-24T10:00:00.000Z")


class VersionRuleTests(unittest.TestCase):
    def setUp(self):
        self.h = Harness().scan()
        self.aid = aid(self.h.ingest(aws()))
        self.h.bridge.source_succeeded(AWS, [self.aid])
        self.h.bridge.finish()
        self.base = len(self.h.events.events)

    def test_lifecycle_change_increments_version_by_one(self):
        self.h.scan()
        self.h.ingest(aws(agentStatus="DELETED"))
        self.assertEqual(self.h.stored("ABC123")["metadata_version"], 2)

    def test_tracked_metadata_change_increments_version_and_emits_metadata_updated(self):
        """`metadata` is a tracked field in the build's _upsert. Only field NAMES go on the wire."""
        self.h.scan()
        self.h.ingest(aws(metadata={"region": "ap-south-1", "owner_note": "SECRET-LOOKING-VALUE-123"}))
        self.assertEqual(self.h.stored("ABC123")["metadata_version"], 2)
        self.h.bridge.source_succeeded(AWS, [self.aid])
        e = self.h.new_events(self.base)[0]
        self.assertEqual(e["event_type"], de.AGENT_METADATA_UPDATED)
        self.assertEqual(e["change_summary"]["changed_fields"], ["metadata"])
        self.assertEqual((e["metadata_version"], e["payload"]["previous_metadata_version"]), (2, 1))
        self.assertNotIn("ap-south-1", json.dumps(e))
        self.assertNotIn("SECRET-LOOKING-VALUE-123", json.dumps(e))
        # same value again (later observation): no bump, no event
        self.h.scan(at="2026-11-24T12:00:00.000Z")
        self.h.ingest(aws(metadata={"region": "ap-south-1", "owner_note": "SECRET-LOOKING-VALUE-123"}))
        self.assertEqual(self.h.stored("ABC123")["metadata_version"], 2)
        self.assertEqual(self.h.bridge.pending_changes, 0)

    def test_lifecycle_change_with_tracked_field_change_reports_names_only_in_the_bridge(self):
        self.h.scan()
        self.h.ingest(aws(agentStatus="DELETED", metadata={"region": "x"}))
        self.assertEqual(self.h.bridge.pending_changes, 1)

    def test_name_and_state_change_in_one_observation_is_one_bump_and_one_event(self):
        """Soham's rule (test_no_double_bump): one upsert = one version step. The contract allows one
        event per version, so the lifecycle event is emitted and the renamed field is recorded in
        bridge.merged_metadata_fields (OPEN DECISION, see INTEGRATION_NOTES)."""
        self.h.scan()
        self.h.ingest(aws(agentName="Renamed", agentStatus="DELETED"))
        self.assertEqual(self.h.stored("ABC123")["metadata_version"], 2)
        self.h.bridge.source_succeeded(AWS, [self.aid])
        evs = self.h.new_events(self.base)
        self.assertEqual(types(evs), [de.AGENT_LIFECYCLE_CHANGED])
        self.assertEqual((evs[0]["metadata_version"], evs[0]["payload"]["previous_metadata_version"]), (2, 1))
        self.assertEqual(self.h.bridge.merged_metadata_fields,
                         [{"agent_id": self.aid, "metadata_version": 2, "fields": ["name"]}])
        self.assertEqual(self.h.stored("ABC123")["name"], "Renamed")         # the change itself is stored

    def test_version_is_monotonic_and_never_resets(self):
        seen = [self.h.stored("ABC123")["metadata_version"]]
        for i, change in enumerate((aws(agentName="n1"), aws(agentName="n1", agentStatus="DELETED"),
                                    aws(agentName="n2", agentStatus="ACTIVE"))):
            self.h.scan()
            self.h.ingest(change)
            seen.append(self.h.stored("ABC123")["metadata_version"])
        self.assertEqual(seen, sorted(seen))
        self.assertEqual(len(set(seen)), len(seen))
        # n1 (+1); n1+DELETED (+1: lifecycle); n2+ACTIVE from DELETED = resurrection -> QUARANTINED (+1)
        self.assertEqual(seen[-1], 4)


class SourceTypeTests(unittest.TestCase):
    def test_approved_source_types_are_exactly_two_uppercase_values(self):
        self.assertEqual(tuple(ingest.SOURCE_ALIASES.values()), ("AWS_BEDROCK", "AZURE_AI_FOUNDRY"))
        self.assertEqual(de.APPROVED_SOURCE_TYPES, ("AWS_BEDROCK", "AZURE_AI_FOUNDRY"))
        self.assertEqual(set(ingest.FIELD_MAP), set(ingest.SOURCE_ALIASES))

    def test_inventory_keys_are_mapped_to_approved_values_at_the_event_boundary(self):
        h = Harness().scan()
        h.ingest(aws())
        h.ingest(FX["azure_valid"], source=AZ_IN)
        h.bridge.source_succeeded(AWS, []); h.bridge.source_succeeded(AZ, [])
        self.assertEqual([e["payload"]["source_reference"]["source_type"] for e in h.events.events], [AWS, AZ])
        self.assertEqual(h.stored("ABC123")["source_references"][0]["source_type"], AWS_IN)  # storage untouched

    def test_unsupported_values_rejected_everywhere(self):
        inv = ingest.Inventory()
        for bad in ("AWS_BEDROCK", "AZURE_AI_FOUNDRY", "GCP_VERTEX", "", None):
            self.assertEqual(inv.ingest(FX["aws_valid"], T, bad).outcome, ingest.REJECTED, bad)
        s = de.ScanEventSession(de.EventPublisher(lambda e: None), T, "scn_x")
        for bad in ("aws_bedrock", "GCP_VERTEX"):
            with self.assertRaises(ValueError):
                s.record_source_succeeded(bad, [])
        with self.assertRaises(lifecycle.LifecycleError):
            lifecycle.provider_state("aws_bedrock", "ACTIVE")

    def test_validator_rejects_unsupported_source_type(self):
        h = Harness().scan()
        h.ingest(aws())
        h.bridge.source_succeeded(AWS, [h.stored("ABC123")["agent_id"]])
        e = copy.deepcopy(h.events.events[0])
        e["payload"]["source_reference"]["source_type"] = "aws_bedrock"
        self.assertIn("PAY-SOURCE-TYPE", [f["rule"] for f in ev.check_event(e) if f["level"] == "FAIL"])
        with self.assertRaises(de.EventValidationError):
            de.validate_event(e)

    def test_missing_status_is_quarantined_not_stored_with_null_state(self):
        inv = ingest.Inventory()
        raw = {k: v for k, v in FX["aws_valid"].items() if k != "agentStatus"}
        res = inv.ingest(raw, T, AWS_IN)
        self.assertEqual(res.outcome, ingest.REVIEW)                     # new agent -> review, not inserted
        self.assertIsNone(res.record)
        self.assertIsNone(inv.get(T, AWS_IN, "ABC123"))


class B2ChangeTests(unittest.TestCase):
    def failed_and_partial(self):
        h = Harness().scan("scn_p")
        res = h.ingest(aws())
        h.bridge.source_succeeded(AWS, [aid(res)])
        h.bridge.source_failed(AZ, "INVALID_CREDENTIALS")
        partial = h.bridge.finish()
        h2 = Harness().scan("scn_f")
        h2.bridge.source_failed(AWS, "SOURCE_TIMEOUT")
        h2.bridge.source_failed(AZ, "INVALID_CREDENTIALS")
        failed = h2.bridge.finish("SCAN_TIMEOUT")
        return h, partial, failed

    def test_error_code_renamed_in_sources_and_scan_level(self):
        h, partial, failed = self.failed_and_partial()
        for sources in (partial["payload"]["sources"], failed["payload"]["sources"]):
            for s in sources:
                self.assertIn("source_error_code", s)
                self.assertNotIn("error_code", s)
        self.assertEqual(failed["payload"]["scan_error_code"], "SCAN_TIMEOUT")
        self.assertNotIn("error_code", failed["payload"])
        self.assertEqual([s["source_error_code"] for s in failed["payload"]["sources"]],
                         ["SOURCE_TIMEOUT", "AUTH_ERROR"])
        self.assertEqual(partial["payload"]["sources"][1]["source_error_code"], "AUTH_ERROR")
        self.assertIsNone(partial["payload"]["sources"][0]["source_error_code"])
        self.assertNotIn("scan_error_code", partial["payload"])      # only FAILED scans carry it
        self.assertNotIn("error_code", json.dumps([partial, failed]).replace("source_error_code", "")
                         .replace("scan_error_code", ""))
        for e in (partial, failed):
            de.validate_event(dict(e, published_at=e["occurred_at"]))

    def test_old_names_are_rejected_by_validator(self):
        _, partial, failed = self.failed_and_partial()
        old_src = copy.deepcopy(partial)
        old_src["payload"]["sources"][1]["error_code"] = old_src["payload"]["sources"][1].pop("source_error_code")
        old_scan = copy.deepcopy(failed)
        old_scan["payload"]["error_code"] = old_scan["payload"].pop("scan_error_code")
        rules = lambda e: {f["rule"] for f in ev.check_event(dict(e, published_at=e["occurred_at"])) if f["level"] == "FAIL"}
        self.assertIn("B2-SOURCE-ERROR-CODE", rules(old_src))
        self.assertIn("B2-SCAN-ERROR-CODE", rules(old_scan))
        self.assertEqual(rules(partial), set())
        self.assertEqual(rules(failed), set())

    def test_event_id_is_never_generated_or_populated(self):
        h = Harness().scan()
        res = h.ingest(aws())
        h.bridge.source_succeeded(AWS, [aid(res)])
        h.ingest(aws(agentName="x"))
        h.bridge.finish()
        for e in h.events.events:
            self.assertNotIn("event_id", e)              # the key is NOT included at all (task rule)
            self.assertTrue(de.is_valid_uuid4(e["source_system_ref"]))   # Module 1's own identifier
        refs = [e["source_system_ref"] for e in h.events.events]
        self.assertEqual(len(refs), len(set(refs)))
        e = copy.deepcopy(h.events.events[0])
        e["event_id"] = e["source_system_ref"]
        self.assertIn("ID-EVENT-ID-NOT-NULL", [f["rule"] for f in ev.check_event(e) if f["level"] == "FAIL"])
        with self.assertRaises(de.EventValidationError):
            de.validate_event(e)

    def test_event_id_can_be_omitted_instead_of_null(self):
        old = de.EVENT_ID_MODE
        de.EVENT_ID_MODE = "OMIT"
        try:
            h = Harness().scan()
            res = h.ingest(aws())
            h.bridge.source_succeeded(AWS, [aid(res)])
            h.bridge.finish()
            for e in h.events.events:
                self.assertNotIn("event_id", e)
            self.assertTrue(ev.validate_batch(h.events.events, ordered=True)["passed"])
        finally:
            de.EVENT_ID_MODE = old


class ScanTerminalEventTests(unittest.TestCase):
    def test_completed_scan_has_one_terminal_event_and_it_is_last(self):
        h = Harness().scan()
        a = aid(h.ingest(aws()))
        b = aid(h.ingest(FX["aws_same_name_other_id"]))
        h.ingest(aws(agentName="n"))
        h.bridge.source_succeeded(AWS, [a, b])
        h.bridge.source_succeeded(AZ, [])
        term = h.bridge.finish()
        self.assertEqual(term["event_type"], de.DISCOVERY_SCAN_COMPLETED)
        evs = h.events.events
        self.assertEqual(sum(e["event_type"] in de.SCAN_EVENT_TYPES for e in evs), 1)
        self.assertEqual(evs[-1]["event_type"], de.DISCOVERY_SCAN_COMPLETED)
        self.assertEqual(len({e["correlation_id"] for e in evs}), 1)
        p = term["payload"]
        self.assertEqual((p["agents_observed"], p["agents_new"], p["agents_updated"]), (2, 2, 0))
        self.assertTrue(ev.validate_batch(evs, ordered=True)["passed"])
        with self.assertRaises(RuntimeError):
            h.bridge.finish()                                       # nothing may follow the terminal event

    def test_partial_scan_when_one_source_fails(self):
        h = Harness().scan()
        res = h.ingest(aws())
        h.bridge.source_succeeded(AWS, [aid(res)])
        h.bridge.source_failed(AZ, "INSUFFICIENT_PERMISSIONS")
        term = h.bridge.finish()
        self.assertEqual(term["event_type"], de.DISCOVERY_SCAN_PARTIAL)
        self.assertEqual(h.events.events[-1], term | {"published_at": h.events.events[-1]["published_at"]})
        self.assertTrue(ev.validate_batch(h.events.events, ordered=True)["passed"])

    def test_failed_scan_marks_nothing_deleted_or_unreachable(self):
        h = Harness().scan()
        h.ingest(aws())
        h.bridge.source_succeeded(AWS, [h.stored("ABC123")["agent_id"]])
        h.bridge.finish()
        h.scan()
        h.bridge.source_failed(AWS, "SOURCE_TIMEOUT")
        h.bridge.source_failed(AZ, "INVALID_CREDENTIALS")
        term = h.bridge.finish("SCAN_TIMEOUT")
        self.assertEqual(term["event_type"], de.DISCOVERY_SCAN_FAILED)
        self.assertEqual(h.stored("ABC123")["lifecycle_state"], "ACTIVE")     # absence from a failed scan changes nothing
        self.assertNotIn(de.AGENT_LIFECYCLE_CHANGED, types(h.events.events))
        self.assertTrue(ev.validate_batch(h.events.events, ordered=True)["passed"])

    def test_unflushed_changes_never_follow_or_hide_behind_the_terminal_event(self):
        h = Harness().scan()
        h.ingest(aws())
        h.bridge.source_succeeded(AWS, [h.stored("ABC123")["agent_id"]])
        h.ingest(aws(agentName="late change"))              # committed AFTER the source was recorded
        self.assertEqual(h.bridge.pending_changes, 1)
        h.bridge.finish()                                    # flushes first, terminal event still last
        self.assertEqual(types(h.events.events)[-1], de.DISCOVERY_SCAN_COMPLETED)
        self.assertEqual(types(h.events.events).count(de.AGENT_METADATA_UPDATED), 1)


class CommitBoundaryTests(unittest.TestCase):
    def test_rejected_or_quarantined_records_emit_nothing(self):
        h = Harness().scan()
        h.ingest(FX["aws_no_id"])
        h.ingest(FX["aws_bad_status"])
        h.ingest(aws(), source="unknown")
        self.assertEqual(h.bridge.pending_changes, 0)
        self.assertEqual(len(h.inv.review_log), 3)

    def test_no_event_when_the_commit_fails(self):
        h = Harness().scan()
        h.ingest(aws())
        original = ingest.Inventory._commit_lifecycle
        def boom(self, *a, **k):
            raise IOError("disk full")
        ingest.Inventory._commit_lifecycle = boom
        try:
            with self.assertRaises(IOError):
                h.ingest(aws(agentName="changed"))            # existing agent: commit step fails
        finally:
            ingest.Inventory._commit_lifecycle = original
        self.assertEqual(h.stored("ABC123")["metadata_version"], 1)       # version not bumped
        self.assertEqual(h.bridge.pending_changes, 1)                     # only the DISCOVERED change exists
        # NOTE (for Soham): his _upsert assigns name/creation_date BEFORE the commit hook, so a failing
        # commit can leave the new name stored without a version bump. Not changed here; see INTEGRATION_NOTES.

    def test_unaligned_plain_uuid_agent_id_blocks_the_event_but_not_the_commit(self):
        """Supplied ingest.py mints a bare UUID (Soumojit's agt_ alignment pending). The producer must not
        fix it up or mint its own: the event is refused, the committed record stays, nothing is published."""
        use_agt_shim(False)
        try:
            h = Harness().scan()
            res = h.ingest(aws())
            plain = res.record["agent_id"]
            self.assertFalse(plain.startswith("agt_"))
            with self.assertRaises(de.EventValidationError):
                h.bridge.source_succeeded(AWS, [plain])
            self.assertEqual(h.bridge.pending_changes, 1)          # kept, never silently dropped
            self.assertEqual(h.events.events, [])
            self.assertIsNotNone(h.stored("ABC123"))
        finally:
            use_agt_shim(True)

    def test_no_secrets_in_events(self):
        h = Harness().scan()
        raw = aws(agentName="Bot", apiKey="AKIAIOSFODNN7EXAMPLE", password="hunter2")
        res = h.ingest(raw)
        h.bridge.source_succeeded(AWS, [aid(res)])
        h.bridge.finish()
        text = json.dumps(h.events.events)
        self.assertNotIn("AKIAIOSFODNN7EXAMPLE", text)
        self.assertNotIn("hunter2", text)
        self.assertNotIn("AKIAIOSFODNN7EXAMPLE", json.dumps(h.stored("ABC123")))   # not stored either


class StoredRecordShapeTests(unittest.TestCase):
    """Pins the documented differences between the inventory's STORED record and the A1->A2 API
    sample record (docs/A1_FINAL_TASK_REPORT.md, sample-data reconciliation). Not an API test."""

    API_ONLY = {"purpose", "connected_tools", "access_scope", "metadata", "autonomy_level", "risk_score",
                "metadata_confidence", "created_at", "updated_at", "freshness_status"}

    def api_sample(self):
        path = os.path.join(HERE, "fixtures", "A1_A2_Dashboard_Sample_Data", "agents_list_page1.json")
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)["items"][0]

    def stored_record(self):
        h = Harness().scan()
        h.ingest(aws())
        return h.stored("ABC123")

    def test_casing_matches_the_official_samples(self):
        rec, api = self.stored_record(), self.api_sample()
        self.assertEqual(rec["lifecycle_state"], "ACTIVE")
        # DIFFERENCE: Soham's inventory stores the lowercase key; the API sample and events use the approved
        # UPPERCASE value. The mapping (ingest.SOURCE_ALIASES) is applied at the event boundary.
        self.assertEqual(rec["source_references"][0]["source_type"], "aws_bedrock")
        self.assertEqual(ingest.SOURCE_ALIASES[rec["source_references"][0]["source_type"]], "AWS_BEDROCK")
        self.assertEqual(api["source_references"][0]["source_type"], "AWS_BEDROCK")
        self.assertTrue(rec["lifecycle_state"].isupper() and api["lifecycle_state"].isupper())

    def test_stored_record_has_no_fields_the_api_sample_lacks_and_omits_the_api_only_fields(self):
        rec, api = self.stored_record(), self.api_sample()
        self.assertEqual(set(rec) - set(api), set())
        self.assertEqual(set(api) - set(rec), self.API_ONLY - {"metadata"})   # week_2 build now stores metadata       # omitted, NOT null, in the stored record

    def test_source_reference_shape_differs_and_event_fields_are_derived(self):
        rec = self.stored_record()
        self.assertEqual(set(rec["source_references"][0]), {"source_type", "external_id", "observed_at"})
        self.assertEqual(set(self.api_sample()["source_references"][0]),
                         {"source_type", "external_id", "first_observed_at", "last_observed_at", "scan_id"})
        # the event's source_reference is built from first_seen_at / last_seen_at + the scan session's scan_id
        h = Harness().scan("scn_shape_01")
        h.ingest(aws())
        h.bridge.source_succeeded(AWS, [h.stored("ABC123")["agent_id"]])
        ref = h.events.events[0]["payload"]["source_reference"]
        self.assertEqual(set(ref), {"source_type", "external_id", "first_observed_at", "last_observed_at", "scan_id"})
        self.assertEqual(ref["first_observed_at"], h.stored("ABC123")["first_seen_at"])
        self.assertEqual(ref["scan_id"], "scn_shape_01")

    def test_owner_id_is_present_as_null_not_omitted(self):
        rec = self.stored_record()
        self.assertIn("owner_id", rec)
        self.assertIsNone(rec["owner_id"])

    def test_absent_and_null_are_treated_as_the_same_value_for_change_detection(self):
        """CURRENT BEHAVIOUR (open decision): an omitted tracked field and an explicit null compare equal;
        0 is not null (a real risk_score of 0 is a change)."""
        self.assertEqual(de.changed_tracked_fields({"name": "a"}, {"name": "a", "purpose": None}), [])
        self.assertEqual(de.changed_tracked_fields({"name": "a"}, {"name": "a", "risk_score": 0}), ["risk_score"])
        self.assertEqual(de.changed_tracked_fields({"metadata": {}}, {"metadata": {"k": 1}}), ["metadata"])

    def test_creation_date_is_not_created_at(self):
        rec = self.stored_record()
        self.assertIn("creation_date", rec)
        self.assertNotIn("created_at", rec)


class ValidatorRejectsInvalidPayloads(unittest.TestCase):
    def good(self):
        h = Harness().scan()
        res = h.ingest(aws())
        h.bridge.source_succeeded(AWS, [aid(res)])
        h.bridge.finish()
        return [copy.deepcopy(e) for e in h.events.events]

    def fails(self, e):
        return {f["rule"] for f in ev.check_event(e) if f["level"] == "FAIL"}

    def test_integration_output_is_clean(self):
        for e in self.good():
            self.assertEqual(self.fails(e), set())

    def test_invalid_payloads_are_rejected(self):
        disc, term = self.good()
        cases = [
            (lambda e: e.update(agent_id="agt_not-a-uuid"), disc, "ID-AGENT"),
            (lambda e: e.update(agent_id=disc["agent_id"][4:]), disc, "ID-AGENT"),
            (lambda e: e.update(metadata_version=0), disc, "ENV-VERSION"),
            (lambda e: e.update(metadata_version=None), disc, "ENV-VERSION"),
            (lambda e: e["payload"].update(lifecycle_state="active"), disc, "PAY-STATE"),
            (lambda e: e["payload"].update(lifecycle_state=None), disc, "PAY-STATE"),
            (lambda e: e["payload"].pop("source_reference"), disc, "PAY-KEYS"),
            (lambda e: e.update(occurred_at="2026-11-24"), disc, "TIME-OCCURRED_AT"),
            (lambda e: e["payload"].update(scan_status="FAILED"), term, "PAY-SCAN-STATUS"),
            (lambda e: e.update(agent_id=disc["agent_id"]), term, "ENV-SCAN-NULLS"),
            (lambda e: e["payload"].update(agents_observed=-1), term, "PAY-COUNT"),
            (lambda e: e.update(event_type="AGENT_DELETED"), disc, "ENV-EVENT-TYPE"),
        ]
        for mutate, base, rule in cases:
            e = copy.deepcopy(base)
            mutate(e)
            self.assertIn(rule, self.fails(e), rule)


class _Seeded(unittest.TestCase):
    """An ACTIVE agent observed at 10:00 whose DISCOVERED event is already published."""

    def setUp(self):
        self.h = Harness().scan(at="2026-11-24T10:00:00.000Z")
        self.aid = aid(self.h.ingest(aws()))
        self.h.bridge.source_succeeded(AWS, [self.aid])
        self.h.bridge.finish()
        self.base = len(self.h.events.events)
        self.rec = self.h.stored("ABC123")

    def snapshot(self):
        r = self.rec
        return (r["lifecycle_state"], r["metadata_version"], r["last_seen_at"], r["name"], r["agent_id"])


class StaleObservationTests(_Seeded):
    """Fix 1: an observation older than last_seen_at is audit-only whatever its status."""

    def _stale(self, raw):
        self.h.scan(at="2026-11-24T09:00:00.000Z")
        before = self.snapshot()
        res = self.h.ingest(raw)
        self.assertEqual(res.outcome, ingest.ACCEPTED_WITH_WARNINGS)
        self.assertIs(res.record, self.rec)                      # record preserved, not replaced
        self.assertEqual(self.snapshot(), before)                # no state / version / last_seen / name change
        self.assertEqual(self.h.bridge.pending_changes, 0)       # nothing for the producer to emit
        self.h.bridge.source_succeeded(AWS, [self.aid])
        self.assertEqual(types(self.h.new_events(self.base)), [])   # and no lifecycle or metadata event
        last = self.h.inv.review_log[-1]
        self.assertEqual(last["outcome"], ingest.REVIEW)
        self.assertIn("older observation", last["reasons"][0])

    def test_stale_with_valid_status(self):
        self._stale(aws(agentStatus="DELETED", agentName="Stale Name"))

    def test_stale_with_unknown_status_does_not_quarantine(self):
        self._stale(aws(agentStatus="banana"))
        self.assertEqual(self.rec["lifecycle_state"], "ACTIVE")

    def test_stale_with_missing_status(self):
        self._stale({k: v for k, v in aws().items() if k != "agentStatus"})


class MissingStatusTests(_Seeded):
    """Fix 2: a missing status on an existing agent is no new evidence."""

    NO_STATUS = {k: v for k, v in aws().items() if k != "agentStatus"}

    def test_existing_active_stays_active_without_version_or_event(self):
        self.h.scan(at="2026-11-24T12:00:00.000Z")
        res = self.h.ingest(self.NO_STATUS)
        self.assertEqual(res.outcome, ingest.ACCEPTED_WITH_WARNINGS)
        self.assertTrue(any("status missing" in r for r in res.reasons))
        self.assertEqual((self.rec["lifecycle_state"], self.rec["metadata_version"]), ("ACTIVE", 1))
        self.assertEqual(self.h.bridge.pending_changes, 0)
        self.h.bridge.source_succeeded(AWS, [self.aid])
        self.assertEqual(types(self.h.new_events(self.base)), [])

    def test_existing_dormant_stays_dormant(self):
        self.h.scan(at="2026-11-24T12:00:00.000Z")
        self.h.inv.mark_unverified(T, AWS_IN, "ABC123", scan_status="SUCCEEDED", verification_failed=True,
                                   now=datetime(2026, 12, 10, tzinfo=timezone.utc))
        self.assertEqual(self.rec["lifecycle_state"], "DORMANT")
        version = self.rec["metadata_version"]
        self.h.bridge.source_succeeded(AWS, [])                  # publishes the DORMANT event
        n = len(self.h.events.events)
        self.h.ingest(self.NO_STATUS, at="2026-12-11T00:00:00.000Z")
        self.assertEqual((self.rec["lifecycle_state"], self.rec["metadata_version"]), ("DORMANT", version))
        self.assertEqual(self.h.bridge.pending_changes, 0)
        self.assertEqual(len(self.h.events.events), n)

    def test_new_agent_without_status_goes_to_review_and_is_not_inserted(self):
        h = Harness().scan()
        res = h.ingest(self.NO_STATUS)
        self.assertEqual(res.outcome, ingest.REVIEW)
        self.assertIsNone(res.record)
        self.assertIsNone(h.stored("ABC123"))
        self.assertEqual(h.bridge.pending_changes, 0)            # no AGENT_DISCOVERED for it

    def test_existing_agent_with_unrecognised_status_is_quarantined_with_one_event(self):
        self.h.scan(at="2026-11-24T12:00:00.000Z")
        res = self.h.ingest(aws(agentStatus="banana"))
        self.assertEqual(res.outcome, ingest.QUARANTINED)
        self.assertEqual((self.rec["lifecycle_state"], self.rec["metadata_version"]), ("QUARANTINED", 2))
        self.h.bridge.source_succeeded(AWS, [self.aid])
        e, = self.h.new_events(self.base)
        self.assertEqual(e["event_type"], de.AGENT_LIFECYCLE_CHANGED)
        self.assertEqual((e["payload"]["previous_state"], e["payload"]["new_state"],
                          e["change_summary"]["reason_code"]), ("ACTIVE", "QUARANTINED", "INTEGRITY_CONCERN"))
        # quarantine is sticky: a later healthy observation neither releases it nor emits anything
        n = len(self.h.events.events)
        self.h.ingest(aws(), at="2026-11-24T13:00:00.000Z")
        self.assertEqual(self.rec["lifecycle_state"], "QUARANTINED")
        self.assertEqual(self.h.bridge.pending_changes, 0)
        self.assertEqual(len(self.h.events.events), n)


class ResurrectionTests(_Seeded):
    """DELETED -> ACTIVE. Per the build handoff the REVIEW decision belongs to the caller (review layer), NOT to
    ingest(): it must spot the resurrection BEFORE ingesting, call quarantine_existing(), log REVIEW and not ingest
    the ACTIVE observation (same pattern as the build's tests/test_pavani_part2.py). The producer only reports."""

    def _delete(self):
        self.h.scan(at="2026-11-24T11:00:00.000Z")
        self.h.ingest(aws(agentStatus="DELETED"))
        self.h.bridge.source_succeeded(AWS, [self.aid])
        self.h.bridge.finish()
        self.n_deleted = len(self.h.events.events)

    def _review_layer(self, raw, at):
        """Caller-side logic (reference pattern from the build), then the real calls."""
        if self.rec["lifecycle_state"] == "DELETED" and raw["agentStatus"] == "ACTIVE":
            self.h.inv.quarantine_existing(T, AWS_IN, "ABC123")
            self.h.inv.review_log.append({"outcome": ingest.REVIEW, "tenant_id": T, "source_type": AWS_IN,
                                          "external_id": "ABC123",
                                          "reasons": ["DELETED to ACTIVE resurrection requires human review"]})
            return None                                          # the ACTIVE observation is NOT ingested
        return self.h.ingest(raw, at=at)

    def _resurrect(self):
        self._delete()
        self.h.scan(at="2026-11-24T12:00:00.000Z")
        return self._review_layer(aws(agentStatus="ACTIVE"), "2026-11-24T12:00:00.000Z")

    def test_resurrection_is_held_in_quarantine_not_active(self):
        self.assertIsNone(self._resurrect())
        self.assertEqual(self.rec["lifecycle_state"], "QUARANTINED")
        self.assertEqual(self.rec["agent_id"], self.aid)                  # canonical id preserved
        self.assertEqual(self.rec["metadata_version"], 3)                 # 1 new, 2 DELETED, 3 QUARANTINED
        self.assertEqual(self.h.inv.review_log[-1]["outcome"], ingest.REVIEW)
        self.assertEqual(len(self.h.inv.list_for_tenant(T)), 1)           # no second record
        self.assertEqual(self.h.observer.review_warnings, [])             # nothing slipped through

    def test_resurrection_emits_exactly_one_lifecycle_event_and_never_deleted_to_active(self):
        self._resurrect()
        self.h.bridge.source_succeeded(AWS, [self.aid])
        self.h.bridge.finish()
        evs = self.h.events.events[self.n_deleted:]
        lifecycle_evs = [e for e in evs if e["event_type"] == de.AGENT_LIFECYCLE_CHANGED]
        self.assertEqual(len(lifecycle_evs), 1)
        e = lifecycle_evs[0]
        self.assertEqual((e["payload"]["previous_state"], e["payload"]["new_state"],
                          e["change_summary"]["reason_code"], e["metadata_version"],
                          e["payload"]["previous_metadata_version"], e["agent_id"]),
                         ("DELETED", "QUARANTINED", "INTEGRITY_CONCERN", 3, 2, self.aid))
        for ev_ in self.h.events.events:
            self.assertFalse(ev_["event_type"] == de.AGENT_LIFECYCLE_CHANGED and
                             ev_["payload"]["previous_state"] == "DELETED" and ev_["payload"]["new_state"] == "ACTIVE")
        self.assertTrue(ev.validate_batch(self.h.events.events, ordered=True)["passed"])

    def test_quarantine_remains_until_explicit_review(self):
        self._resurrect()
        self.h.bridge.source_succeeded(AWS, [self.aid])
        self.h.bridge.finish()
        n = len(self.h.events.events)
        for day in ("2026-11-25", "2026-11-26"):                         # repeated healthy observations
            self.h.scan(at=day + "T12:00:00.000Z")
            self._review_layer(aws(agentStatus="ACTIVE"), day + "T12:00:00.000Z")   # now QUARANTINED -> plain ingest
        self.assertEqual(self.rec["lifecycle_state"], "QUARANTINED")
        self.assertEqual(self.rec["metadata_version"], 3)
        self.assertEqual(self.h.bridge.pending_changes, 0)
        self.assertEqual(len(self.h.events.events), n)

    def test_unintercepted_resurrection_is_reported_not_hidden(self):
        """If the review layer is missing, the supplied ingest() silently re-activates. The producer cannot
        prevent that: it emits the truthful event AND records a warning (BLOCKER: review layer not built)."""
        self._delete()
        self.h.scan(at="2026-11-24T12:00:00.000Z")
        self.h.ingest(aws(agentStatus="ACTIVE"))                          # no interception
        self.assertEqual(self.rec["lifecycle_state"], "ACTIVE")
        self.assertEqual(len(self.h.observer.review_warnings), 1)
        self.assertIn("without a review hold", self.h.observer.review_warnings[0])

    def test_quarantine_existing_hook_is_one_bump_and_idempotent(self):
        self.h.scan(at="2026-11-24T12:00:00.000Z")
        self.assertIs(self.h.inv.quarantine_existing(T, AWS_IN, "ABC123"), self.rec)
        self.assertIs(self.h.inv.quarantine_existing(T, AWS_IN, "ABC123"), self.rec)
        self.assertIsNone(self.h.inv.quarantine_existing("other", AWS_IN, "ABC123"))   # never creates
        self.assertEqual(self.rec["metadata_version"], 2)
        self.h.bridge.source_succeeded(AWS, [self.aid])
        e, = self.h.new_events(self.base)
        self.assertEqual(e["change_summary"]["reason_code"], "INTEGRITY_CONCERN")

    def test_duplicate_review_pattern_creates_no_record_and_one_quarantine_event(self):
        """Pavani's duplicate pattern (build test_pavani_part2): the new duplicate is NOT ingested, the existing
        agent is quarantined -> exactly one lifecycle event, no AGENT_DISCOVERED for the duplicate."""
        self.h.scan(at="2026-11-24T12:00:00.000Z")
        self.h.inv.quarantine_existing(T, AWS_IN, "ABC123")
        self.h.inv.review_log.append({"outcome": ingest.REVIEW, "reasons": ["same name and creation date, different ID"],
                                     "tenant_id": T, "source_type": AWS_IN, "external_id": "OTHER"})
        self.h.bridge.source_succeeded(AWS, [self.aid])
        self.assertEqual(types(self.h.new_events(self.base)), [de.AGENT_LIFECYCLE_CHANGED])
        self.assertEqual(len(self.h.inv.list_for_tenant(T)), 1)


class ScanIdAndDuplicateTests(_Seeded):
    def test_scan_id_is_propagated_to_every_event_of_the_scan(self):
        h = Harness().scan("scn_prop_01")
        a = aid(h.ingest(aws()))
        h.ingest(aws(agentName="Renamed"))                        # same scan, second change
        h.bridge.source_succeeded(AWS, [a])
        h.bridge.finish()
        self.assertEqual({e["scan_id"] for e in h.events.events}, {"scn_prop_01"})
        self.assertEqual(h.events.events[0]["payload"]["source_reference"]["scan_id"], "scn_prop_01")

    def test_same_observation_in_a_later_scan_produces_no_event(self):
        self.h.scan(at="2026-11-24T12:00:00.000Z")
        for _ in range(3):
            self.h.ingest(aws())
        self.h.bridge.source_succeeded(AWS, [self.aid])
        self.h.bridge.finish()
        self.assertEqual(types(self.h.new_events(self.base)), [de.DISCOVERY_SCAN_COMPLETED])
        self.assertEqual(self.rec["metadata_version"], 1)

    def test_one_agent_one_discovered_even_if_observed_twice_in_one_scan(self):
        h = Harness().scan()
        h.ingest(aws()); h.ingest(aws())
        h.bridge.source_succeeded(AWS, [])
        self.assertEqual(types(h.events.events).count(de.AGENT_DISCOVERED), 1)
        self.assertEqual(len(h.inv.list_for_tenant(T)), 1)

    def test_one_event_per_agent_version_is_enforced(self):
        h = Harness().scan()
        a = aid(h.ingest(aws()))
        h.bridge.flush()
        with self.assertRaises(ValueError):                       # a second event for (agent, v1)
            h.session.queue_metadata_updated(agent_id=a, metadata_version=1, previous_metadata_version=0,
                                             changed_fields=["name"])

    def test_every_hook_is_one_bump_one_event(self):
        """new -> v1 DISCOVERED; rename -> v2 METADATA; rename+DELETED -> v3 LIFECYCLE (single bump)."""
        h = Harness().scan(at="2026-11-24T10:00:00.000Z")
        a = aid(h.ingest(aws()))
        h.ingest(aws(agentName="B"), at="2026-11-24T11:00:00.000Z")
        h.ingest(aws(agentName="C", agentStatus="DELETED"), at="2026-11-24T12:00:00.000Z")
        h.bridge.source_succeeded(AWS, [a])
        got = [(e["event_type"], e["metadata_version"]) for e in h.events.events]
        self.assertEqual(got, [(de.AGENT_DISCOVERED, 1), (de.AGENT_METADATA_UPDATED, 2),
                               (de.AGENT_LIFECYCLE_CHANGED, 3)])
        self.assertEqual(h.stored("ABC123")["metadata_version"], 3)

    def test_stored_source_keys_mirror_the_inventorys_own_aliases(self):
        self.assertEqual(de.STORED_SOURCE_KEYS, ingest.SOURCE_ALIASES)


if __name__ == "__main__":
    unittest.main(verbosity=2)

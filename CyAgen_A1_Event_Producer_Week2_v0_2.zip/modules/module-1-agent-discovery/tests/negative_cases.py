"""
negative_cases.py - deliberately BROKEN events used to prove the validator works.

Every case starts from a real supplied fixture and breaks exactly one thing.
These are test inputs, not company data, and are never written to the delivered
example files. Used by test_event_validator.py and scripts/generate_deliverables.py.

Each case: {name, mode, build(fx) -> data, expect: (category, rule)}
  mode "event"  : build returns one event       -> check_event
  mode "batch"  : build returns a list of events -> check_scan_groups / integrity
  mode "retry"  : build returns delivered copies -> check_retries
fx is a dict of loaded fixtures keyed by file stem (without .json).
"""
import copy


def _c(fx, name):
    e = copy.deepcopy(fx[name])
    e.pop("_note", None)
    return e


def _set(path_keys, value):
    def apply(e):
        d = e
        for k in path_keys[:-1]:
            d = d[k]
        d[path_keys[-1]] = value
        return e
    return apply


def cases():
    def ev(name, base, mutate, expect):
        return {"name": name, "mode": "event", "expect": expect,
                "build": lambda fx, b=base, m=mutate: m(_c(fx, b))}

    def drop(key):
        def m(e):
            del e[key]
            return e
        return m

    def add_payload(k, v):
        def m(e):
            e["payload"][k] = v
            return e
        return m

    out = [
        # ---- ids ----
        ev("source_system_ref is not a UUID", "agent_discovered", _set(["source_system_ref"], "not-a-uuid"), ("ID", "ID-UUID4-SOURCE_SYSTEM_REF")),
        # ---- latest B2 feedback ----
        ev("event_id populated by Module 1 (random UUID)", "agent_discovered", _set(["event_id"], "11111111-1111-4111-8111-111111111111"), ("ID", "ID-EVENT-ID-NOT-NULL")),
        ev("event_id copied from source_system_ref (old behaviour)", "agent_discovered", lambda e: e.update(event_id=e["source_system_ref"]) or e, ("ID", "ID-EVENT-ID-NOT-NULL")),
        ev("old name error_code inside sources[]", "discovery_scan_partial",
           lambda e: (e["payload"]["sources"][1].update(error_code=e["payload"]["sources"][1].pop("source_error_code")), e)[1], ("PAYLOAD", "B2-SOURCE-ERROR-CODE")),
        ev("old name error_code at scan level", "discovery_scan_failed",
           lambda e: (e["payload"].update(error_code=e["payload"].pop("scan_error_code")), e)[1], ("PAYLOAD", "B2-SCAN-ERROR-CODE")),
        ev("scan-level scan_error_code missing on FAILED scan", "discovery_scan_failed",
           lambda e: (e["payload"].pop("scan_error_code"), e)[1], ("PAYLOAD", "PAY-KEYS")),
        ev("correlation_id is null", "agent_discovered", _set(["correlation_id"], None), ("ID", "ID-UUID4-CORRELATION_ID")),
        ev("correlation_id reuses the scan_id text", "agent_discovered", _set(["correlation_id"], "scn_20261121_1200_01"), ("ID", "ID-UUID4-CORRELATION_ID")),
        ev("source_system_ref is a version-1 UUID (not v4)", "agent_discovered",
           _set(["source_system_ref"], "3c3ae353-fb14-128e-90b4-01a6c1cc0aff"), ("ID", "ID-UUID4-SOURCE_SYSTEM_REF")),
        ev("correlation_id has an invalid variant digit", "agent_discovered",
           _set(["correlation_id"], "6f5e4d3c-2b1a-4c9d-ce7f-6a5b4c3d2e1f"), ("ID", "ID-UUID4-CORRELATION_ID")),
        ev("agent_id is a version-1 UUID behind agt_", "agent_discovered",
           _set(["agent_id"], "agt_0b80a255-53a1-1945-a932-58ef7777682c"), ("ID", "ID-AGENT")),
        ev("correlation_id in uppercase", "agent_discovered", lambda e: e.update(correlation_id=e["correlation_id"].upper()) or e, ("ID", "ID-UUID4-CORRELATION_ID")),
        ev("agent_id is a plain UUID (no agt_ prefix)", "agent_discovered", lambda e: e.update(agent_id=e["agent_id"][4:]) or e, ("ID", "ID-AGENT")),
        # ---- time ----
        ev("occurred_at has no milliseconds", "agent_discovered", _set(["occurred_at"], "2026-11-21T12:00:02Z"), ("TIME", "TIME-OCCURRED_AT")),
        ev("published_at uses +05:30 offset, not Z", "agent_discovered", _set(["published_at"], "2026-11-21T17:30:02.150+05:30"), ("TIME", "TIME-PUBLISHED_AT")),
        ev("published_at earlier than occurred_at", "agent_discovered", _set(["published_at"], "2026-11-21T11:59:59.000Z"), ("TIME", "TIME-PUB-BEFORE-OCC")),
        ev("impossible calendar date", "agent_discovered", _set(["occurred_at"], "2026-13-45T12:00:02.000Z"), ("TIME", "TIME-OCCURRED_AT")),
        # ---- envelope ----
        ev("tenant_id missing", "agent_discovered", drop("tenant_id"), ("ENVELOPE", "ENV-MISSING")),
        ev("unknown event_type", "agent_discovered", _set(["event_type"], "AGENT_DELETED"), ("ENVELOPE", "ENV-EVENT-TYPE")),
        ev("scan event carries an agent_id", "discovery_scan_partial", _set(["agent_id"], "agt_0b80a255-53a1-4945-a932-58ef7777682c"), ("ENVELOPE", "ENV-SCAN-NULLS")),
        # ---- payload ----
        ev("lifecycle value in lowercase", "agent_lifecycle_changed", _set(["payload", "new_state"], "quarantined"), ("PAYLOAD", "PAY-STATE")),
        ev("DELETED reached through NOT_VERIFIED_IN_RECENT_SCAN", "agent_lifecycle_changed__unreachable",
           lambda e: (e["payload"].update(new_state="DELETED"), e)[1], ("PAYLOAD", "PAY-DELETED-RULE")),
        ev("metadata_version skips a number", "agent_metadata_updated", _set(["metadata_version"], 9), ("PAYLOAD", "PAY-VERSION-STEP")),
        ev("AGENT_DISCOVERED not at version 1", "agent_discovered", _set(["metadata_version"], 2), ("PAYLOAD", "PAY-DISCOVERED-V1")),
        ev("lifecycle_state listed in a METADATA_UPDATED change", "agent_metadata_updated",
           _set(["change_summary", "changed_fields"], ["lifecycle_state"]), ("PAYLOAD", "PAY-META-FIELDS")),
        ev("scan_status contradicts event type", "discovery_scan_partial", _set(["payload", "scan_status"], "SUCCEEDED"), ("PAYLOAD", "PAY-SCAN-STATUS")),
        ev("failed source has no source_error_code", "discovery_scan_failed",
           lambda e: (e["payload"]["sources"][0].update(source_error_code=None), e)[1], ("PAYLOAD", "PAY-SOURCE-FAILURE")),
        ev("unsupported source_type (lowercase legacy value)", "discovery_scan_partial",
           lambda e: (e["payload"]["sources"][0].update(source_type="aws_bedrock"), e)[1], ("PAYLOAD", "PAY-SOURCE-TYPE")),
        ev("unsupported source_type in source_reference", "agent_discovered",
           _set(["payload", "source_reference", "source_type"], "GCP_VERTEX"), ("PAYLOAD", "PAY-SOURCE-TYPE")),
        ev("PARTIAL scan whose sources all succeeded", "discovery_scan_partial",
           lambda e: (e["payload"]["sources"][1].update(status="SUCCEEDED", failure_category=None, source_error_code=None), e)[1], ("PAYLOAD", "PAY-PARTIAL-MIX")),
        ev("agents_observed larger than all sources together", "discovery_scan_partial", _set(["payload", "agents_observed"], 50), ("PAYLOAD", "PAY-OBSERVED-RANGE")),
        ev("retired_agent_ids contains the survivor", "agent_identity_resolved",
           lambda e: (e["payload"].update(retired_agent_ids=[e["payload"]["surviving_agent_id"]]), e)[1], ("PAYLOAD", "PAY-RETIRED")),
        # ---- secrets ----
        ev("secret-named key in payload", "agent_metadata_updated", add_payload("api_key", "x"), ("SECRET", "SECRET-KEY")),
        ev("AWS access key value in payload", "agent_metadata_updated",
           add_payload("note", "AKIAIOSFODNN7EXAMPLE"), ("SECRET", "SECRET-VALUE")),
        ev("Bearer token value in payload", "agent_metadata_updated",
           add_payload("note", "Bearer abcdefghijklmnop1234"), ("SECRET", "SECRET-VALUE")),
    ]

    def batch(name, build, expect):
        return {"name": name, "mode": "batch", "expect": expect, "build": build}

    def two_terminals(fx):
        a = _c(fx, "discovery_scan_partial")
        b = copy.deepcopy(a)
        b["source_system_ref"] = "22222222-2222-4222-8222-222222222222"
        return [a, b]

    def agent_after_terminal(fx):
        t = _c(fx, "discovery_scan_partial")                 # occurred 09:00:41
        a = _c(fx, "agent_metadata_updated")
        a["occurred_at"], a["published_at"] = "2026-11-23T09:05:00.000Z", "2026-11-23T09:05:00.100Z"
        return [a, t]

    def mixed_correlation(fx):
        t = _c(fx, "discovery_scan_partial")
        a = _c(fx, "agent_metadata_updated")
        a["correlation_id"] = "33333333-3333-4333-8333-333333333333"
        return [a, t]

    def delete_in_failed_scan(fx):
        t = _c(fx, "discovery_scan_failed")                  # scn_20261122_1500_01
        a = _c(fx, "agent_lifecycle_changed")
        a["scan_id"], a["correlation_id"] = t["scan_id"], t["correlation_id"]
        a["occurred_at"], a["published_at"] = "2026-11-22T15:02:00.000Z", "2026-11-22T15:02:00.100Z"
        a["change_summary"]["reason_code"] = "SOURCE_REPORTED_DELETED"
        a["payload"]["new_state"] = "DELETED"
        return [a, t]

    def unreachable_in_failed_scan(fx):
        t = _c(fx, "discovery_scan_failed")
        a = _c(fx, "agent_lifecycle_changed__unreachable")
        a["scan_id"], a["correlation_id"] = t["scan_id"], t["correlation_id"]
        a["occurred_at"], a["published_at"] = "2026-11-22T15:02:00.000Z", "2026-11-22T15:02:00.100Z"
        return [a, t]

    def duplicate_ref(fx):
        a = _c(fx, "agent_metadata_updated")
        b = _c(fx, "agent_lifecycle_changed")
        b["source_system_ref"] = a["source_system_ref"]
        return [a, b]

    def two_events_one_version(fx):
        a = _c(fx, "agent_metadata_updated")
        b = copy.deepcopy(a)
        b["source_system_ref"] = "44444444-4444-4444-8444-444444444444"
        return [a, b]

    def terminal_not_last_in_order(fx):
        a = _c(fx, "agent_metadata_updated")
        t = _c(fx, "discovery_scan_partial")
        return [t, a]

    out += [
        batch("two terminal events for one scan", two_terminals, ("GROUP", "GROUP-ONE-TERMINAL")),
        batch("agent event occurs after the terminal event", agent_after_terminal, ("GROUP", "GROUP-TERMINAL-LAST")),
        batch("events of one scan with different correlation_id", mixed_correlation, ("GROUP", "GROUP-CORRELATION")),
        batch("DELETED inside a FAILED scan", delete_in_failed_scan, ("GROUP", "GROUP-FAILED-SCAN-NO-DELETE")),
        batch("UNREACHABLE inside a FAILED scan", unreachable_in_failed_scan, ("GROUP", "GROUP-FAILED-SCAN-NO-DELETE")),
        batch("same source_system_ref on two different events", duplicate_ref, ("GROUP", "GROUP-DUPLICATE-REF")),
        batch("two events for the same agent version", two_events_one_version, ("GROUP", "GROUP-ONE-EVENT-PER-VERSION")),
    ]
    out.append({"name": "terminal event published before agent event (publish order)", "mode": "batch_ordered",
                "expect": ("GROUP", "GROUP-TERMINAL-LAST"), "build": terminal_not_last_in_order})

    def retry_changed_payload(fx):
        a = _c(fx, "agent_metadata_updated")
        b = copy.deepcopy(a)
        b["published_at"] = "2026-11-23T09:00:04.000Z"
        b["payload"]["previous_metadata_version"] = 1
        return [a, b]

    def retry_changed_occurred(fx):
        a = _c(fx, "agent_metadata_updated")
        b = copy.deepcopy(a)
        b["published_at"] = "2026-11-23T09:00:04.000Z"
        b["occurred_at"] = "2026-11-23T09:00:03.500Z"
        return [a, b]

    out += [
        {"name": "retry changed the payload", "mode": "retry", "expect": ("RETRY", "RETRY-IDENTICAL"), "build": retry_changed_payload},
        {"name": "retry changed occurred_at", "mode": "retry", "expect": ("RETRY", "RETRY-IDENTICAL"), "build": retry_changed_occurred},
    ]
    return out


def evaluate(case, fx, validator):
    """Run one case through the validator module. Returns (caught, findings)."""
    data = case["build"](fx)
    mode = case["mode"]
    if mode == "event":
        findings = validator.check_event(data)
    elif mode in ("batch", "batch_ordered"):
        findings = []
        for fs in validator.check_scan_groups(data, ordered=(mode == "batch_ordered")).values():
            findings += fs
        findings += validator.check_batch_integrity(data)
    else:
        findings = validator.check_retries(data)
    cat, rule = case["expect"]
    caught = any(f["level"] == "FAIL" and f["category"] == cat and f["rule"] == rule for f in findings)
    return caught, findings

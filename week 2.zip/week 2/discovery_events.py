"""CyAgen A1 discovery event producer scaffold.

This module intentionally does not define an assumed B2 event schema.
Bind the payload builder to the approved B2 contract before submission.
"""
from dataclasses import dataclass
from typing import Any, Mapping, Optional


@dataclass(frozen=True)
class InventoryChange:
    """Snapshot-derived committed inventory change."""
    change_type: str
    record: Mapping[str, Any]
    previous_record: Optional[Mapping[str, Any]] = None
    scan_id: Optional[str] = None


class DiscoveryEventProducer:
    """Build events from committed inventory changes.

    The approved B2 schema and delivery/outbox contract must be supplied
    before this class can emit contract-compliant production events.
    """

    def __init__(self, event_validator=None):
        self.event_validator = event_validator

    def build_event(self, change: InventoryChange) -> dict:
        """Return an event only after the approved contract is configured."""
        raise NotImplementedError(
            "Configure the approved B2 event schema and map the actual "
            "inventory record fields before building events."
        )

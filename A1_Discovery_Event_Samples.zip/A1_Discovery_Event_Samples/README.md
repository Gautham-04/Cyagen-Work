# A1 Discovery Event Samples (Fixtures)

**FIXTURE EVENTS – written to the A1 Discovery Event Contract v0.1. Not yet produced by the prototype.**
These are the target payloads for implementation (Gautham) and for B2's producer mapping.

| File | Event |
|---|---|
| agent_discovered.json | New agent created in the registry |
| agent_metadata_updated.json | Tracked metadata changed |
| agent_lifecycle_changed.json | ACTIVE → QUARANTINED |
| agent_lifecycle_changed__unreachable.json | ACTIVE → UNREACHABLE |
| agent_identity_resolved.json | Two records merged; retired ID listed |
| discovery_scan_completed.json | All sources succeeded |
| discovery_scan_completed__zero_results.json | Succeeded with 0 agents (not a failure) |
| discovery_scan_partial.json | One source failed (AUTH_ERROR), one succeeded |
| discovery_scan_failed.json | Scan timed out; no source succeeded |

All events share one envelope. `correlation_id` is always a UUID; `scan_id` is a separate field.

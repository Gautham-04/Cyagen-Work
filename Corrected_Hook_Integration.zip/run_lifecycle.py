"""Manual demonstration of lifecycle integration hooks.

This is not an ingest pipeline, duplicate detector, or scheduler. Run explicitly:
    python run_lifecycle.py
"""
from datetime import datetime, timezone
from ingest import Inventory, REVIEW

inventory = Inventory(dormancy_days=14)
inventory.ingest(
    {"agentId": "ABC123", "agentName": "Sales Bot", "agentStatus": "ACTIVE"},
    "tenant-1", "aws_bedrock",
)

# Example review-layer decision: the application has identified this stored
# agent as suspicious. The hook is called outside ingest.py.
inventory.quarantine_existing("tenant-1", "aws_bedrock", "ABC123")

# Example scan-coordinator decision: trusted scan failed to verify the agent.
inventory.mark_unverified(
    "tenant-1", "aws_bedrock", "ABC123",
    scan_status="FAILED",
    now=datetime.now(timezone.utc),
    verification_failed=True,
)

print("Manual lifecycle hook demonstration:")
print(inventory.get("tenant-1", "aws_bedrock", "ABC123"))

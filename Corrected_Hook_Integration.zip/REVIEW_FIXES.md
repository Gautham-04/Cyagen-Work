# Lifecycle integration — review fixes (26 November 2026)

## Changes
1. Stale/replayed observations are ignored **before** suspicious status handling, including unknown statuses. An entry is appended to `Inventory.review_log` with outcome `REVIEW`; the ingest call returns `ACCEPTED_WITH_WARNINGS` and the unchanged stored agent.
2. Existing agents with missing (`None`/absent) status retain lifecycle state and metadata_version and receive a warning. The observation timestamp may advance. New agents with missing status continue to `REVIEW`.
3. Added three focused regression tests; all **63 tests pass** using `python -m pytest -v`.

## Ownership and remaining work
Pavani owns `DELETED -> ACTIVE` resurrection review rules and quarantine-release policy is still undefined. No GitHub PR was created from this local package; apply to the current team branch, run the suite there, then submit the PR.


## Hook placement correction

Application-level duplicate detection and resurrection REVIEW decisions do not
belong inside `Inventory.ingest()` or reusable `ingest.py` lifecycle methods.
The caller must detect the condition before inserting/updating the record,
append the REVIEW event, and call `quarantine_existing()` for the existing
inventory record. The caller must not ingest a suspicious new duplicate.
Resurrection (`DELETED` -> `ACTIVE`) must be intercepted before ingesting the
incoming ACTIVE observation, then reviewed and quarantined through the hook.

No duplicate-detection module or scheduler currently exists in this prototype.
Use `tests/test_lifecycle_integration.py` as the reference; `run_lifecycle.py`
is a manually invoked illustration only.

import json
from datetime import datetime, timezone
from pathlib import Path
from ingest import Inventory, REVIEW, ACCEPTED, ACCEPTED_WITH_WARNINGS

ROOT = Path(__file__).resolve().parents[1]
def fixture(key):
    return json.loads((ROOT / "fixtures.json").read_text())[key]

def test_quarantine_hook_is_called_by_review_integration_not_ingest():
    inv = Inventory()
    raw = fixture("aws_valid")
    inv.ingest(raw, "tenant-p", "aws_bedrock", "2026-11-26T10:00:00Z")
    existing = inv.get("tenant-p", "aws_bedrock", "ABC123")
    # Simulate the review/duplicate module deciding that this existing
    # inventory record is suspicious. The application layer invokes the hook.
    quarantined = inv.quarantine_existing("tenant-p", "aws_bedrock", "ABC123")
    assert quarantined is existing
    assert existing["lifecycle_state"] == "QUARANTINED"
    assert existing["metadata_version"] == 2

def test_resurrection_review_integration_calls_quarantine_hook():
    inv = Inventory()
    raw = fixture("aws_valid")
    inv.ingest(raw, "tenant-p", "aws_bedrock", "2026-11-26T10:00:00Z")
    deleted = dict(raw, agentStatus="DELETED")
    inv.ingest(deleted, "tenant-p", "aws_bedrock", "2026-11-26T10:01:00Z")
    prior = inv.get("tenant-p", "aws_bedrock", "ABC123")
    assert prior["lifecycle_state"] == "DELETED"

    # REVIEW/application logic must identify DELETED -> ACTIVE before ingesting
    # the incoming ACTIVE observation; then call the reusable lifecycle hook.
    incoming = dict(raw, agentStatus="ACTIVE")
    if prior["lifecycle_state"] == "DELETED" and incoming["agentStatus"] == "ACTIVE":
        inv.quarantine_existing("tenant-p", "aws_bedrock", "ABC123")
        inv.review_log.append({"outcome": REVIEW,
                               "reasons": ["DELETED to ACTIVE resurrection requires human review"],
                               "tenant_id": "tenant-p", "source_type": "aws_bedrock",
                               "external_id": "ABC123"})
        # Do not pass the resurrection observation to ingest in this branch.
    assert prior["lifecycle_state"] == "QUARANTINED"
    assert inv.review_log[-1]["outcome"] == REVIEW

def test_metadata_secrets_removed_and_paths_only():
    raw = fixture("aws_metadata_secrets")
    result = __import__("ingest").validate_and_normalize(
        raw, "tenant-p", "aws_bedrock", "2026-11-26T10:00:00Z")
    assert result.record["metadata"] == {"region":"ap-south-1","nested":{"purpose":"fixture"}}
    assert "secret removed: metadata.apiKey" in result.reasons
    assert "secret removed: metadata.nested.access_token" in result.reasons
    assert "FAKE_KEY" not in repr(result.reasons)
    assert "FAKE_TOKEN" not in repr(result.reasons)


def test_review_layer_stops_new_duplicate_before_inventory_ingest():
    inv = Inventory()
    original = fixture("aws_valid")
    inv.ingest(original, "tenant-p", "aws_bedrock", "2026-11-26T10:00:00Z")
    incoming = fixture("aws_same_name_other_id")
    normalized = __import__("ingest").validate_and_normalize(
        incoming, "tenant-p", "aws_bedrock", "2026-11-26T10:01:00Z").record

    # This is caller-side review logic, not an Inventory/ingest.py feature.
    duplicate_found = any(
        agent.get("tenant_id") == "tenant-p"
        and agent.get("name") == normalized.get("name")
        and agent.get("creation_date") == normalized.get("creation_date")
        and agent.get("source_references", [{}])[0].get("external_id") != normalized["source_references"][0]["external_id"]
        for agent in inv.list_for_tenant("tenant-p")
    )
    if duplicate_found:
        inv.quarantine_existing("tenant-p", "aws_bedrock", "ABC123")
        inv.review_log.append({"outcome": REVIEW,
                               "reasons": ["same name and creation date, different ID"],
                               "tenant_id": "tenant-p", "source_type": "aws_bedrock",
                               "external_id": normalized["source_references"][0]["external_id"]})
        result = None  # critical: do not call inv.ingest() for this new record
    else:
        result = inv.ingest(incoming, "tenant-p", "aws_bedrock")

    assert result is None
    assert inv.get("tenant-p", "aws_bedrock", normalized["source_references"][0]["external_id"]) is None
    assert inv.get("tenant-p", "aws_bedrock", "ABC123")["lifecycle_state"] == "QUARANTINED"
    assert inv.review_log[-1]["outcome"] == REVIEW

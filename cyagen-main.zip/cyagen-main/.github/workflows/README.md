# CI/CD workflows

Mohd Araaf / the CI owner: add the approved GitHub Actions workflow YAML here.
Connect checks to the actual languages, dependency files, test commands and
build commands after these are confirmed. Do not treat this placeholder as an
operational pipeline.

# Repository scripts

Place shared helper scripts here. Document prerequisites and usage for each
script. Keep module-specific scripts inside the relevant module.

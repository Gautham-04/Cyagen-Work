# CyAgen

CyAgen is organized as a hybrid monorepo: each functional module has its own
source, tests, configuration and documentation, while cross-module contracts,
events and integration tests are maintained centrally.

## Repository layout

- `modules/` — five functional modules
- `shared/contracts/` — shared interface contracts
- `shared/events/` — shared event schemas
- `shared/integration-tests/` — cross-module integration tests
- `docker/` — shared container build and local composition files
- `.github/workflows/` — CI/CD workflows
- `scripts/` — repository helper scripts
- `docs/` — architecture and engineering documentation

## Getting started

1. Read the relevant module README.
2. Install the dependencies listed by that module.
3. Add tests under the module's `tests/` directory.
4. Keep shared interface changes under `shared/contracts/` and coordinate them
   with provider and consumer pods.
5. Follow the team's agreed branch, pull-request and review rules.

> Initial scaffold: module implementations, exact dependency versions, service
> commands, owners and CI checks must be filled in and verified by the team.

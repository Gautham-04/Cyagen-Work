# Engineering documentation

Suggested documents:
- architecture overview and module boundaries
- local development setup
- branching and pull-request workflow
- CI/CD and test-evidence process
- security and secrets-handling guidance
- release and versioning approach

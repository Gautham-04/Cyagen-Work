# module-1-agent-discovery

Module owner: confirm and add the responsible pod/team.

## Contents
- `src/` — implementation
- `tests/` — unit and module-level tests
- `config/` — non-secret configuration and examples
- `docs/` — module-specific documentation

Add verified setup, run, test and build commands once the implementation
and runtime are confirmed.

# Cross-module integration tests

Place tests that validate interactions between modules here. Keep test
environment requirements, test data provenance and evidence links documented.
Clearly label mocks and synthetic data; do not report an integration test as
passed unless it was actually executed.

# Shared resources

Keep cross-module interface definitions and integration assets here.
Coordinate changes with both provider and consumer pods.

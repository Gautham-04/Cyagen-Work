# Security event schema

Add the canonical security-event schema and validated examples here.
Coordinate event field ownership and semantics with A1, A3, A4, B1 and B2.
Distinguish event_id, request_id, correlation_id and decision_id.

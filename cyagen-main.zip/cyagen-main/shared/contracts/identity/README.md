# Identity contract

Add the agreed identity schema and examples here. Confirm field names, types,
required/optional status and identifier semantics with producing and consuming
pods before marking the contract final.

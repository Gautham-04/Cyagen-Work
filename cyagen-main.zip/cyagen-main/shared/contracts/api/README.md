# API contracts

Add versioned API specifications and examples here after endpoint ownership,
request/response formats, pagination and error handling are confirmed.

# Policy decision contract

Add the agreed policy request/response schema here. Confirm decision values,
reason codes, evaluation status, identifiers and error semantics with the
Gateway, Policy Engine and Audit pods.

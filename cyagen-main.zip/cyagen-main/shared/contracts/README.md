# Shared contracts

Organize versioned schemas and interface definitions by contract domain.
Record the provider, consumer, version, compatibility expectations and change
owner for each contract.
